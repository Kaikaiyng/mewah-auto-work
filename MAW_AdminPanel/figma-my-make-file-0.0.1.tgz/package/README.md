# MAW Admin Panel

MAW 管理后台是 Mewah Auto Work 系统的核心运营中枢，用于全面管理客户公司、车辆/设备、Staff 员工、预约、工单流水、备件库存、供应商采购单 (PO)、客户订单、发票及 AutoCount 财务同步监控。

> 📖 **完整技术规范与业务状态机参考**：详见根目录 [PROJECT_DOCUMENTATION.md](../PROJECT_DOCUMENTATION.md)。

---

## 技术栈与运行环境

- **框架**：React 18.3.1 + Vite 6.3.5
- **样式与组件**：TailwindCSS 4.1.12, Material UI 7.3.5, Radix UI Primitives, Recharts 2.15.2
- **路由**：React Router 7.13.0
- **后端通信**：共享 PHP RESTful API（`backend/api.php`）

| 模式 | API 网关地址 | 数据库 |
| :--- | :--- | :--- |
| **Development** | Vite 代理到线上 Staging API | `winnerc4_mewahautowork_staging` |
| **Staging** | `https://adminpanel.mewahautoworks.com.my/staging/api_staging/api.php` | `winnerc4_mewahautowork_staging` |
| **Production** | `https://adminpanel.mewahautoworks.com.my/api/api.php` | `winnerc4_mewahautoworksystem` |

---

## 本地启动

```bash
corepack enable
pnpm install
pnpm dev
```

`pnpm dev` 会启动 Vite 开发服务器（默认端口 `http://localhost:5173/`）。本地所有 `/api` 请求默认代理至 Staging 环境，不会影响生产数据。

---

## 核心业务模块与功能

1. **Dashboard (`/`)**：实时工单状态分布、待审核车辆数量、低库存预警及营收统计。
2. **Work Orders (`/work-orders`)**：
   - 支持从预约转入或现场 Walk-in 快速开单（`checked_in`）。
   - 完整维修生命周期阶段流转（`scheduled` &rarr; `checked_in` &rarr; `inspected` &rarr; `quotation_issued` &rarr; `approved` &rarr; `parts_ready` &rarr; `under_repair` &rarr; `ready_for_collection` &rarr; `collected`）。
   - 报价单制作与下发客户审批；备件申请与缺件前置阻断（`parts_status` 必须为 `parts_ready` 才可开工）。
   - 检验照片管理（支持控制各照片对客户是否可见）。
3. **Bookings (`/bookings`)**：客户预约受理、排期与一键转入工单。
4. **Companies (`/companies`)**：维护企业客户档案、AutoCount Debtor Code 映射、信用额度与付款账期。
5. **Customers (`/customers`)**：维护客户公司下的登录账号（Company Users）。
6. **Drivers (`/drivers`)**：维护车队司机资料（司机不分配系统登录权限）。
7. **Equipment/Vehicles (`/equipment`)**：商用车辆技术规格（底盘号、BTM/BDM、发动机号）与车辆 Grant 审核。
8. **Parts (`/parts`)**：备件物料主数据、货位、安全库存及 AutoCount Item Code 映射。
9. **Purchase Orders (`/purchase-orders`)**：向供应商下达采购订单、跟踪发货及入库收货（入库时自动更新库存）。
10. **Orders (`/orders`)**：客户零件商城订单处理与 AutoCount DO 队列派发。
11. **Invoices (`/invoices`)**：工单发票开具、收款状态跟踪及 AutoCount 同步管理。
12. **AutoCount Sync (`/autocount-sync`)**：三类 Outbox 队列监控、同步重试与错误排查。
13. **Staff (`/staff`)**：管理员工档案、角色与车间技师指派。
14. **Audit Trail (`/audit-trail`)**：只增审计日志查看（记录操作人、IP、变更前后差异）。
15. **App Logs (`/app-logs`)**：后台应用日志实时查看与分析。

---

## 角色权限体系 (RBAC)

后台权限在前端界面与后端 `backend/api.php`（`requireAdminSession()` / `checkPermission()`）双重强校验：

| 角色 | 权限范围 |
| :--- | :--- |
| **Super Admin / Admin** | 拥有全部管理权限，包含 Staff 账号、系统设置、审核及全部业务操作。 |
| **Head Manager / Manager** | 拥有工单全流程流转、报价开票、PO 采购入库、备件管理及大部分管理权限。 |
| **Service Advisor** | 负责预约接待、工单开单、客户沟通、车辆审核及开具发票；不能管理 Staff 与修改敏感系统配置。 |
| **Receptionist** | 负责前台预约接待、基本客户登记及未同步发票的付款记录。 |
| **Foreman / Mechanic / Technician** | 车间技师，负责查看指派工单、推进施工阶段（`under_repair` / `ready_for_collection`）及上传检验照片。 |

---

## 构建与打包

在 `MAW_AdminPanel/` 目录下：

```bash
# 验证构建
pnpm build

# 同时打包生产与 staging 更新包
pnpm pack

# 单独打包
pnpm pack:production-only  # 生成 AdminSystem_Update.zip
pnpm pack:staging-only     # 生成 AdminSystem_Update_Staging.zip
```

打包生成的 ZIP 文件可直接上传至托管根目录解压覆盖部署。

---

## 部署注意事项

1. **生产根目录**：`/home/winnerc4/adminpanel.mewahautoworks.com.my`。
2. **私有配置保护**：数据库配置必须位于 `public_html` 以外（如 `/home/CPANEL_USER/maw_db_config.php`），严禁被打包文件覆盖。
3. **发布前备份**：生产发布前务必备份生产数据库 `winnerc4_mewahautoworksystem`。
