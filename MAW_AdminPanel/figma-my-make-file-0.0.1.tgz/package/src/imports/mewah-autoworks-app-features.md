Mewah AutoWorks 移动应用 - 完整功能清单
🏠 1. 首页 (Home)
欢迎界面（用户名、Logo）
语言切换器（英语 / 马来文 / 中文）
通知铃铛（未读通知徽章、下拉通知面板）
快捷操作按钮：
📋 预订服务 (Book Service)
📦 购买配件 (Buy Parts)
🛡️ 保险续约 (Insurance)
📞 道路救援 (Roadside Assist)
下一个预订显示卡（日期、时间、地点）
📅 2. 预订管理 (Bookings)
预订列表：

Upcoming（即将到来）
Completed（已完成）
显示服务类型、日期、车辆、状态
预订详情：

预订编号、状态徽章
车辆信息、服务类型
日期、时间、地点
备注（顾客备注、技师备注）
发票查看按钮
5步预订流程：

选择车辆（Select Vehicle）
选择服务类型（Service Type）- General Service、Oil Change、Brake Service、Engine Repair等
选择日期和时间（Date & Time）- 固定地点：Pasir Gudang HQ
添加备注（Notes）
确认预订（Confirmation）
🔧 3. 配件商城 (Parts)
配件分类：

All Parts（全部）
Oil and Filters（机油和滤芯）
Brake Parts（刹车配件）
Engine Parts（引擎配件）
Car Accessories（汽车配件）
配件商品：

商品图片、名称、价格
库存状态
加入购物车功能
购物车：

商品列表、数量调整
小计、税费、总计
结账流程
配件订单：

订单列表（Ready、Completed）
订单详情（订单号、配送地址、商品列表、总价）
订单完成后下载发票
🔔 4. 维护提醒 (Reminders)
车辆维护提醒：

下次服务日期
推荐里程数
服务类型
通知开关
证件到期提醒：

🛡️ 保险到期日期 (Insurance Expiry)
🚗 路税到期日期 (Road Tax Expiry)
✅ Puspakom检验到期日期
👤 5. 个人资料 (Profile)
个人信息：

姓名、邮箱、电话
编辑个人信息
注册车辆 (Equipment Management)：

车辆列表
添加新车辆
车辆详情：
Vec No（车辆编号）
Reg No（注册号码）
Equipment（设备类型）- 如40's Trailer、Prime Mover
Brand（品牌）- Volvo、Scania
Model（型号）
里程数 (Mileage)
年份 (Year)
底盘号 (Chassis No)
引擎号 (Engine No)
保险到期
路税到期
Puspakom到期
车辆历史记录：

查看该车辆的所有服务记录
配送地址管理：

地址列表
添加/编辑/删除地址
设置默认地址
发票记录 (Invoices)：

查看所有已完成服务的发票
发票详情（服务项目、配件、人工费、税费）
下载发票PDF
通知设置：

服务提醒
配件订单通知
保险/路税到期提醒
设置 (Settings)：

语言设置
通知偏好
账户设置
🆘 6. 其他功能
保险续约 (Insurance)：

提交保险续约申请
选择车辆
填写保险详情
上传文件
道路救援 (Roadside Assistance)：

紧急救援请求
选择车辆
描述问题
当前位置
联系方式
客户支持 (Support)：

常见问题 (FAQ)
联系客服
WhatsApp、电话、邮件
🔐 7. 认证
登录系统：
用户名/邮箱登录
密码输入
记住我功能
🎨 8. UI/UX特色
深蓝色主题 (#1e3a8a)
移动优先设计
三语支持（EN / MS / ZH）
底部导航栏（5个标签）
通知系统（实时提醒、未读徽章）
渐变背景卡片
圆角设计、毛玻璃效果
优雅的滚动条
🖥️ 您需要的后台管理系统功能建议
基于以上移动应用功能，后台系统应该包含以下模块：

1. 仪表板 (Dashboard)
今日预订统计
待处理订单数量
收入概览
最近活动
2. 客户管理 (Customer Management)
客户列表（搜索、筛选）
客户详情（个人信息、车辆、预订历史）
添加/编辑客户
3. 车辆管理 (Equipment Management)
所有客户车辆列表
车辆详情编辑
维护记录
4. 预订管理 (Booking Management)
预订列表（All、Upcoming、In Progress、Completed、Cancelled）
预订详情查看
状态更新
分配技师
添加技师备注
5. 配件管理 (Parts Inventory)
配件库存列表
添加/编辑/删除配件
库存数量管理
价格管理
分类管理
6. 订单管理 (Orders Management)
服务订单
配件订单
订单状态更新
配送管理
7. 发票管理 (Invoice Management)
创建发票
发票列表
发票详情（服务项目、配件、税费）
导出PDF
8. 通知管理 (Notification Center)
发送通知给客户
通知历史记录
批量通知
9. 报表分析 (Reports & Analytics)
收入报表
服务统计
配件销售统计
客户活跃度分析
10. 用户权限管理 (User & Roles)
管理员账户
角色权限设置
员工账户管理
11. 设置 (Settings)
服务中心信息
服务类型管理
价格设置
系统配置