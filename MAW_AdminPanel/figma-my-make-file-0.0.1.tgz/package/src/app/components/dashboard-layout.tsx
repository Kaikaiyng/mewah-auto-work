import { Link, useLocation, useNavigate, useOutlet } from "react-router";
import {
  Home,
  Users,
  Building2,
  Car,
  Calendar,
  Package,
  ShoppingCart,
  FileText,
  Bell,
  BarChart3,
  Settings,
  Menu,
  X,
  LogOut,
  ClipboardList,
  UserCog,
  Info,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  CalendarClock,
  Landmark,
  Handshake,
  ShieldCheck,
  Activity,
  LayoutDashboard,
} from "lucide-react";
import { useState, useEffect, useRef, useMemo } from "react";
import { useLanguage } from "../contexts/language-context";
import { clearAdminAuth } from "./login-page";
import { useApiData } from "../lib/use-api-data";
import { postApi } from "../lib/api";
import { canAccessAdminPath, getSignedInAdmin } from "../lib/admin-permissions";
import mawLogo from "../../MAW_logo.png";

const APP_VERSION = "0.0.1";
const SIDEBAR_COLLAPSED_KEY = "maw-admin-sidebar-collapsed";
const EXPANDED_SECTIONS_KEY = "maw-admin-expanded-sections";
const READ_NOTIFICATIONS_KEY = "maw-admin-read-notifications";

interface NotificationItem {
  id: number | string;
  title: string;
  message: string;
  type: string;
  date: string;
  actionRoute?: string;
}

const navStructure: Array<
  | {
      type: "single";
      path: string;
      nameKey: string;
      icon: any;
    }
  | {
      type: "group";
      id: string;
      titleKey: string;
      icon: any;
      items: Array<{ nameKey: string; path: string }>;
    }
> = [
  {
    type: "single",
    path: "/",
    nameKey: "dashboard",
    icon: LayoutDashboard,
  },
  {
    type: "group",
    id: "workshop",
    titleKey: "workshop",
    icon: ClipboardList,
    items: [
      { nameKey: "bookings_nav", path: "/bookings" },
      { nameKey: "work_orders", path: "/work-orders" },
    ],
  },
  {
    type: "group",
    id: "customers_group",
    titleKey: "customers_group",
    icon: Building2,
    items: [
      { nameKey: "companies", path: "/companies" },
      { nameKey: "customers", path: "/customers" },
      { nameKey: "drivers", path: "/drivers" },
      { nameKey: "vehicles", path: "/equipment" },
      { nameKey: "autocount_projects", path: "/projects" },
    ],
  },
  {
    type: "group",
    id: "inventory",
    titleKey: "inventory",
    icon: Package,
    items: [
      { nameKey: "parts_inventory", path: "/parts" },
      { nameKey: "parts_orders", path: "/orders" },
      { nameKey: "suppliers", path: "/suppliers" },
    ],
  },
  {
    type: "group",
    id: "finance",
    titleKey: "finance",
    icon: FileText,
    items: [
      { nameKey: "purchase_orders", path: "/purchase-orders" },
      { nameKey: "invoices", path: "/invoices" },
      { nameKey: "pending_sync_invoices", path: "/pending-sync-invoices" },
      { nameKey: "reports", path: "/reports" },
    ],
  },
  {
    type: "group",
    id: "admin_group",
    titleKey: "admin_group",
    icon: ShieldCheck,
    items: [
      { nameKey: "staff", path: "/staff" },
      { nameKey: "autocount_sync", path: "/autocount-sync" },
      { nameKey: "audit_trail", path: "/audit-trail" },
      { nameKey: "app_logs", path: "/app-logs" },
    ],
  },
  {
    type: "single",
    path: "/settings",
    nameKey: "settings",
    icon: Settings,
  },
];

export function DashboardLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const outlet = useOutlet();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(() => {
    try {
      return window.localStorage.getItem(SIDEBAR_COLLAPSED_KEY) === "true";
    } catch {
      return false;
    }
  });

  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>(() => {
    try {
      const saved = window.localStorage.getItem(EXPANDED_SECTIONS_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return {
      workshop: true,
      customers_group: false,
      inventory: false,
      finance: false,
      admin_group: false,
    };
  });

  const toggleSection = (sectionKey: string) => {
    setExpandedSections((prev) => {
      const next = { ...prev, [sectionKey]: !prev[sectionKey] };
      try {
        window.localStorage.setItem(EXPANDED_SECTIONS_KEY, JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  // Auto-expand section if current route is inside it
  useEffect(() => {
    for (const nav of navStructure) {
      if (nav.type === "group") {
        const hasActiveChild = nav.items.some((item) => item.path === location.pathname);
        if (hasActiveChild && !expandedSections[nav.id]) {
          setExpandedSections((prev) => {
            const next = { ...prev, [nav.id]: true };
            try {
              window.localStorage.setItem(EXPANDED_SECTIONS_KEY, JSON.stringify(next));
            } catch {}
            return next;
          });
        }
      }
    }
  }, [location.pathname]);
  const { t } = useLanguage();
  const signedInAdmin = getSignedInAdmin();
  const canViewNotifications = canAccessAdminPath("/notifications", signedInAdmin.role);
  const currentPageName = location.pathname === "/"
    ? t("dashboard")
    : (() => {
        for (const nav of navStructure) {
          if (nav.type === "single" && nav.path === location.pathname) {
            return t(nav.nameKey);
          }
          if (nav.type === "group") {
            const found = nav.items.find((item) => item.path === location.pathname);
            if (found) return t(found.nameKey);
          }
        }
        return "Admin Panel";
      })();

  // Notification states & API
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [readNotificationIds, setReadNotificationIds] = useState<Set<string>>(() => {
    try {
      const saved = window.localStorage.getItem(READ_NOTIFICATIONS_KEY);
      if (saved) return new Set(JSON.parse(saved));
    } catch {
      // fallback
    }
    return new Set();
  });
  const dropdownRef = useRef<HTMLDivElement>(null);

  const saveReadNotificationIds = (newSet: Set<string>) => {
    setReadNotificationIds(newSet);
    try {
      window.localStorage.setItem(READ_NOTIFICATIONS_KEY, JSON.stringify(Array.from(newSet)));
    } catch {}
  };

  const markSingleNotificationRead = (id: number | string) => {
    const next = new Set(readNotificationIds);
    next.add(String(id));
    saveReadNotificationIds(next);
  };

  const markAllNotificationsRead = () => {
    const next = new Set(readNotificationIds);
    notifications.forEach((n) => next.add(String(n.id)));
    saveReadNotificationIds(next);
  };

  const { data: partsAlertData, reload: reloadPartsAlert } = useApiData<{ hasUnacknowledgedParts: boolean; count: number }>(
    "admin-unacknowledged-parts-alert",
    { hasUnacknowledgedParts: false, count: 0 },
    true,
  );

  const { data: notifications, reload: reloadNotifications } = useApiData<NotificationItem[]>(
    "admin-notifications",
    [],
    canViewNotifications,
  );

  const unreadNotificationsCount = useMemo(() => {
    return notifications.filter((n) => !readNotificationIds.has(String(n.id))).length;
  }, [notifications, readNotificationIds]);

  useEffect(() => {
    const interval = setInterval(() => {
      void reloadPartsAlert();
      if (canViewNotifications) void reloadNotifications();
    }, 8000);
    const handlePartsUpdate = () => {
      void reloadPartsAlert();
      if (canViewNotifications) void reloadNotifications();
    };
    window.addEventListener("work-order-parts-updated", handlePartsUpdate);
    return () => {
      clearInterval(interval);
      window.removeEventListener("work-order-parts-updated", handlePartsUpdate);
    };
  }, [canViewNotifications, reloadNotifications, reloadPartsAlert]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setNotificationsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleLogout = async () => {
    try {
      await postApi<void>("admin-logout", {});
    } catch {
      // Local credentials are still cleared if the server is unavailable.
    } finally {
      clearAdminAuth();
      navigate("/login", { replace: true });
    }
  };

  const toggleDesktopSidebar = () => {
    setSidebarCollapsed((currentValue) => {
      const nextValue = !currentValue;
      try {
        window.localStorage.setItem(SIDEBAR_COLLAPSED_KEY, String(nextValue));
      } catch {
        // The sidebar still works when browser storage is unavailable.
      }
      return nextValue;
    });
  };

  const sidebarLabelClass = (compact: boolean) => `min-w-0 shrink-0 whitespace-nowrap transition-[opacity,transform] duration-100 ${
    compact
      ? "pointer-events-none translate-x-1 opacity-0"
      : "translate-x-0 opacity-100 delay-75"
  }`;

  const hasWorkOrderPartsAlert = useMemo(() => {
    return Boolean(partsAlertData?.hasUnacknowledgedParts);
  }, [partsAlertData]);

  const renderNavItems = (onItemClick?: () => void, compact = false) => {
    return (
      <nav className="space-y-1.5 font-sans">
        {navStructure.map((entry) => {
          if (entry.type === "single") {
            if (!canAccessAdminPath(entry.path, signedInAdmin.role)) return null;
            const isActive = location.pathname === entry.path;
            return (
              <Link
                key={entry.path}
                to={entry.path}
                onClick={onItemClick}
                title={compact ? t(entry.nameKey) : undefined}
                aria-label={compact ? t(entry.nameKey) : undefined}
                className={`group relative flex items-center rounded-xl px-3.5 py-2.5 text-[13px] font-semibold transition-all ${
                  isActive
                    ? "bg-blue-50/90 text-[#1e3a8a] font-bold shadow-xs"
                    : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                }`}
              >
                <div className="relative mr-3 flex-shrink-0">
                  <entry.icon
                    className={`h-[18px] w-[18px] transition-colors ${
                      isActive
                        ? "text-[#1e3a8a]"
                        : "text-slate-500 group-hover:text-slate-700"
                    }`}
                  />
                </div>
                <span className={sidebarLabelClass(compact)}>{t(entry.nameKey)}</span>
              </Link>
            );
          }

          // Group item
          const accessibleItems = entry.items.filter((item) =>
            canAccessAdminPath(item.path, signedInAdmin.role)
          );
          if (accessibleItems.length === 0) return null;

          const isExpanded = expandedSections[entry.id] ?? false;
          const hasActiveChild = accessibleItems.some(
            (item) => location.pathname === item.path
          );
          const hasAlert =
            entry.id === "workshop" && hasWorkOrderPartsAlert;

          if (compact) {
            return (
              <div key={entry.id} className="space-y-1 pt-1 border-t border-slate-100/70">
                {accessibleItems.map((item) => {
                  const isActive = location.pathname === item.path;
                  return (
                    <Link
                      key={item.path}
                      to={item.path}
                      onClick={onItemClick}
                      title={t(item.nameKey)}
                      aria-label={t(item.nameKey)}
                      className={`group relative flex items-center justify-center rounded-xl p-2.5 text-[13px] font-semibold transition-colors ${
                        isActive
                          ? "bg-blue-50 text-[#1e3a8a] font-bold"
                          : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                      }`}
                    >
                      <entry.icon
                        className={`h-[18px] w-[18px] transition-colors ${
                          isActive
                            ? "text-[#1e3a8a]"
                            : "text-slate-500 group-hover:text-slate-700"
                        }`}
                      />
                    </Link>
                  );
                })}
              </div>
            );
          }

          return (
            <div key={entry.id} className="space-y-0.5">
              {/* Group Header Button */}
              <button
                type="button"
                onClick={() => toggleSection(entry.id)}
                className={`group flex w-full items-center justify-between rounded-xl px-3.5 py-2.5 text-left text-[13px] font-semibold transition-all cursor-pointer ${
                  isExpanded || hasActiveChild
                    ? "bg-blue-50/80 text-[#1e3a8a] font-bold"
                    : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                }`}
                aria-expanded={isExpanded}
              >
                <div className="flex items-center min-w-0">
                  <entry.icon
                    className={`mr-3 h-[18px] w-[18px] flex-shrink-0 transition-colors ${
                      isExpanded || hasActiveChild
                        ? "text-[#1e3a8a]"
                        : "text-slate-500 group-hover:text-slate-700"
                    }`}
                  />
                  <span className={sidebarLabelClass(compact)}>{t(entry.titleKey)}</span>
                  {hasAlert ? (
                    <span className="relative ml-2 flex h-2 w-2">
                      <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-400 opacity-75"></span>
                      <span className="relative inline-flex h-2 w-2 rounded-full bg-red-500"></span>
                    </span>
                  ) : null}
                </div>
                {!compact && (
                  <ChevronRight
                    className={`h-4 w-4 transition-transform duration-300 ease-in-out ${
                      isExpanded
                        ? "rotate-90 text-[#1e3a8a]"
                        : "rotate-0 text-slate-400 group-hover:text-slate-600"
                    }`}
                  />
                )}
              </button>

              {/* Sub-items list with silky smooth grid-height accordion transition */}
              <div
                className={`grid transition-[grid-template-rows,opacity] duration-300 ease-in-out ${
                  isExpanded
                    ? "grid-rows-[1fr] opacity-100"
                    : "grid-rows-[0fr] opacity-0 pointer-events-none"
                }`}
              >
                <div className="overflow-hidden">
                  <div className="ml-5 border-l-2 border-blue-200/80 pl-4 py-1 space-y-1">
                    {accessibleItems.map((item) => {
                      const isActive = location.pathname === item.path;
                      const showPartsDot =
                        item.path === "/work-orders" && hasWorkOrderPartsAlert;
                      return (
                        <Link
                          key={item.path}
                          to={item.path}
                          onClick={onItemClick}
                          className={`group relative flex items-center justify-between rounded-lg px-2 py-1.5 text-[13px] transition-colors ${
                            isActive
                              ? "font-bold text-[#1e3a8a]"
                              : "font-medium text-slate-500 hover:text-[#1e3a8a]"
                          }`}
                        >
                          <span className="truncate">{t(item.nameKey)}</span>
                          {showPartsDot ? (
                            <span className="relative flex h-2 w-2">
                              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-400 opacity-75"></span>
                              <span className="relative inline-flex h-2 w-2 rounded-full bg-red-500"></span>
                            </span>
                          ) : null}
                        </Link>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </nav>
    );
  };

  const renderSidebarFooter = (onLogout?: () => void, compact = false) => (
    <div className="mt-auto flex-shrink-0 pt-2 border-t border-slate-100/80 space-y-1">
      <div
        className="flex items-center overflow-hidden rounded-xl px-3.5 py-2 text-slate-500"
        title={compact ? `Admin Portal · Version ${APP_VERSION}` : undefined}
      >
        <Info className="mr-3 h-[18px] w-[18px] flex-shrink-0 text-slate-400" />
        <div className={sidebarLabelClass(compact)}>
          <p className="text-xs font-semibold text-slate-700">Admin Portal</p>
          <p className="text-[10px] text-slate-400">Version {APP_VERSION}</p>
        </div>
      </div>
      <button
        type="button"
        onClick={() => {
          onLogout?.();
          void handleLogout();
        }}
        title={compact ? "Log out" : undefined}
        aria-label={compact ? "Log out" : undefined}
        className="group flex w-full items-center overflow-hidden rounded-xl px-3.5 py-2 text-left text-[13px] font-semibold text-slate-600 transition-colors hover:bg-red-50 hover:text-red-600"
      >
        <LogOut className="mr-3 h-[18px] w-[18px] flex-shrink-0 text-red-500 transition-colors group-hover:text-red-600" />
        <span className={sidebarLabelClass(compact)}>Log out</span>
      </button>
    </div>
  );

  return (
    <div className="maw-admin-shell min-h-screen overflow-x-hidden bg-[#f6f7fb]">
      {/* Sidebar for desktop with smoothly gliding attached toggle tab */}
      <div className={`maw-admin-sidebar hidden z-30 transform-gpu transition-transform duration-200 ease-out lg:fixed lg:inset-y-0 lg:flex lg:flex-col lg:w-64 ${sidebarCollapsed ? "lg:-translate-x-full" : "lg:translate-x-0"}`}>
        <div className="relative flex h-full flex-grow flex-col overflow-visible border-r border-slate-200 bg-white shadow-[5px_0_24px_rgba(15,23,42,0.04)]">
          <div className="flex h-20 flex-shrink-0 items-center justify-center overflow-hidden border-b border-slate-100 bg-white px-3">
            <div className="flex h-14 w-full items-center justify-center">
              <img
                src={mawLogo}
                className="h-auto w-[145px] object-contain"
                alt="Mewah AutoWorks"
              />
            </div>
          </div>
          <button
            type="button"
            onClick={toggleDesktopSidebar}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-full z-30 flex h-11 w-6 items-center justify-center rounded-r-xl border border-l-0 border-slate-200 bg-white text-slate-400 shadow-sm transition-all hover:w-7.5 hover:bg-slate-50 hover:text-slate-700 focus:outline-none focus:ring-0 focus-visible:outline-none focus-visible:ring-0 cursor-pointer"
            aria-label={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
            title={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            {sidebarCollapsed ? (
              <ChevronRight className="h-4 w-4" />
            ) : (
              <ChevronLeft className="h-4 w-4" />
            )}
          </button>
          <div className="maw-sidebar-scroll flex min-h-0 flex-1 flex-col justify-between px-2.5 py-3">
            {renderNavItems(undefined, false)}
            {renderSidebarFooter(undefined, false)}
          </div>
        </div>
      </div>

      {/* Mobile sidebar */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="fixed inset-0 bg-gray-600 bg-opacity-75"
            onClick={() => setSidebarOpen(false)}
          />
          <div className="fixed inset-y-0 left-0 flex w-64 flex-col bg-white shadow-2xl">
            <div className="flex h-20 flex-shrink-0 items-center justify-between overflow-hidden border-b border-slate-100 bg-white px-4">
              <div className="flex h-14 w-36 items-center justify-center">
                <img
                  src={mawLogo}
                  className="h-auto w-[145px] object-contain"
                  alt="Mewah AutoWorks"
                />
              </div>
              <button
                onClick={() => setSidebarOpen(false)}
                className="rounded-lg p-2 text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700"
                aria-label="Close navigation"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            <div className="maw-sidebar-scroll flex min-h-0 flex-1 flex-col justify-between px-2.5 py-3">
              {renderNavItems(() => setSidebarOpen(false))}
              {renderSidebarFooter(() => setSidebarOpen(false))}
            </div>
          </div>
        </div>
      )}

      {/* Main content */}
      <div className={`maw-admin-main flex flex-1 flex-col transition-[padding] duration-200 ease-out ${sidebarCollapsed ? "lg:pl-0" : "lg:pl-64"}`}>
        {/* Top bar */}
        <div className="sticky top-0 z-10 flex h-14 border-b border-gray-200 bg-white/95 backdrop-blur">
          <button
            type="button"
            className="px-4 text-gray-500 lg:hidden"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="h-6 w-6" />
          </button>
          <div className="flex flex-1 justify-between px-4 sm:px-6 lg:px-8">
            <div className="flex flex-1 items-center gap-2 text-sm">
              <span className="hidden text-gray-400 sm:inline">Mewah AutoWorks</span>
              <span className="hidden text-gray-300 sm:inline">/</span>
              <h2 className="text-sm font-semibold text-gray-800">{currentPageName}</h2>
            </div>
            <div className="flex items-center space-x-4">
              {canViewNotifications ? <div className="relative" ref={dropdownRef}>
                <button
                  onClick={() => setNotificationsOpen(!notificationsOpen)}
                  className="relative p-2 text-gray-400 hover:text-gray-500 rounded-full hover:bg-gray-100 transition-colors focus:outline-none cursor-pointer"
                  aria-label="Notifications"
                >
                  <Bell className="h-6 w-6" />
                  {unreadNotificationsCount > 0 && (
                    <span className="absolute top-1 right-1 h-2.5 w-2.5 rounded-full bg-red-500 ring-2 ring-white" />
                  )}
                </button>

                {/* Dropdown Popover */}
                {notificationsOpen && (
                  <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-lg shadow-lg border border-gray-200 z-50 overflow-hidden animate-in fade-in slide-in-from-top-1 duration-150">
                    <div className="flex items-center justify-between px-4 py-2.5 border-b border-gray-150 bg-gray-50">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-gray-900">Notifications</span>
                        {unreadNotificationsCount > 0 && (
                          <span className="rounded-full bg-blue-100 px-2 py-0.5 text-[10px] font-bold text-blue-700">
                            {unreadNotificationsCount} new
                          </span>
                        )}
                      </div>
                      {unreadNotificationsCount > 0 && (
                        <button
                          onClick={markAllNotificationsRead}
                          className="text-[11px] text-blue-600 hover:text-blue-800 font-medium transition-colors cursor-pointer"
                        >
                          Mark all as read
                        </button>
                      )}
                    </div>
                    
                    <div className="max-h-64 overflow-y-auto divide-y divide-gray-100">
                      {notifications.length === 0 ? (
                        <div className="text-center py-8 text-xs text-gray-500">
                          No notifications found.
                        </div>
                      ) : (
                        notifications.slice(0, 6).map((n) => {
                          const isUnread = !readNotificationIds.has(String(n.id));
                          return (
                            <div
                              key={n.id}
                              onClick={() => {
                                markSingleNotificationRead(n.id);
                                setNotificationsOpen(false);
                                navigate(n.actionRoute || "/notifications");
                              }}
                              className={`p-3 hover:bg-gray-50 cursor-pointer transition-colors ${
                                isUnread ? "bg-blue-50/40" : ""
                              }`}
                            >
                              <div className="flex items-start">
                                <div className="mt-1 mr-2.5 flex-shrink-0">
                                  {isUnread ? (
                                    <span className="flex h-2 w-2 rounded-full bg-blue-600" />
                                  ) : (
                                    <span className="flex h-2 w-2 rounded-full bg-slate-200" />
                                  )}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className={`text-xs ${isUnread ? "font-bold text-slate-900" : "font-medium text-slate-700"} truncate`}>
                                    {n.title}
                                  </p>
                                  <p className="text-[11px] text-gray-500 mt-0.5 line-clamp-2">{n.message}</p>
                                  <p className="text-[9px] text-gray-400 mt-1">{n.date}</p>
                                </div>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>

                    <div className="border-t border-gray-100 bg-gray-50 text-center py-2">
                      <Link
                        to="/notifications"
                        onClick={() => {
                          markAllNotificationsRead();
                          setNotificationsOpen(false);
                        }}
                        className="text-[11px] font-semibold text-blue-600 hover:text-blue-800 transition-colors inline-block w-full"
                      >
                        View all notifications
                      </Link>
                    </div>
                  </div>
                )}
              </div> : null}
              <div className="flex items-center space-x-3">
                <div className="h-8 w-8 rounded-full bg-[#1e3a8a] flex items-center justify-center text-white text-sm">
                  {(signedInAdmin.displayName || signedInAdmin.username || "A").charAt(0).toUpperCase()}
                </div>
                <span className="hidden sm:block text-sm text-gray-700">
                  {signedInAdmin.displayName || signedInAdmin.username || "Admin"}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Page content */}
        <main className="flex-1">
          <div className="maw-admin-content px-4 py-5 sm:px-6 lg:px-8 lg:py-6">
            {outlet}
          </div>
        </main>
      </div>
    </div>
  );
}
