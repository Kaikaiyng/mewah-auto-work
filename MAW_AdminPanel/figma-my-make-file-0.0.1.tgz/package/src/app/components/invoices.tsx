import { useMemo, useState } from "react";
import { useNavigate } from "react-router";
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  Calendar,
  Check,
  CheckSquare,
  ClipboardList,
  Database,
  Download,
  Edit,
  Eye,
  FilePlus2,
  FileText,
  RefreshCw,
  RotateCw,
  Search,
  Send,
  Square,
  X,
} from "lucide-react";
import { apiRequest, postApi } from "../lib/api";
import { useApiData } from "../lib/use-api-data";
import { hasAdminPermission } from "../lib/admin-permissions";
import { toast } from "sonner";
import { WorkOrderInvoiceDialog, type InvoiceWorkOrder, type WorkOrderInvoice } from "./work-order-invoice-dialog";
import { AutoCountInvoiceDialog, type AutoCountInvoiceRecord } from "./autocount-invoice-dialog";
import { PartsOrderInvoiceDialog, type PartsOrderData } from "./parts-order-invoice-dialog";
import { AdminSelect } from "./ui/admin-select";
import { AutoCountSyncBadge } from "./autocount-sync-badge";
import { useConfirmationDialog } from "../contexts/confirmation-dialog-context";
import { DesktopDatePicker } from "./ui/desktop-date-picker";
import { exportTableToExcel, ExcelColumnDef } from "../lib/excel-export";

type InvoiceCandidate = InvoiceWorkOrder & {
  orderType?: "work_order" | "parts_order";
  partsOrderId?: string;
  partsOrder?: PartsOrderData;
};

type InvoiceRecord = Omit<WorkOrderInvoice, "id" | "status" | "storedStatus"> & AutoCountInvoiceRecord & {
  id: number | string;
  status: WorkOrderInvoice["status"] | "expired";
  storedStatus: WorkOrderInvoice["storedStatus"] | "expired";
  source?: "autocount" | "maw" | "maw_legacy" | "parts_order";
  orderType?: "work_order" | "parts_order";
  partsOrder?: PartsOrderData;
  summaryOnly?: boolean;
  workOrder: InvoiceWorkOrder;
};

function money(value: number) {
  return Number(value || 0).toLocaleString("en-MY", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function badge(status: string) {
  if (status === "paid") return "bg-emerald-100 text-emerald-700";
  if (status === "overdue" || status === "void" || status === "expired") return "bg-rose-100 text-rose-700";
  if (status === "partially_paid") return "bg-amber-100 text-amber-700";
  if (status === "pending_sync") return "bg-amber-100 text-amber-700";
  if (status === "issued") return "bg-blue-100 text-blue-700";
  return "bg-slate-100 text-slate-600";
}

type TabType = "all" | "issued" | "synced" | "unpaid" | "paid";

export function Invoices() {
  const navigate = useNavigate();
  const canManage = hasAdminPermission("invoice.update");
  const confirmAction = useConfirmationDialog();
  const { data: invoices, isLoading, error, reload } = useApiData<InvoiceRecord[]>("admin-invoices", []);
  const [search, setSearch] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [activeTab, setActiveTab] = useState<TabType>("all");
  const [status, setStatus] = useState("all");
  const [selectedWorkOrder, setSelectedWorkOrder] = useState<InvoiceWorkOrder | null>(null);
  const [selectedPartsOrder, setSelectedPartsOrder] = useState<PartsOrderData | null>(null);
  const [selectedAutoCountInvoice, setSelectedAutoCountInvoice] = useState<InvoiceRecord | null>(null);
  const [candidateOpen, setCandidateOpen] = useState(false);
  const [creationMode, setCreationMode] = useState(false);
  const [candidates, setCandidates] = useState<InvoiceCandidate[]>([]);
  const [candidateLoading, setCandidateLoading] = useState(false);
  const [candidateSearch, setCandidateSearch] = useState("");
  const [selectedIds, setSelectedIds] = useState<Set<number | string>>(new Set());
  const [isBatchSyncing, setIsBatchSyncing] = useState(false);


  const isPendingSyncRecord = (i: InvoiceRecord) =>
    ["queued", "pending", "processing"].includes(i.syncStatus || "") || i.status === "pending_sync";

  const nonPendingInvoices = useMemo(() => {
    return invoices.filter((i) => !isPendingSyncRecord(i));
  }, [invoices]);

  const pendingCount = useMemo(() => {
    return invoices.filter(isPendingSyncRecord).length;
  }, [invoices]);

  const counts = useMemo(() => {
    return {
      all: nonPendingInvoices.length,
      issued: nonPendingInvoices.filter((i) => !["paid", "void"].includes(i.storedStatus)).length,
      synced: nonPendingInvoices.filter((i) => i.syncStatus === "synced" || i.source === "autocount").length,
      unpaid: nonPendingInvoices.filter((i) => !["paid", "void", "draft"].includes(i.storedStatus) && i.balance > 0).length,
      paid: nonPendingInvoices.filter((i) => i.storedStatus === "paid").length,
    };
  }, [nonPendingInvoices]);

  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase();
    return nonPendingInvoices.filter((invoice) => {
      // Tab filter
      if (activeTab === "issued" && ["paid", "void"].includes(invoice.storedStatus)) return false;
      if (activeTab === "synced" && invoice.syncStatus !== "synced" && invoice.source !== "autocount") return false;
      if (activeTab === "unpaid" && (["paid", "void", "draft"].includes(invoice.storedStatus) || invoice.balance <= 0)) return false;
      if (activeTab === "paid" && invoice.storedStatus !== "paid") return false;

      // Date range filter
      if (startDate && invoice.invoiceDate && invoice.invoiceDate < startDate) return false;
      if (endDate && invoice.invoiceDate && invoice.invoiceDate > endDate) return false;

      // Status dropdown filter
      const matchesStatus = status === "all" || invoice.status === status;
      // Search query
      const matchesSearch =
        !query ||
        [
          invoice.invoiceNo,
          invoice.autocountInvoiceNo,
          invoice.workOrder?.workOrderNo,
          invoice.workOrder?.companyName,
          invoice.workOrder?.vehicleNo,
          invoice.autocountJobNo,
        ].some((value) => String(value || "").toLowerCase().includes(query));

      return matchesStatus && matchesSearch;
    });
  }, [nonPendingInvoices, search, status, activeTab, startDate, endDate]);

  const isInvoiceSyncable = (invoice: InvoiceRecord) => {
    if (invoice.source === "autocount" || invoice.syncStatus === "synced") return false;
    if (["paid", "void"].includes(invoice.storedStatus) || ["paid", "void"].includes(invoice.status)) return false;
    return true;
  };

  const syncableInFiltered = useMemo(() => {
    return filtered.filter(isInvoiceSyncable);
  }, [filtered]);

  const isAllSyncableSelected =
    syncableInFiltered.length > 0 &&
    syncableInFiltered.every((i) => selectedIds.has(i.id));

  const toggleSelect = (invoice: InvoiceRecord) => {
    if (!isInvoiceSyncable(invoice)) {
      if (invoice.syncStatus === "synced") {
        toast.info("This invoice is already synced to AutoCount.");
      } else if (invoice.storedStatus === "void" || invoice.status === "void") {
        toast.info("Void invoices cannot be synced.");
      }
      return;
    }
    const next = new Set(selectedIds);
    if (next.has(invoice.id)) {
      next.delete(invoice.id);
    } else {
      next.add(invoice.id);
    }
    setSelectedIds(next);
  };

  const toggleSelectAll = () => {
    if (syncableInFiltered.length === 0) {
      toast.info("No syncable invoices available in this view.");
      return;
    }
    if (isAllSyncableSelected) {
      setSelectedIds(new Set());
    } else {
      const next = new Set(selectedIds);
      syncableInFiltered.forEach((i) => next.add(i.id));
      setSelectedIds(next);
    }
  };

  const handleBatchQueueSync = async () => {
    if (selectedIds.size === 0) return;
    const count = selectedIds.size;
    const confirmed = await confirmAction({
      title: `Queue ${count} Invoice(s) for AutoCount Sync?`,
      description: `This will move ${count} selected invoice(s) to the Pending Sync queue.`,
      confirmLabel: "Queue Sync",
      tone: "primary",
    });
    if (!confirmed) return;

    setIsBatchSyncing(true);
    try {
      const idsArray = Array.from(selectedIds);
      await postApi("admin-batch-retry-autocount-invoice-sync", { invoiceIds: idsArray });
      toast.success(`${idsArray.length} invoice(s) queued for AutoCount sync.`);
      setSelectedIds(new Set());
      await reload();
    } catch (caught) {
      toast.error(caught instanceof Error ? caught.message : "Failed to queue invoices for sync.");
    } finally {
      setIsBatchSyncing(false);
    }
  };

  const openInvoiceDetail = (invoice: InvoiceRecord) => {
    if (invoice.source === "parts_order" || invoice.orderType === "parts_order") {
      setSelectedPartsOrder(invoice.partsOrder || {
        id: invoice.autocountJobNo || String(invoice.invoiceNo),
        customer: invoice.workOrder?.companyName || "Customer",
        items: (invoice.items || []).map((it) => ({
          name: it.description,
          quantity: it.quantity,
          price: it.unitPrice,
          code: it.code,
        })),
        total: invoice.total,
        status: "Processing",
        orderDate: invoice.invoiceDate,
        deliveryAddress: "",
        autocountDoNo: invoice.autocountDoNo || invoice.invoiceNo,
        debtorCode: invoice.workOrder?.debtorCode,
      });
    } else if (invoice.source === "autocount") {
      setSelectedAutoCountInvoice(invoice);
    } else if (invoice.workOrder) {
      setSelectedWorkOrder(invoice.workOrder);
    }
  };

  const filteredCandidates = useMemo(() => {
    const query = candidateSearch.trim().toLowerCase();
    if (!query) return candidates;
    return candidates.filter((c) =>
      [c.workOrderNo, c.companyName, c.vehicleNo, c.quotationNo || "", c.canonicalStatus]
        .some((v) => String(v || "").toLowerCase().includes(query))
    );
  }, [candidates, candidateSearch]);

  const paidRevenue = invoices.filter((invoice) => invoice.storedStatus === "paid").reduce((sum, invoice) => sum + invoice.total, 0);
  const outstanding = invoices.filter((invoice) => !["paid", "void", "draft", "pending_sync"].includes(invoice.storedStatus)).reduce((sum, invoice) => sum + invoice.balance, 0);

  const openCreate = async () => {
    setCreationMode(true);
    setCandidateOpen(true);
    setCandidateLoading(true);
    try {
      setCandidates(await apiRequest<InvoiceWorkOrder[]>("admin-invoice-work-orders"));
    } catch (caught) {
      setCandidateOpen(false);
      setCreationMode(false);
      toast.error(caught instanceof Error ? caught.message : "Unable to load invoice-ready work orders.");
    } finally {
      setCandidateLoading(false);
    }
  };

  // In-Page View: View / Edit Parts Order Invoice
  if (selectedPartsOrder) {
    return (
      <PartsOrderInvoiceDialog
        order={selectedPartsOrder}
        backLabel={creationMode ? "Back to Select Order" : "Back to Invoices"}
        onClose={() => {
          setSelectedPartsOrder(null);
          if (creationMode) {
            setCandidateOpen(true);
          }
        }}
        onChanged={async () => {
          setCreationMode(false);
          await reload();
        }}
      />
    );
  }

  // In-Page View: View / Edit Work Order Invoice
  if (selectedWorkOrder) {
    return (
      <WorkOrderInvoiceDialog
        workOrder={selectedWorkOrder}
        backLabel={creationMode ? "Back to Select Work Order" : "Back to Invoices"}
        onClose={() => {
          setSelectedWorkOrder(null);
          if (creationMode) {
            setCandidateOpen(true);
          }
        }}
        onChanged={async () => {
          setCreationMode(false);
          await reload();
        }}
      />
    );
  }

  // AutoCount Linked Invoice View
  if (selectedAutoCountInvoice) {
    return (
      <AutoCountInvoiceDialog
        invoice={selectedAutoCountInvoice}
        onClose={() => setSelectedAutoCountInvoice(null)}
      />
    );
  }

  // In-Page View: Candidate Work Orders (Step 1 of Create Invoice)
  if (candidateOpen) {
    return (
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => {
                setCandidateOpen(false);
                setCreationMode(false);
              }}
              className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 shadow-sm hover:bg-slate-50 cursor-pointer"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Invoices
            </button>
            <div>
              <h1 className="text-xl font-extrabold text-slate-900">Select Work Order to Invoice</h1>
              <p className="text-xs text-slate-500">
                Choose a completed or approved repair to generate a billing invoice
              </p>
            </div>
          </div>
        </div>

        <div className="maw-search-field">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input
            type="text"
            value={candidateSearch}
            onChange={(e) => setCandidateSearch(e.target.value)}
            placeholder="Search candidate by WO#, company, vehicle or quotation..."
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-sm"
          />
        </div>

        <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
          {candidateLoading ? (
            <div className="p-12 text-center text-sm text-slate-500">Loading work orders...</div>
          ) : filteredCandidates.length === 0 ? (
            <div className="p-12 text-center text-sm text-slate-500">
              No invoice-ready work orders available.
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {filteredCandidates.map((c) => (
                <div
                  key={c.partsOrderId || c.workOrderNo || c.id}
                  onClick={() => {
                    setCandidateOpen(false);
                    if (c.orderType === "parts_order" || c.partsOrder) {
                      setSelectedPartsOrder(c.partsOrder || {
                        id: c.workOrderNo,
                        customer: c.companyName,
                        items: [],
                        total: Number(c.quotationTotal) || 0,
                        status: "Pending",
                        orderDate: "",
                        deliveryAddress: "",
                      });
                    } else {
                      setSelectedWorkOrder(c);
                    }
                  }}
                  className="flex flex-wrap items-center justify-between gap-4 p-4 hover:bg-blue-50/50 cursor-pointer transition-colors"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-blue-900">{c.workOrderNo}</span>
                      <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-600 uppercase">
                        {c.canonicalStatus}
                      </span>
                      {c.quotationNo ? (
                        <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-700 border border-emerald-200">
                          {c.quotationNo}
                        </span>
                      ) : null}
                    </div>
                    <p className="text-xs font-semibold text-slate-700 mt-1">{c.companyName} · {c.vehicleNo}</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">{c.serviceType || "General Service"}</p>
                  </div>
                  <button
                    type="button"
                    className="inline-flex items-center gap-1.5 rounded-lg bg-[#1e3a8a] px-3.5 py-2 text-xs font-bold text-white shadow-sm hover:bg-blue-800 cursor-pointer"
                  >
                    <FilePlus2 className="h-3.5 w-3.5" />
                    Generate Invoice
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  const handleExportInvoices = async () => {
    if (filtered.length === 0) {
      toast.error("No invoices available to export.");
      return;
    }

    const columnDefs: ExcelColumnDef[] = [
      { header: "Invoice No", key: "invoiceNo", align: "left", minWidth: 18, numFmt: "@" },
      { header: "Date", key: "docDate", align: "center", minWidth: 14 },
      { header: "Due Date", key: "dueDate", align: "center", minWidth: 14 },
      { header: "Debtor Code", key: "debtorCode", align: "left", minWidth: 16, numFmt: "@" },
      { header: "Customer / Company", key: "customerName", align: "left", minWidth: 26 },
      { header: "Reference / WO No", key: "referenceNo", align: "left", minWidth: 18, numFmt: "@" },
      { header: "Vehicle Plate", key: "vehicleNo", align: "left", minWidth: 14, numFmt: "@" },
      { header: "Subtotal (RM)", key: "subtotal", align: "right", minWidth: 16, numFmt: "#,##0.00" },
      { header: "Tax (RM)", key: "taxAmount", align: "right", minWidth: 14, numFmt: "#,##0.00" },
      { header: "Total Amount (RM)", key: "total", align: "right", minWidth: 18, numFmt: "#,##0.00" },
      { header: "Paid (RM)", key: "paidAmount", align: "right", minWidth: 16, numFmt: "#,##0.00" },
      { header: "Balance (RM)", key: "balance", align: "right", minWidth: 16, numFmt: "#,##0.00" },
      { header: "Payment Status", key: "status", align: "center", minWidth: 15 },
      { header: "AutoCount Sync", key: "syncStatus", align: "center", minWidth: 16 },
    ];

    const rows = filtered.map((inv) => {
      const invNo = inv.invoiceNo || inv.docNo || `INV-${inv.id}`;
      const invDate = inv.docDate || inv.issueDate || (inv as any).date || "-";
      const debtorCode = inv.debtorCode || (inv as any).customerCode || "-";
      const custName = inv.customerName || inv.debtorName || (inv as any).companyName || inv.workOrder?.customerName || inv.workOrder?.companyName || "-";
      const refNo = inv.workOrder?.workOrderNo || (inv as any).referenceNo || "-";
      const vehicleNo = inv.workOrder?.vehicleNo || (inv as any).vehicleNo || "-";
      const subtotal = Number(inv.subtotal ?? (inv.total ? inv.total - (inv.taxAmount || 0) : 0));
      const tax = Number(inv.taxAmount ?? (inv as any).tax ?? 0);
      const total = Number(inv.total ?? inv.docAmount ?? 0);
      const balance = Number(inv.balance ?? 0);
      const paid = Number(total - balance);

      return {
        invoiceNo: String(invNo),
        docDate: String(invDate).slice(0, 10),
        dueDate: inv.dueDate ? String(inv.dueDate).slice(0, 10) : "-",
        debtorCode: String(debtorCode),
        customerName: String(custName),
        referenceNo: String(refNo),
        vehicleNo: String(vehicleNo),
        subtotal,
        taxAmount: tax,
        total,
        paidAmount: paid,
        balance,
        status: String(inv.storedStatus || inv.status || "-").toUpperCase(),
        syncStatus: inv.syncStatus ? String(inv.syncStatus).toUpperCase() : (inv.source === "autocount" ? "SYNCED" : "LOCAL"),
      };
    });

    const fileName = `maw-invoices-${activeTab}-${new Date().toISOString().slice(0, 10)}.xlsx`;
    await exportTableToExcel({
      fileName,
      sheetName: "Invoices",
      columns: columnDefs,
      data: rows,
      successMessage: `Exported ${filtered.length} invoices to ${fileName}`,
    });
  };

  // Default Invoices Table View
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-2xl font-extrabold text-slate-900">Invoice Management</h1>
            <AutoCountSyncBadge
              label="AutoCount Billing Active"
              onRefresh={() => void reload()}
              isRefreshing={isLoading}
            />
          </div>
          <p className="mt-0.5 text-xs text-slate-500">
            Create and manage work order invoices, then queue and sync to AutoCount ERP
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportInvoices}
            disabled={isLoading || filtered.length === 0}
            className="inline-flex h-10 items-center justify-center rounded-xl border border-gray-300 bg-white px-4 text-sm font-semibold text-gray-700 shadow-sm transition-colors hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50 cursor-pointer"
          >
            <Download className="mr-2 h-4 w-4" />
            Export Excel
          </button>
          {canManage ? (
            <button
              type="button"
              disabled={selectedIds.size === 0 || isBatchSyncing}
              onClick={() => void handleBatchQueueSync()}
              className={`inline-flex h-10 items-center justify-center rounded-xl px-4 text-sm font-bold shadow-sm transition-all cursor-pointer ${
                selectedIds.size > 0
                  ? "bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-700/20"
                  : "bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed opacity-60"
              }`}
            >
              <Send className="mr-2 h-4 w-4" />
              <span>Queue Sync ({selectedIds.size})</span>
            </button>
          ) : null}
          {canManage ? (
            <button
              type="button"
              onClick={() => void openCreate()}
              className="inline-flex h-10 items-center justify-center rounded-xl bg-[#1e3a8a] px-4 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-blue-800 cursor-pointer"
            >
              <FilePlus2 className="mr-2 h-4 w-4" />
              Create Invoice
            </button>
          ) : null}
        </div>
      </div>

      {error ? <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">{error}</div> : null}

      {/* Pending Sync Alert Banner */}
      {pendingCount > 0 ? (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-200 bg-amber-50/80 p-3.5 text-xs text-amber-900 shadow-sm">
          <div className="flex items-center gap-2.5">
            <span className="flex h-2.5 w-2.5 rounded-full bg-amber-500 animate-pulse" />
            <span className="font-bold">
              {pendingCount} invoice(s) are currently in Pending Sync queue and ready for AutoCount synchronization.
            </span>
          </div>
          <button
            type="button"
            onClick={() => navigate("/pending-sync-invoices")}
            className="inline-flex items-center gap-1.5 rounded-lg bg-amber-600 px-3 py-1.5 text-xs font-bold text-white shadow-sm hover:bg-amber-700 transition-colors cursor-pointer"
          >
            <span>View in Pending Sync Invoice</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
      ) : null}

      {/* KPI Stats Cards */}
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "Total invoices", value: counts.all },
          { label: "Paid", value: counts.paid },
          { label: "Outstanding", value: `RM ${money(outstanding)}` },
          { label: "Paid revenue", value: `RM ${money(paidRevenue)}` },
        ].map((item) => (
          <div key={item.label} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <p className="text-xs font-bold uppercase tracking-wide text-slate-500">{item.label}</p>
            <p className="mt-3 text-2xl font-extrabold text-slate-900">{item.value}</p>
          </div>
        ))}
      </div>

      {/* Status Category Tabs */}
      <div className="flex flex-wrap items-center gap-1.5 border-b border-slate-200 pb-2">
        {(
          [
            { id: "all", label: "All Invoices", count: counts.all },
            { id: "issued", label: "Bill Done / Issued", count: counts.issued },
            { id: "synced", label: "Synced to AutoCount", count: counts.synced, badgeColor: "bg-emerald-100 text-emerald-800" },
            { id: "unpaid", label: "Outstanding", count: counts.unpaid },
            { id: "paid", label: "Paid", count: counts.paid },
          ] as { id: TabType; label: string; count: number; badgeColor?: string }[]
        ).map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`inline-flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-bold transition-all cursor-pointer ${
                isActive
                  ? "bg-[#1e3a8a] text-white shadow-sm"
                  : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
              }`}
            >
              <span>{tab.label}</span>
              <span
                className={`rounded-full px-2 py-0.5 text-[10px] font-extrabold ${
                  isActive
                    ? "bg-white/20 text-white"
                    : tab.badgeColor || "bg-slate-100 text-slate-600"
                }`}
              >
                {tab.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Search and Secondary Filter */}
      <div className="maw-filter-bar">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="maw-search-field">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search invoice #, job #, company..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
              />
            </div>
          </div>
          <div>
            <DesktopDatePicker
              value={startDate}
              onChange={setStartDate}
              placeholder="Invoice from"
              ariaLabel="Filter from date"
              className="maw-filter-control"
            />
          </div>
          <div>
            <DesktopDatePicker
              value={endDate}
              onChange={setEndDate}
              placeholder="Invoice to"
              ariaLabel="Filter to date"
              className="maw-filter-control"
            />
          </div>
          <div>
            <AdminSelect
              value={status}
              onChange={(event) => setStatus(event.target.value)}
              className="w-full"
              aria-label="Filter invoice status"
            >
              <option value="all">All sub-statuses</option>
              <option value="draft">Draft</option>
              <option value="issued">Issued</option>
              <option value="partially_paid">Partially Paid</option>
              <option value="overdue">Overdue</option>
              <option value="paid">Paid</option>
              <option value="void">Void</option>
              <option value="expired">Expired</option>
            </AdminSelect>
          </div>
        </div>
      </div>

      {/* Invoices Table */}
      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm relative">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200">
            <thead className="bg-slate-50">
              <tr>
                <th scope="col" className="w-10 px-4 py-3 text-left">
                  <button
                    type="button"
                    onClick={toggleSelectAll}
                    className="text-slate-400 hover:text-slate-700 cursor-pointer"
                    title={isAllSyncableSelected ? "Deselect all" : "Select all syncable"}
                  >
                    {isAllSyncableSelected ? (
                      <CheckSquare className="h-4 w-4 text-blue-600" />
                    ) : (
                      <Square className="h-4 w-4" />
                    )}
                  </button>
                </th>
                {["Invoice No", "Job / Ref No.", "Bill To", "Invoice Date", "Items / Vehicle", "Invoice Amount", "Sync Status", "AutoCount Invoice No", "Action"].map((heading) => (
                  <th key={heading} className="px-4 py-3 text-left text-[11px] font-extrabold uppercase tracking-wide text-slate-500">
                    {heading}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {isLoading ? (
                <tr>
                  <td colSpan={10} className="p-12 text-center text-sm text-slate-500">
                    Loading invoices...
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={10} className="p-12 text-center">
                    <FileText className="mx-auto mb-3 h-9 w-9 text-slate-300" />
                    <p className="text-sm text-slate-500">No invoices found in this view.</p>
                  </td>
                </tr>
              ) : (
                filtered.map((invoice) => {
                  const isFailed = invoice.syncStatus === "failed";
                  const isSyncable = isInvoiceSyncable(invoice);
                  const isSelected = selectedIds.has(invoice.id);
                  return (
                    <tr
                      key={`${invoice.source || "invoice"}-${invoice.id}`}
                      onClick={() => openInvoiceDetail(invoice)}
                      className={`hover:bg-blue-50/40 transition-colors cursor-pointer ${
                        isSelected ? "bg-blue-50/50" : ""
                      }`}
                    >
                      <td className="px-4 py-4" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          disabled={!isSyncable}
                          onClick={() => toggleSelect(invoice)}
                          className={`cursor-pointer ${
                            !isSyncable
                              ? "opacity-30 cursor-not-allowed text-slate-300"
                              : isSelected
                              ? "text-blue-600"
                              : "text-slate-400 hover:text-slate-600"
                          }`}
                          title={
                            !isSyncable
                              ? "Already synced or void"
                              : isSelected
                              ? "Deselect"
                              : "Select for queue sync"
                          }
                        >
                          {isSelected ? (
                            <CheckSquare className="h-4 w-4 text-blue-600" />
                          ) : (
                            <Square className="h-4 w-4" />
                          )}
                        </button>
                      </td>
                      <td className="px-4 py-4">
                        <p className="text-sm font-extrabold text-slate-900">
                          {invoice.autocountInvoiceNo || invoice.invoiceNo || invoice.internalRef}
                        </p>
                        {invoice.autocountInvoiceNo && invoice.invoiceNo && invoice.autocountInvoiceNo !== invoice.invoiceNo ? (
                          <p className="text-[10px] text-slate-400">Ref: {invoice.invoiceNo}</p>
                        ) : null}
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span
                            className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold uppercase ${
                              invoice.source === "autocount" || invoice.syncStatus === "synced"
                                ? "border-cyan-200 bg-cyan-50 text-cyan-800"
                                : "border-indigo-200 bg-indigo-50 text-indigo-700"
                            }`}
                          >
                            <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                            {invoice.source === "autocount" ? "AutoCount" : invoice.syncStatus === "synced" ? "MAW → AutoCount" : "MAW"}
                          </span>
                          {invoice.isBackOrder ? (
                            <span className="inline-flex items-center rounded-full border border-purple-200 bg-purple-50 px-2.5 py-1 text-xs font-semibold text-purple-700 whitespace-nowrap">
                              <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                              Back Order
                            </span>
                          ) : null}
                        </div>
                        <p className="mt-1 text-xs font-bold text-blue-700">{invoice.autocountJobNo || invoice.workOrder.workOrderNo}</p>
                      </td>
                      <td className="px-4 py-4">
                        <p className="text-sm font-semibold text-slate-800">{invoice.workOrder.companyName}</p>
                        <p className="text-xs text-slate-500">{invoice.vehicleNoRaw || invoice.vehicleNo || invoice.workOrder.vehicleNo}</p>
                      </td>
                      <td className="px-4 py-4 text-xs text-slate-600">
                        <p className="font-semibold">{invoice.invoiceDate}</p>
                        {invoice.dueDate ? (
                          <p className="text-[10px] text-slate-400">Due: {invoice.dueDate}</p>
                        ) : null}
                      </td>
                      <td className="px-4 py-4 text-sm font-bold text-slate-900">RM {money(invoice.total)}</td>
                      <td className="px-4 py-4 text-sm font-bold text-slate-900">RM {money(invoice.balance)}</td>
                      <td className="px-4 py-4">
                        <div>
                          {invoice.storedStatus === "paid" || invoice.status === "paid" ? (
                            <span className="inline-flex items-center rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700 whitespace-nowrap">
                              <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" /> Paid
                            </span>
                          ) : invoice.storedStatus === "void" || invoice.status === "void" ? (
                            <span className="inline-flex items-center rounded-full border border-rose-200 bg-rose-50 px-2.5 py-1 text-xs font-semibold text-rose-700 whitespace-nowrap">
                              <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" /> Void
                            </span>
                          ) : invoice.syncStatus === "synced" || invoice.source === "autocount" ? (
                            <span className="inline-flex items-center rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700 whitespace-nowrap">
                              <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" /> Synced
                            </span>
                          ) : (
                            <span className="inline-flex items-center rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs font-semibold text-slate-600 whitespace-nowrap">
                              <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" /> Not Queued
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-4 text-xs font-semibold text-slate-700">
                        <p>{invoice.autocountInvoiceNo || "—"}</p>
                      </td>
                      <td className="px-4 py-4" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              openInvoiceDetail(invoice);
                            }}
                            className="rounded-lg p-1.5 text-blue-700 hover:bg-blue-50 cursor-pointer"
                            aria-label={`View ${invoice.invoiceNo}`}
                            title="View Details"
                          >
                            <Eye className="h-4 w-4" />
                          </button>
                          {canManage && invoice.source !== "autocount" ? (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                openInvoiceDetail(invoice);
                              }}
                              className="rounded-lg p-1.5 text-slate-600 hover:bg-slate-100 cursor-pointer"
                              aria-label={`Edit ${invoice.invoiceNo}`}
                              title="Edit Invoice"
                            >
                              <Edit className="h-4 w-4" />
                            </button>
                          ) : null}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
