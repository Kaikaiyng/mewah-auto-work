import { useState, useMemo } from "react";
import { useNavigate } from "react-router";
import {
  Search,
  Eye,
  Edit,
  Phone,
  Mail,
  X,
  MapPin,
  Users,
  Truck,
  ArrowRight,
  Building2,
  Save,
  Database,
  CheckCircle2,
  Landmark,
  CreditCard,
  Download,
} from "lucide-react";
import { useLanguage } from "../contexts/language-context";
import { postApi } from "../lib/api";
import { EMAIL_PLACEHOLDER, isValidEmail, normalizeEmail } from "../lib/email";
import {
  formatMalaysiaPhone,
  formatMalaysiaPhoneInput,
  isValidMalaysiaPhone,
  MALAYSIA_PHONE_PLACEHOLDER,
  normalizeMalaysiaPhone,
} from "../lib/malaysia-phone";
import { useApiData } from "../lib/use-api-data";
import { hasAdminPermission } from "../lib/admin-permissions";
import { adminFieldClass, adminLabelClass, adminTextareaClass } from "./ui/admin-form-dialog";
import { AutoCountSyncBadge } from "./autocount-sync-badge";
import { AdminSelect } from "./ui/admin-select";
import { exportTableToExcel, ExcelColumnDef } from "../lib/excel-export";
import { toast } from "sonner";

type Company = {
  id: number | null;
  name: string;
  phone: string;
  email: string;
  address: string;
  autocountDebtorCode: string;
  registrationNo?: string;
  term?: string;
  creditLimit?: number;
  currency?: string;
  debtorActive?: boolean;
  vehicles: number;
  customers: number;
};

type CompanyForm = {
  name: string;
  phone: string;
  email: string;
  address: string;
  autocountDebtorCode: string;
};

type CompanyUser = {
  id: number;
  name: string;
  email: string;
  phone: string;
  status: string;
  companyId?: number;
  vehicles?: number;
};

type CompanyVehicle = {
  id: number;
  regNo: string;
  equipment: string;
  brand: string;
  model: string;
  vehicleStatus?: string;
  verificationStatus?: string;
  companyId?: number;
};

const emptyCompanyForm: CompanyForm = {
  name: "",
  phone: "",
  email: "",
  address: "",
  autocountDebtorCode: "",
};

function displayMoney(value?: number, currency = "MYR") {
  return new Intl.NumberFormat("en-MY", {
    style: "currency",
    currency: currency || "MYR",
    maximumFractionDigits: 2,
  }).format(value || 0);
}

export function Companies() {
  const navigate = useNavigate();
  const canViewUsers = hasAdminPermission("customer.view");
  const canUpdateUsers = hasAdminPermission("customer.update");
  const canViewVehicles = hasAdminPermission("vehicle.view");
  const canUpdate = hasAdminPermission("company.update");
  const { t } = useLanguage();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "linked" | "unlinked" | "with_vehicles">("all");
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);
  const [modalMode, setModalMode] = useState<"view" | "edit" | null>(null);
  const [form, setForm] = useState<CompanyForm>(emptyCompanyForm);
  const [isSaving, setIsSaving] = useState(false);
  const [formError, setFormError] = useState("");

  const { data: companiesData, isLoading, error, reload, hasLoaded } = useApiData<Company[]>("admin-companies", []);
  const {
    data: usersData,
    isLoading: areUsersLoading,
    error: usersError,
  } = useApiData<CompanyUser[]>("admin-customers", []);
  const {
    data: vehiclesData,
    isLoading: areVehiclesLoading,
    error: vehiclesError,
  } = useApiData<CompanyVehicle[]>("admin-vehicles", []);

  const companies = useMemo(() => {
    if (isLoading && !hasLoaded) return [];
    return companiesData || [];
  }, [companiesData, isLoading, hasLoaded]);

  const activeLinkedCount = useMemo(
    () => companies.filter((c) => Boolean(c.autocountDebtorCode)).length,
    [companies],
  );
  const totalVehiclesCount = useMemo(
    () => companies.reduce((acc, c) => acc + (c.vehicles || 0), 0),
    [companies],
  );
  const totalUsersCount = useMemo(
    () => companies.reduce((acc, c) => acc + (c.customers || 0), 0),
    [companies],
  );

  const openEditModal = (company: Company) => {
    setSelectedCompany(company);
    setForm({
      name: company.name,
      phone: company.phone === "-" ? "" : formatMalaysiaPhone(company.phone),
      email: company.email === "-" ? "" : normalizeEmail(company.email),
      address: company.address === "-" ? "" : company.address,
      autocountDebtorCode: company.autocountDebtorCode || "",
    });
    setFormError("");
    setModalMode("edit");
  };

  const openViewModal = (company: Company) => {
    setSelectedCompany(company);
    setModalMode("view");
  };

  const closeModal = () => {
    setSelectedCompany(null);
    setModalMode(null);
    setForm(emptyCompanyForm);
    setFormError("");
  };

  const handleSubmitCompany = async () => {
    setFormError("");

    if (!form.name.trim()) {
      setFormError("Company name is required.");
      return;
    }

    if (form.phone.trim() && !isValidMalaysiaPhone(form.phone)) {
      setFormError("Enter a valid Malaysia mobile or landline number.");
      return;
    }

    if (form.email.trim() && !isValidEmail(form.email)) {
      setFormError("Enter a valid email address, for example name@example.com.");
      return;
    }

    setIsSaving(true);
    try {
      await postApi("admin-update-company", {
        id: selectedCompany?.id,
        name: form.name.trim(),
        phone: form.phone.trim() ? normalizeMalaysiaPhone(form.phone)! : "",
        email: form.email.trim() ? normalizeEmail(form.email) : "",
        address: form.address.trim(),
        autocountDebtorCode: form.autocountDebtorCode.trim().toUpperCase(),
      });
      await reload();
      closeModal();
    } catch (apiError) {
      setFormError(apiError instanceof Error ? apiError.message : "Unable to save company.");
    } finally {
      setIsSaving(false);
    }
  };

  const filteredCompanies = useMemo(() => {
    const needle = searchTerm.trim().toLowerCase();
    return companies.filter((company) => {
      if (statusFilter === "linked" && !company.autocountDebtorCode) return false;
      if (statusFilter === "unlinked" && company.autocountDebtorCode) return false;
      if (statusFilter === "with_vehicles" && (!company.vehicles || company.vehicles === 0)) return false;

      if (!needle) return true;
      return (
        company.name.toLowerCase().includes(needle) ||
        (company.autocountDebtorCode && company.autocountDebtorCode.toLowerCase().includes(needle)) ||
        (company.registrationNo && company.registrationNo.toLowerCase().includes(needle)) ||
        company.email.toLowerCase().includes(needle) ||
        company.phone.includes(needle) ||
        company.address.toLowerCase().includes(needle)
      );
    });
  }, [companies, searchTerm, statusFilter]);

  const selectedCompanyUsers = useMemo(
    () => (selectedCompany ? usersData.filter((user) => Number(user.companyId) === selectedCompany.id) : []),
    [usersData, selectedCompany],
  );

  const selectedCompanyVehicles = useMemo(
    () => (selectedCompany ? vehiclesData.filter((vehicle) => Number(vehicle.companyId) === selectedCompany.id) : []),
    [vehiclesData, selectedCompany],
  );

  const openCompanyUsers = () => {
    if (!selectedCompany) return;
    closeModal();
    navigate(`/customers?companyId=${selectedCompany.id}`);
  };

  const openCompanyVehicles = () => {
    if (!selectedCompany) return;
    closeModal();
    navigate(`/equipment?companyId=${selectedCompany.id}`);
  };

  const openCompanyUserDetail = (userId: number) => {
    if (!selectedCompany) return;
    navigate(`/customers?companyId=${selectedCompany.id}&userId=${userId}`);
  };

  const openCompanyUserEdit = (userId: number) => {
    if (!selectedCompany) return;
    navigate(`/customers?companyId=${selectedCompany.id}&editUserId=${userId}`);
  };

  const openCompanyVehicleDetail = (vehicleId: number) => {
    if (!selectedCompany) return;
    navigate(`/equipment?companyId=${selectedCompany.id}&vehicleId=${vehicleId}`);
  };

  const handleExportCompanies = async () => {
    if (filteredCompanies.length === 0) {
      toast.error("No companies available to export.");
      return;
    }

    const columnDefs: ExcelColumnDef[] = [
      { header: "Company Name", key: "name", align: "left", minWidth: 28 },
      { header: "AutoCount Debtor Code", key: "autocountDebtorCode", align: "left", minWidth: 20, numFmt: "@" },
      { header: "Registration No", key: "registrationNo", align: "left", minWidth: 18, numFmt: "@" },
      { header: "Contact Phone", key: "phone", align: "left", minWidth: 18, numFmt: "@" },
      { header: "Email Address", key: "email", align: "left", minWidth: 26 },
      { header: "Billing Address", key: "address", align: "left", minWidth: 36 },
      { header: "Credit Terms", key: "term", align: "center", minWidth: 14 },
      { header: "Credit Limit (RM)", key: "creditLimit", align: "right", minWidth: 18, numFmt: "#,##0.00" },
      { header: "Fleet Vehicles Count", key: "vehicles", align: "right", minWidth: 18, numFmt: "#,##0" },
      { header: "Users Count", key: "customers", align: "right", minWidth: 14, numFmt: "#,##0" },
      { header: "AutoCount Status", key: "status", align: "center", minWidth: 16 },
    ];

    const rows = filteredCompanies.map((c) => ({
      name: String(c.name || "-"),
      autocountDebtorCode: String(c.autocountDebtorCode || "-"),
      registrationNo: String(c.registrationNo || "-"),
      phone: String(c.phone || "-"),
      email: String(c.email || "-"),
      address: String(c.address || "-"),
      term: String(c.term || "-"),
      creditLimit: Number(c.creditLimit || 0),
      vehicles: Number(c.vehicles || 0),
      customers: Number(c.customers || 0),
      status: c.autocountDebtorCode ? "LINKED (AUTOCONT)" : "UNLINKED",
    }));

    const fileName = `maw-companies-debtors-${new Date().toISOString().slice(0, 10)}.xlsx`;
    await exportTableToExcel({
      fileName,
      sheetName: "Companies & Debtors",
      columns: columnDefs,
      data: rows,
      successMessage: `Exported ${filteredCompanies.length} companies to ${fileName}`,
    });
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-2xl font-extrabold text-slate-900">Companies & Debtors</h1>
            <AutoCountSyncBadge
              label="AutoCount Debtor / Master Entity"
              onRefresh={() => void reload()}
              isRefreshing={isLoading}
            />
          </div>
          <p className="mt-0.5 text-xs text-slate-500">
            Unified AutoCount debtor financial accounts and workshop fleet organization management.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCompanies}
            disabled={isLoading || filteredCompanies.length === 0}
            className="inline-flex h-10 items-center justify-center rounded-xl border border-gray-300 bg-white px-4 text-sm font-semibold text-gray-700 shadow-sm transition-colors hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Download className="mr-2 h-4 w-4" />
            Export Excel
          </button>
        </div>
      </div>

      {error ? (
        <div className="rounded-lg border border-yellow-200 bg-yellow-50 px-4 py-3 text-sm text-yellow-800">
          Database data unavailable: {error}.
        </div>
      ) : null}

      {/* KPI Metrics */}
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
          <Building2 className="h-5 w-5 text-blue-600" />
          <p className="mt-3 text-xs font-semibold uppercase tracking-wide text-gray-500">Total Companies</p>
          <p className="mt-1 text-2xl font-bold text-gray-900">{companies.length}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
          <Landmark className="h-5 w-5 text-emerald-600" />
          <p className="mt-3 text-xs font-semibold uppercase tracking-wide text-gray-500">AutoCount Linked Debtors</p>
          <p className="mt-1 text-2xl font-bold text-gray-900">{activeLinkedCount}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
          <Truck className="h-5 w-5 text-indigo-600" />
          <p className="mt-3 text-xs font-semibold uppercase tracking-wide text-gray-500">Total Fleet Vehicles</p>
          <p className="mt-1 text-2xl font-bold text-gray-900">{totalVehiclesCount}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
          <Users className="h-5 w-5 text-purple-600" />
          <p className="mt-3 text-xs font-semibold uppercase tracking-wide text-gray-500">Total App Users</p>
          <p className="mt-1 text-2xl font-bold text-gray-900">{totalUsersCount}</p>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="maw-filter-bar">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
          <div className="md:col-span-2">
            <div className="maw-search-field">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search company name, AutoCount debtor code, registration no, phone or address..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
              />
            </div>
          </div>
          <div>
            <AdminSelect
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)}
              className="w-full"
              aria-label="Filter companies"
            >
              <option value="all">All Companies</option>
              <option value="linked">Linked to AutoCount</option>
              <option value="unlinked">Not Linked</option>
              <option value="with_vehicles">With Fleet Vehicles</option>
            </AdminSelect>
          </div>
        </div>
      </div>

      {/* Main Unified Table */}
      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Company / AutoCount Debtor
                </th>
                <th scope="col" className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Contact
                </th>
                <th scope="col" className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Terms / Credit Limit
                </th>
                <th scope="col" className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Fleet & Users
                </th>
                <th scope="col" className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">
                  AutoCount Status
                </th>
                <th scope="col" className="relative px-5 py-3 text-right">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 bg-white">
              {isLoading && companies.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-12 text-center text-sm text-gray-500">
                    Loading companies & debtors…
                  </td>
                </tr>
              ) : filteredCompanies.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-12 text-center text-sm text-gray-500">
                    No companies match the current filter criteria.
                  </td>
                </tr>
              ) : (
                filteredCompanies.map((company) => (
                  <tr key={company.id ? `c-${company.id}` : `d-${company.autocountDebtorCode}`} className="transition-colors hover:bg-gray-50 [content-visibility:auto]">
                    {/* Company & AutoCount Debtor */}
                    <td className="px-5 py-4">
                      <p className="font-semibold text-gray-900">{company.name}</p>
                      <div className="mt-1 flex flex-wrap items-center gap-1.5">
                        {company.autocountDebtorCode ? (
                          <span className="rounded bg-blue-50 px-1.5 py-0.5 font-mono text-xs font-bold text-blue-700">
                            {company.autocountDebtorCode}
                          </span>
                        ) : (
                          <span className="rounded bg-gray-100 px-1.5 py-0.5 text-xs text-gray-500">
                            No Debtor Code
                          </span>
                        )}
                        {company.registrationNo ? (
                          <span className="text-xs text-gray-500">Reg: {company.registrationNo}</span>
                        ) : null}
                      </div>
                    </td>

                    {/* Contact */}
                    <td className="px-5 py-4 text-sm text-gray-600">
                      {company.phone && company.phone !== "-" ? (
                        <p className="flex items-center gap-1.5">
                          <Phone className="h-3.5 w-3.5 text-gray-400" />
                          {formatMalaysiaPhone(company.phone)}
                        </p>
                      ) : null}
                      {company.email && company.email !== "-" ? (
                        <p className="mt-1 flex items-center gap-1.5 text-xs text-gray-500">
                          <Mail className="h-3.5 w-3.5 text-gray-400" />
                          {company.email}
                        </p>
                      ) : null}
                      {(!company.phone || company.phone === "-") && (!company.email || company.email === "-") ? (
                        <span className="text-xs text-gray-400">—</span>
                      ) : null}
                    </td>

                    {/* Terms & Credit */}
                    <td className="px-5 py-4 text-sm text-gray-700">
                      <p className="font-medium text-gray-900">{company.term || "No term"}</p>
                      <p className="mt-0.5 text-xs text-gray-500">
                        {displayMoney(company.creditLimit, company.currency)}
                      </p>
                    </td>

                    {/* Fleet & Users */}
                    <td className="px-5 py-4 text-sm">
                      <div className="flex items-center gap-3 text-xs text-gray-700">
                        <span className="flex items-center gap-1 font-semibold" title="Fleet Vehicles">
                          <Truck className="h-3.5 w-3.5 text-indigo-600" />
                          {company.vehicles || 0}
                        </span>
                        <span className="flex items-center gap-1 font-semibold" title="App Users">
                          <Users className="h-3.5 w-3.5 text-purple-600" />
                          {company.customers || 0}
                        </span>
                      </div>
                    </td>

                    {/* AutoCount Status */}
                    <td className="px-5 py-4">
                      {company.autocountDebtorCode ? (
                        <span
                          className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold ${
                            company.debtorActive === false
                              ? "border-slate-200 bg-slate-50 text-slate-600"
                              : "border-emerald-200 bg-emerald-50 text-emerald-700"
                          }`}
                        >
                          <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                          {company.debtorActive === false ? "Inactive" : "Active Debtor"}
                        </span>
                      ) : (
                        <span className="inline-flex items-center rounded-full border border-amber-200 bg-amber-50 px-2.5 py-0.5 text-xs font-semibold text-amber-700">
                          <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                          Unlinked
                        </span>
                      )}
                    </td>

                    {/* Actions */}
                    <td className="whitespace-nowrap px-5 py-4 text-right text-sm font-medium">
                      <div className="flex items-center justify-end space-x-2">
                        <button
                          type="button"
                          onClick={() => openViewModal(company)}
                          className="rounded-lg p-2 text-gray-500 transition-colors hover:bg-blue-50 hover:text-blue-700"
                          title="View 360° Company & Debtor Profile"
                          aria-label={`View ${company.name}`}
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                        {canUpdate ? (
                          <button
                            type="button"
                            onClick={() => openEditModal(company)}
                            className="rounded-lg p-2 text-gray-500 transition-colors hover:bg-gray-100 hover:text-gray-900"
                            title={t("edit")}
                            aria-label={`Edit ${company.name}`}
                          >
                            <Edit className="h-4 w-4" />
                          </button>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        <div className="border-t border-gray-200 bg-gray-50/70 px-5 py-3 text-xs text-gray-500">
          Showing {filteredCompanies.length} of {companies.length} companies & debtors
        </div>
      </div>

      {/* 360° Profile & Edit Modal */}
      {modalMode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-3 backdrop-blur-sm transition-opacity sm:p-5">
          <div
            className={`flex max-h-[94vh] w-full flex-col overflow-hidden rounded-2xl border border-white/70 bg-white shadow-2xl animate-in fade-in zoom-in-95 duration-150 ${
              modalMode === "view" ? "max-w-4xl" : "max-w-2xl"
            }`}
          >
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 bg-white px-5 py-4 sm:px-7 sm:py-5">
              <div className="flex min-w-0 items-start gap-3.5">
                <div className="mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-[#1e3a8a] ring-1 ring-blue-100">
                  <Building2 className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="text-lg font-bold tracking-tight text-slate-900 sm:text-xl">
                    {modalMode === "view" ? selectedCompany?.name : "Edit Company Profile"}
                  </h2>
                  <p className="mt-0.5 text-xs text-slate-500">
                    {modalMode === "view"
                      ? "360° AutoCount Debtor master, fleet vehicles and app user overview."
                      : "Maintain company operational contact and AutoCount Debtor link."}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={closeModal}
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700"
                aria-label="Close dialog"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className={`flex-1 overflow-y-auto p-4 sm:p-6 ${modalMode === "view" ? "bg-slate-50/50" : "bg-slate-50/80"}`}>
              {formError && (
                <div className="mb-4 rounded-lg border border-red-200 bg-red-50 p-3 text-sm font-medium text-red-600">
                  {formError}
                </div>
              )}

              {modalMode === "view" && selectedCompany ? (
                <div className="space-y-6">
                  {/* Financial & Account Overview Card */}
                  <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-xs space-y-4">
                    <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                      <div className="flex items-center gap-2">
                        <Landmark className="h-4 w-4 text-[#1e3a8a]" />
                        <h3 className="text-sm font-bold text-gray-900">AutoCount Debtor & Financial Terms</h3>
                      </div>
                      {selectedCompany.autocountDebtorCode ? (
                        <span className="rounded-full bg-emerald-50 px-2.5 py-0.5 text-xs font-bold text-emerald-700 border border-emerald-200">
                          Linked Debtor
                        </span>
                      ) : (
                        <span className="rounded-full bg-amber-50 px-2.5 py-0.5 text-xs font-bold text-amber-700 border border-amber-200">
                          Unlinked
                        </span>
                      )}
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-xs md:grid-cols-4">
                      <div>
                        <span className="text-gray-500 font-semibold uppercase">Debtor Code</span>
                        <p className="mt-1 font-mono text-sm font-bold text-blue-700">
                          {selectedCompany.autocountDebtorCode || "—"}
                        </p>
                      </div>
                      <div>
                        <span className="text-gray-500 font-semibold uppercase">Registration No.</span>
                        <p className="mt-1 font-medium text-gray-900">{selectedCompany.registrationNo || "—"}</p>
                      </div>
                      <div>
                        <span className="text-gray-500 font-semibold uppercase">Payment Terms</span>
                        <p className="mt-1 font-medium text-gray-900">{selectedCompany.term || "No term set"}</p>
                      </div>
                      <div>
                        <span className="text-gray-500 font-semibold uppercase">Credit Limit</span>
                        <p className="mt-1 font-bold text-emerald-700">
                          {displayMoney(selectedCompany.creditLimit, selectedCompany.currency)}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Operational Contact */}
                  <div className="grid grid-cols-1 gap-4 rounded-xl border border-gray-200 bg-white p-4 shadow-xs md:grid-cols-3">
                    <div>
                      <span className="block text-xs font-semibold uppercase tracking-wider text-gray-500">Phone</span>
                      <span className="mt-1 flex items-center text-sm text-gray-900">
                        <Phone className="mr-2 h-4 w-4 text-gray-400" />
                        {selectedCompany.phone && selectedCompany.phone !== "-"
                          ? formatMalaysiaPhone(selectedCompany.phone)
                          : "—"}
                      </span>
                    </div>
                    <div>
                      <span className="block text-xs font-semibold uppercase tracking-wider text-gray-500">Email</span>
                      <span className="mt-1 flex items-center text-sm text-gray-900">
                        <Mail className="mr-2 h-4 w-4 text-gray-400" />
                        {selectedCompany.email && selectedCompany.email !== "-" ? selectedCompany.email : "—"}
                      </span>
                    </div>
                    <div>
                      <span className="block text-xs font-semibold uppercase tracking-wider text-gray-500">Billing Address</span>
                      <span className="mt-1 flex items-start text-sm text-gray-900">
                        <MapPin className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-gray-400" />
                        <span>{selectedCompany.address && selectedCompany.address !== "-" ? selectedCompany.address : "—"}</span>
                      </span>
                    </div>
                  </div>

                  {usersError || vehiclesError ? (
                    <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                      Some related records could not be loaded. {usersError || vehiclesError}
                    </div>
                  ) : null}

                  {/* Users and Vehicles Side-by-Side Table Views */}
                  <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
                    {/* Users Table */}
                    <section className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-xs" aria-labelledby="company-users-title">
                      <div className="flex items-center justify-between border-b border-gray-200 bg-gray-50 px-4 py-3">
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-[#1e3a8a]" />
                          <h3 id="company-users-title" className="text-sm font-semibold text-gray-900">
                            Company Users ({selectedCompanyUsers.length})
                          </h3>
                        </div>
                        {canViewUsers ? (
                          <button
                            type="button"
                            onClick={openCompanyUsers}
                            className="inline-flex items-center gap-1 text-xs font-semibold text-[#1e3a8a] hover:text-blue-700"
                          >
                            View all <ArrowRight className="h-3.5 w-3.5" />
                          </button>
                        ) : null}
                      </div>
                      <div className="max-h-72 overflow-y-auto">
                        {areUsersLoading ? (
                          <p className="px-4 py-8 text-center text-sm text-gray-500">Loading company users...</p>
                        ) : selectedCompanyUsers.length === 0 ? (
                          <p className="px-4 py-8 text-center text-sm text-gray-500">No app users under this company.</p>
                        ) : (
                          <table className="min-w-full divide-y divide-gray-200 text-left text-xs">
                            <thead className="sticky top-0 bg-gray-50 text-[11px] font-semibold uppercase text-gray-500">
                              <tr>
                                <th className="px-4 py-2.5">User</th>
                                <th className="px-3 py-2.5">Status</th>
                                <th className="px-3 py-2.5 text-center">Vehicles</th>
                                <th className="px-3 py-2.5 text-right">Actions</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100 bg-white">
                              {selectedCompanyUsers.map((user) => (
                                <tr key={user.id} className="transition-colors hover:bg-gray-50/80">
                                  <td className="px-4 py-3">
                                    <p className="font-semibold text-gray-900">{user.name}</p>
                                    <p className="text-[11px] text-gray-500">{user.email || user.phone || "—"}</p>
                                  </td>
                                  <td className="px-3 py-3">
                                    <span
                                      className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold ${
                                        user.status === "Inactive"
                                          ? "border-slate-200 bg-slate-50 text-slate-600"
                                          : "border-emerald-200 bg-emerald-50 text-emerald-700"
                                      }`}
                                    >
                                      <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                                      {user.status || "Active"}
                                    </span>
                                  </td>
                                  <td className="px-3 py-3 text-center font-medium text-gray-700">
                                    {user.vehicles || 0}
                                  </td>
                                  <td className="px-3 py-3 text-right">
                                    <div className="flex items-center justify-end gap-1">
                                      {canViewUsers ? (
                                        <button
                                          type="button"
                                          onClick={() => openCompanyUserDetail(user.id)}
                                          className="rounded-lg p-1.5 text-gray-400 hover:bg-blue-50 hover:text-[#1e3a8a]"
                                          title={`View ${user.name}`}
                                          aria-label={`View company user ${user.name}`}
                                        >
                                          <Eye className="h-4 w-4" />
                                        </button>
                                      ) : null}
                                      {canUpdateUsers ? (
                                        <button
                                          type="button"
                                          onClick={() => openCompanyUserEdit(user.id)}
                                          className="inline-flex items-center gap-1 rounded-lg border border-gray-200 px-2 py-1 text-xs font-semibold text-gray-600 hover:border-blue-200 hover:bg-blue-50 hover:text-[#1e3a8a]"
                                          title={`Edit ${user.name}`}
                                          aria-label={`Edit company user ${user.name}`}
                                        >
                                          <Edit className="h-3.5 w-3.5" /> Edit
                                        </button>
                                      ) : null}
                                    </div>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        )}
                      </div>
                    </section>

                    {/* Vehicles Table */}
                    <section className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-xs" aria-labelledby="company-vehicles-title">
                      <div className="flex items-center justify-between border-b border-gray-200 bg-gray-50 px-4 py-3">
                        <div className="flex items-center gap-2">
                          <Truck className="h-4 w-4 text-[#1e3a8a]" />
                          <h3 id="company-vehicles-title" className="text-sm font-semibold text-gray-900">
                            Vehicles ({selectedCompanyVehicles.length})
                          </h3>
                        </div>
                        {canViewVehicles ? (
                          <button
                            type="button"
                            onClick={openCompanyVehicles}
                            className="inline-flex items-center gap-1 text-xs font-semibold text-[#1e3a8a] hover:text-blue-700"
                          >
                            View all <ArrowRight className="h-3.5 w-3.5" />
                          </button>
                        ) : null}
                      </div>
                      <div className="max-h-72 overflow-y-auto">
                        {areVehiclesLoading ? (
                          <p className="px-4 py-8 text-center text-sm text-gray-500">Loading vehicles...</p>
                        ) : selectedCompanyVehicles.length === 0 ? (
                          <p className="px-4 py-8 text-center text-sm text-gray-500">No vehicles under this company.</p>
                        ) : (
                          <table className="min-w-full divide-y divide-gray-200 text-left text-xs">
                            <thead className="sticky top-0 bg-gray-50 text-[11px] font-semibold uppercase text-gray-500">
                              <tr>
                                <th className="px-4 py-2.5">Reg No / Model</th>
                                <th className="px-3 py-2.5">Status</th>
                                <th className="px-3 py-2.5 text-right">Actions</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100 bg-white">
                              {selectedCompanyVehicles.map((vehicle) => (
                                <tr key={vehicle.id} className="transition-colors hover:bg-gray-50/80">
                                  <td className="px-4 py-3">
                                    <p className="font-semibold text-gray-900">{vehicle.regNo || "-"}</p>
                                    <p className="text-[11px] text-gray-500">
                                      {[vehicle.brand, vehicle.model].filter(Boolean).join(" ") || vehicle.equipment || "-"}
                                    </p>
                                  </td>
                                  <td className="px-3 py-3">
                                    <span className="inline-flex items-center rounded-full border border-sky-200 bg-sky-50 px-2.5 py-0.5 text-xs font-semibold text-sky-700">
                                      <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                                      {vehicle.vehicleStatus || "Active"}
                                    </span>
                                  </td>
                                  <td className="px-3 py-3 text-right">
                                    {canViewVehicles ? (
                                      <button
                                        type="button"
                                        onClick={() => openCompanyVehicleDetail(vehicle.id)}
                                        className="rounded-lg p-1.5 text-gray-400 hover:bg-blue-50 hover:text-[#1e3a8a]"
                                        title={`View ${vehicle.regNo || "vehicle"}`}
                                        aria-label={`View vehicle ${vehicle.regNo || vehicle.id}`}
                                      >
                                        <Eye className="h-4 w-4" />
                                      </button>
                                    ) : null}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        )}
                      </div>
                    </section>
                  </div>
                </div>
              ) : (
                /* Edit Form */
                <div className="space-y-4">
                  <div className="flex items-start gap-2.5 rounded-xl border border-blue-200 bg-blue-50/70 p-3.5 text-xs text-slate-700">
                    <Database className="mt-0.5 h-4 w-4 shrink-0 text-[#1e3a8a]" />
                    <div>
                      <strong className="text-slate-900">AutoCount Master Entity:</strong> Company legal name and AutoCount Debtor Code are synchronized directly from AutoCount. Operational phone, email, and billing/service address can be maintained here.
                    </div>
                  </div>
                  <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                    <div className="flex items-start gap-3 border-b border-slate-100 px-4 py-3.5 sm:px-5">
                      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-blue-50 text-blue-700">
                        <Building2 className="h-4 w-4" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-slate-900">Company & Debtor Profile</h3>
                        <p className="mt-0.5 text-xs text-slate-500">AutoCount master account and primary contact details.</p>
                      </div>
                    </div>
                    <div className="grid gap-4 p-4 sm:p-5 md:grid-cols-2">
                      <div>
                        <label htmlFor="company-name" className={adminLabelClass}>
                          Company Name
                        </label>
                        <input
                          id="company-name"
                          type="text"
                          value={form.name}
                          disabled
                          className={`${adminFieldClass} cursor-not-allowed bg-slate-100 text-slate-600`}
                        />
                      </div>
                      <div>
                        <label htmlFor="company-autocount-code" className={adminLabelClass}>
                          AutoCount Debtor Code
                        </label>
                        <input
                          id="company-autocount-code"
                          value={form.autocountDebtorCode}
                          disabled
                          className={`${adminFieldClass} cursor-not-allowed bg-slate-100 font-mono uppercase text-slate-600`}
                        />
                      </div>
                      <div>
                        <label htmlFor="company-phone" className={adminLabelClass}>
                          Phone
                        </label>
                        <input
                          id="company-phone"
                          type="tel"
                          inputMode="tel"
                          autoComplete="tel"
                          value={form.phone}
                          onChange={(e) => setForm({ ...form, phone: formatMalaysiaPhoneInput(e.target.value) })}
                          placeholder={MALAYSIA_PHONE_PLACEHOLDER}
                          maxLength={18}
                          className={adminFieldClass}
                        />
                        <p className="mt-1 text-xs text-gray-500">Mobile: +60 12-345 6789 · Landline: +60 3-1234 5678</p>
                      </div>
                      <div>
                        <label htmlFor="company-email" className={adminLabelClass}>
                          Email
                        </label>
                        <input
                          id="company-email"
                          type="email"
                          inputMode="email"
                          autoComplete="email"
                          autoCapitalize="none"
                          spellCheck={false}
                          value={form.email}
                          onChange={(e) => {
                            setForm({ ...form, email: e.target.value });
                            setFormError("");
                          }}
                          onBlur={() => setForm({ ...form, email: normalizeEmail(form.email) })}
                          placeholder={EMAIL_PLACEHOLDER}
                          maxLength={254}
                          className={adminFieldClass}
                        />
                      </div>
                      <div className="md:col-span-2">
                        <label htmlFor="company-address" className={adminLabelClass}>
                          Address
                        </label>
                        <textarea
                          id="company-address"
                          value={form.address}
                          onChange={(e) => setForm({ ...form, address: e.target.value })}
                          placeholder="Full company address..."
                          rows={3}
                          className={adminTextareaClass}
                        />
                      </div>
                    </div>
                  </section>
                </div>
              )}
            </div>

            <div className="flex flex-col-reverse gap-3 border-t border-slate-200 bg-white px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between sm:px-7">
              <p className="text-xs text-slate-500">
                {modalMode !== "view" ? (
                  <>
                    <span className="font-bold text-red-500">*</span> Required fields must be completed
                  </>
                ) : null}
              </p>
              <div className="flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={closeModal}
                  className="h-10 rounded-lg border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-700 transition-colors hover:bg-slate-50"
                >
                  {modalMode === "view" ? "Close" : "Cancel"}
                </button>
                {modalMode !== "view" && (
                  <button
                    type="button"
                    disabled={isSaving}
                    onClick={handleSubmitCompany}
                    className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-[#1e3a8a] px-5 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-blue-800 disabled:opacity-50"
                  >
                    <Save className="h-4 w-4" />
                    {isSaving ? "Saving..." : "Save changes"}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
