import { useState } from "react";
import { Check, Clock3 } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "./popover";
import { cn } from "./utils";

type DesktopTimePickerProps = {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
  required?: boolean;
  ariaLabel?: string;
  disabled?: boolean;
};

function normaliseTime(value: string) {
  const match = /^(\d{2}):(\d{2})/.exec(value);
  if (!match) return { hour: "09", minute: "00" };
  return { hour: match[1], minute: match[2] };
}

function displayTime(value: string) {
  const match = /^(\d{2}):(\d{2})/.exec(value);
  if (!match) return "";
  const hour = Number(match[1]);
  const suffix = hour >= 12 ? "PM" : "AM";
  return `${String(hour % 12 || 12).padStart(2, "0")}:${match[2]} ${suffix}`;
}

const hours = Array.from({ length: 24 }, (_, index) => String(index).padStart(2, "0"));
const minutes = Array.from({ length: 60 }, (_, index) => String(index).padStart(2, "0"));

export function DesktopTimePicker({
  value,
  onChange,
  placeholder = "Select time",
  className,
  required = false,
  ariaLabel = "Choose time",
  disabled = false,
}: DesktopTimePickerProps) {
  const initial = normaliseTime(value);
  const [open, setOpen] = useState(false);
  const [hour, setHour] = useState(initial.hour);
  const [minute, setMinute] = useState(initial.minute);

  const handleOpenChange = (nextOpen: boolean) => {
    if (nextOpen) {
      const next = normaliseTime(value);
      setHour(next.hour);
      setMinute(next.minute);
    }
    setOpen(nextOpen);
  };

  return (
    <Popover open={open} onOpenChange={handleOpenChange}>
      <PopoverTrigger asChild>
        <button
          type="button"
          aria-label={ariaLabel}
          aria-required={required}
          disabled={disabled}
          className={cn(
            "flex w-full items-center justify-between rounded-lg border border-gray-300 bg-white px-3 py-2 text-left text-sm text-gray-900 transition-colors hover:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:cursor-not-allowed disabled:bg-slate-100 disabled:opacity-70",
            !value && "text-gray-400",
            className,
          )}
        >
          <span>{displayTime(value) || placeholder}</span>
          <Clock3 className="h-4 w-4 shrink-0 text-gray-500" />
        </button>
      </PopoverTrigger>
      <PopoverContent align="start" sideOffset={8} collisionPadding={16} className="z-[90] w-[300px] rounded-xl border-gray-200 bg-white p-0 shadow-xl">
        <div className="border-b border-gray-100 px-4 py-3">
          <p className="text-sm font-semibold text-gray-900">Pick a time</p>
          <p className="mt-0.5 text-xs text-gray-500">{displayTime(`${hour}:${minute}`)}</p>
        </div>
        <div className="grid grid-cols-[88px_1fr] gap-3 p-3">
          <div>
            <p className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-gray-500">Hour</p>
            <div className="grid max-h-48 grid-cols-2 gap-1 overflow-y-auto pr-1">
              {hours.map((option) => (
                <button key={option} type="button" onClick={() => setHour(option)} className={cn("rounded-md px-2 py-1.5 text-xs font-semibold text-gray-600 hover:bg-blue-50", hour === option && "bg-blue-600 text-white hover:bg-blue-700")}>{option}</button>
              ))}
            </div>
          </div>
          <div>
            <p className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-gray-500">Minute</p>
            <div className="grid max-h-48 grid-cols-5 gap-1 overflow-y-auto pr-1">
              {minutes.map((option) => (
                <button key={option} type="button" onClick={() => setMinute(option)} className={cn("rounded-md px-1 py-1.5 text-xs font-semibold text-gray-600 hover:bg-blue-50", minute === option && "bg-blue-600 text-white hover:bg-blue-700")}>{option}</button>
              ))}
            </div>
          </div>
        </div>
        <div className="flex items-center justify-between border-t border-gray-100 px-3 py-3">
          <button type="button" onClick={() => { onChange(""); setOpen(false); }} className="rounded-lg px-3 py-2 text-xs font-semibold text-gray-500 hover:bg-gray-100">Clear</button>
          <button type="button" onClick={() => { onChange(`${hour}:${minute}`); setOpen(false); }} className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-bold text-white hover:bg-blue-700"><Check className="h-3.5 w-3.5" />Apply</button>
        </div>
      </PopoverContent>
    </Popover>
  );
}
