import { useMemo, useState, useCallback } from "react";
import {
  Activity,
  AlertCircle,
  AlertTriangle,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  FileText,
  Fingerprint,
  RefreshCw,
  Search,
  ServerCrash,
} from "lucide-react";
import { useApiData } from "../lib/use-api-data";
import { AdminSelect } from "./ui/admin-select";

interface LogEntry {
  ts: string;
  level: "FATAL" | "ERROR" | "WARN" | "INFO";
  message: string;
  context: Record<string, unknown>;
  mode: string;
  ip: string;
  actor: string;
}

interface LogFile {
  month: string;
  sizeBytes: number;
  lines: number;
}

interface LogsResponse {
  availableFiles: LogFile[];
  month: string;
  entries: LogEntry[];
  pagination: {
    page: number;
    perPage: number;
    total: number;
    totalPages: number;
  };
}

const EMPTY: LogsResponse = {
  availableFiles: [],
  month: "",
  entries: [],
  pagination: { page: 1, perPage: 100, total: 0, totalPages: 1 },
};

function levelStyle(level: string) {
  switch (level) {
    case "FATAL":
      return {
        row: "bg-red-50/60",
        badge: "border-red-300 bg-red-100 text-red-700",
        icon: <ServerCrash className="h-3.5 w-3.5" />,
      };
    case "ERROR":
      return {
        row: "bg-orange-50/40",
        badge: "border-orange-300 bg-orange-100 text-orange-700",
        icon: <AlertCircle className="h-3.5 w-3.5" />,
      };
    case "WARN":
      return {
        row: "bg-amber-50/30",
        badge: "border-amber-300 bg-amber-100 text-amber-700",
        icon: <AlertTriangle className="h-3.5 w-3.5" />,
      };
    default:
      return {
        row: "",
        badge: "border-slate-200 bg-slate-50 text-slate-600",
        icon: <Activity className="h-3.5 w-3.5" />,
      };
  }
}

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}

function formatTs(ts: string) {
  if (!ts) return "-";
  const d = new Date(ts.replace(" ", "T"));
  return isNaN(d.getTime())
    ? ts
    : new Intl.DateTimeFormat("en-MY", {
        dateStyle: "short",
        timeStyle: "medium",
      }).format(d);
}

export function AppLogs() {
  const [month, setMonth] = useState("");
  const [level, setLevel] = useState("ALL");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [expandedIdx, setExpandedIdx] = useState<number | null>(null);

  const query = useMemo(() => {
    const parts: string[] = [`level=${level}`, `page=${page}`];
    if (month) parts.push(`month=${month}`);
    if (search) parts.push(`search=${encodeURIComponent(search)}`);
    return `admin-app-logs&${parts.join("&")}`;
  }, [level, month, page, search]);

  const { data, isLoading, error, reload } = useApiData<LogsResponse>(query, EMPTY);

  const handleMonthChange = useCallback((m: string) => {
    setMonth(m);
    setPage(1);
    setExpandedIdx(null);
  }, []);

  const handleLevelChange = useCallback((l: string) => {
    setLevel(l);
    setPage(1);
    setExpandedIdx(null);
  }, []);

  const handlePageChange = useCallback((p: number) => {
    setPage(p);
    setExpandedIdx(null);
  }, []);

  const pagination = data.pagination;
  const fatalCount = data.entries.filter((e) => e.level === "FATAL").length;
  const errorCount = data.entries.filter((e) => e.level === "ERROR").length;
  const warnCount = data.entries.filter((e) => e.level === "WARN").length;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-rose-200 bg-rose-50 text-rose-700">
            <FileText className="h-5 w-5" />
          </span>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Application Logs</h1>
            <p className="mt-0.5 text-sm text-slate-500">
              Server-side errors, API failures, and slow requests.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center rounded-full border border-violet-200 bg-violet-50 px-3 py-1.5 text-xs font-bold text-violet-700">
            <Fingerprint className="mr-1.5 h-3.5 w-3.5" />
            Super Admin only
          </span>
          <button
            type="button"
            onClick={() => void reload()}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Refresh
          </button>
        </div>
      </div>

      {error ? (
        <div className="flex items-center justify-between gap-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          <span>Application logs unavailable: {error}</span>
          <button type="button" onClick={() => void reload()} className="font-semibold underline underline-offset-2">Retry</button>
        </div>
      ) : null}

      {/* Log file selector */}
      {data.availableFiles.length > 0 ? (
        <div className="flex flex-wrap gap-2">
          {data.availableFiles.map((f) => (
            <button
              key={f.month}
              type="button"
              onClick={() => handleMonthChange(f.month)}
              className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors ${
                (month || data.month) === f.month
                  ? "border-[#1e3a8a] bg-[#1e3a8a] text-white"
                  : "border-slate-300 bg-white text-slate-700 hover:bg-slate-50"
              }`}
            >
              <FileText className="h-3 w-3" />
              {f.month}
              <span className="opacity-70 text-[10px]">· {formatBytes(f.sizeBytes)}</span>
            </button>
          ))}
        </div>
      ) : !isLoading ? (
        <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 px-6 py-10 text-center">
          <Activity className="mx-auto mb-2 h-8 w-8 text-slate-300" />
          <p className="text-sm font-semibold text-slate-500">No log files yet</p>
          <p className="mt-1 text-xs text-slate-400">Logs are created automatically on the first API error or slow request (&gt;2s).</p>
        </div>
      ) : null}

      {/* Quick stats */}
      {data.entries.length > 0 ? (
        <div className="flex flex-wrap gap-2">
          {[
            { label: "This page", value: data.entries.length, tone: "text-slate-700 bg-slate-100" },
            { label: "FATAL", value: fatalCount, tone: "text-red-700 bg-red-100", hide: fatalCount === 0 },
            { label: "ERROR", value: errorCount, tone: "text-orange-700 bg-orange-100", hide: errorCount === 0 },
            { label: "WARN", value: warnCount, tone: "text-amber-700 bg-amber-100", hide: warnCount === 0 },
            { label: "Total matching", value: pagination.total, tone: "text-blue-700 bg-blue-100" },
          ].filter((s) => !s.hide).map((stat) => (
            <span key={stat.label} className={`rounded-lg px-3 py-1.5 text-xs font-bold ${stat.tone}`}>
              {stat.label}: {stat.value.toLocaleString()}
            </span>
          ))}
        </div>
      ) : null}

      {/* Filters */}
      <div className="rounded-xl border border-slate-200 bg-white p-3 shadow-sm">
        <div className="grid gap-3 lg:grid-cols-[minmax(240px,1fr)_160px]">
          <label className="relative block">
            <span className="sr-only">Search logs</span>
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="search"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              placeholder="Search message, mode, IP, actor…"
              className="h-10 w-full rounded-lg border border-slate-300 bg-white pl-10 pr-3 text-sm outline-none transition focus:border-blue-400 focus:ring-2 focus:ring-blue-100"
            />
          </label>
          <AdminSelect value={level} onChange={(e) => handleLevelChange(e.target.value)} className="w-full">
            <option value="ALL">All levels</option>
            <option value="FATAL">FATAL only</option>
            <option value="ERROR">ERROR only</option>
            <option value="WARN">WARN only</option>
            <option value="INFO">INFO only</option>
          </AdminSelect>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[860px] text-left">
            <thead className="border-b border-slate-200 bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-500">
              <tr>
                <th className="px-4 py-3 whitespace-nowrap">Timestamp</th>
                <th className="w-20 px-4 py-3">Level</th>
                <th className="px-4 py-3">Message</th>
                <th className="px-4 py-3">Mode</th>
                <th className="px-4 py-3">Actor / IP</th>
                <th className="w-10 px-4 py-3"><span className="sr-only">Expand</span></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {isLoading ? (
                <tr>
                  <td colSpan={6} className="px-4 py-16 text-center text-sm text-slate-400">
                    <RefreshCw className="mx-auto mb-2 h-5 w-5 animate-spin text-slate-300" />
                    Loading log entries…
                  </td>
                </tr>
              ) : data.entries.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-16 text-center text-sm text-slate-400">
                    No log entries match the current filters.
                  </td>
                </tr>
              ) : (
                data.entries.map((entry, idx) => {
                  const style = levelStyle(entry.level);
                  const expanded = expandedIdx === idx;
                  return [
                    <tr key={`row-${idx}`} className={`transition-colors hover:bg-slate-50/60 ${style.row}`}>
                      <td className="whitespace-nowrap px-4 py-2.5 font-mono text-xs text-slate-500">
                        {formatTs(entry.ts)}
                      </td>
                      <td className="px-4 py-2.5">
                        <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-bold ${style.badge}`}>
                          {style.icon}
                          {entry.level}
                        </span>
                      </td>
                      <td className="max-w-[340px] px-4 py-2.5">
                        <p className="truncate text-xs font-medium text-slate-800" title={entry.message}>
                          {entry.message}
                        </p>
                      </td>
                      <td className="px-4 py-2.5">
                        <code className="rounded bg-slate-100 px-1.5 py-0.5 text-[10px] text-slate-600">
                          {entry.mode || "—"}
                        </code>
                      </td>
                      <td className="px-4 py-2.5">
                        {entry.actor ? (
                          <p className="text-xs font-semibold text-slate-700">{entry.actor}</p>
                        ) : null}
                        {entry.ip ? (
                          <p className="mt-0.5 font-mono text-[10px] text-slate-400">{entry.ip}</p>
                        ) : null}
                      </td>
                      <td className="px-4 py-2.5">
                        <button
                          type="button"
                          onClick={() => setExpandedIdx(expanded ? null : idx)}
                          className="flex h-7 w-7 items-center justify-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
                          aria-label={expanded ? "Collapse" : "Expand"}
                          aria-expanded={expanded}
                        >
                          <ChevronDown className={`h-4 w-4 transition-transform ${expanded ? "rotate-180" : ""}`} />
                        </button>
                      </td>
                    </tr>,
                    expanded ? (
                      <tr key={`detail-${idx}`} className="bg-slate-950">
                        <td colSpan={6} className="px-4 py-3">
                          <p className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                            Context Details
                          </p>
                          <pre className="max-h-64 overflow-auto whitespace-pre-wrap break-words rounded-lg bg-slate-900 p-3 text-xs leading-relaxed text-emerald-300">
                            {JSON.stringify({ message: entry.message, context: entry.context, mode: entry.mode, ip: entry.ip, actor: entry.actor }, null, 2)}
                          </pre>
                        </td>
                      </tr>
                    ) : null,
                  ];
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination footer */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 bg-slate-50/70 px-4 py-3">
          <p className="text-xs text-slate-500">
            Showing {data.entries.length.toLocaleString()} of {pagination.total.toLocaleString()} entries
            {pagination.totalPages > 1 ? ` · Page ${pagination.page} / ${pagination.totalPages}` : ""}
          </p>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handlePageChange(pagination.page - 1)}
              disabled={pagination.page <= 1}
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-300 bg-white text-slate-600 disabled:cursor-not-allowed disabled:opacity-40"
              aria-label="Previous page"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <span className="min-w-20 text-center text-xs font-semibold text-slate-600">
              {pagination.page} / {pagination.totalPages}
            </span>
            <button
              type="button"
              onClick={() => handlePageChange(pagination.page + 1)}
              disabled={pagination.page >= pagination.totalPages}
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-300 bg-white text-slate-600 disabled:cursor-not-allowed disabled:opacity-40"
              aria-label="Next page"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
