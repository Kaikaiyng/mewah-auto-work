import { useState, useEffect, useMemo, useRef } from "react";
import { useSearchParams } from "react-router";
import { Search, Plus, Eye, Edit, ClipboardList, FileText, History as HistoryIcon, ListTodo, X, ChevronLeft, ChevronRight, ChevronDown, AlertCircle, AlertTriangle, Clock, Camera, Car, Building2, MapPin, Users, Check, CheckCircle2, Wrench, Save, CalendarClock, UserRound, Trash2, PackageSearch, Package, RefreshCw, Zap, Undo2, ArrowLeft, PhoneCall, Send, Download } from "lucide-react";
import { useLanguage } from "../contexts/language-context";
import { postApi, apiAssetUrl, apiRequest } from "../lib/api";
import { DesktopDatePicker } from "./ui/desktop-date-picker";
import { DesktopDateTimePicker } from "./ui/desktop-date-time-picker";
import { AdminSelect } from "./ui/admin-select";
import type { StaffMember } from "./staff";
import { getSignedInAdmin, hasAdminPermission } from "../lib/admin-permissions";
import { WorkOrderQuotationDialog } from "./work-order-quotation-dialog";
import { DocumentItemCatalogSelect, type DocumentCatalogPart } from "./ui/document-item-catalog-select";
import { toast } from "sonner";
import { exportTableToExcel, ExcelColumnDef } from "../lib/excel-export";

export function isRescueWorkOrder(wo?: { intakeType?: string; serviceType?: string; requestChannel?: string; reportedProblem?: string } | null) {
  if (!wo) return false;
  const intake = (wo.intakeType || "").toLowerCase();
  const channel = (wo.requestChannel || "").toLowerCase();
  const service = (wo.serviceType || "").toLowerCase();
  const problem = (wo.reportedProblem || "").toLowerCase();
  return (
    intake === "rescue" ||
    channel.includes("rescue") ||
    service.includes("rescue") ||
    service.includes("emergency") ||
    problem.startsWith("🚨") ||
    problem.includes("roadside rescue") ||
    problem.includes("emergency breakdown") ||
    problem.includes("道路救援") ||
    problem.includes("救援")
  );
}

type AssignedStaff = Pick<StaffMember, "id" | "name" | "role">;
type RelatedVehicle = { id: number; vehicleNo: string; relationship: string };
type WorkOrderPhoto = {
  id: number;
  category: string;
  caption: string;
  uploadedBy: string;
  customerVisible: boolean;
  takenAt: string | null;
  createdAt: string | null;
};

type WorkOrderPartOverviewItem = {
  inventoryPartId: number | null;
  code: string;
  description: string;
  uom: string;
  requiredQuantity: number;
  stockOnHand: number;
  shortageQuantity: number;
  orderedQuantity: number;
  receivedQuantity: number;
  outstandingOrderQuantity: number;
  projectedStock: number;
  availability: "ready" | "incoming" | "shortage";
  purchaseOrderNumbers: string[];
  isNewlyAdded?: boolean;
  isQtyIncreased?: boolean;
  originalQuotationQty?: number;
  inOriginalQuotation?: boolean;
};

type WorkOrderPartsOverview = {
  source: string;
  quotationNo: string | null;
  items: WorkOrderPartOverviewItem[];
  removedItems?: Array<{
    inventoryPartId: number | null;
    code: string;
    description: string;
    uom: string;
    originalQuantity: number;
    stockOnHand: number;
    isRemoved: boolean;
  }>;
  purchaseOrders: Array<{
    id: number;
    number: string;
    supplierName: string;
    status: string;
    estimatedArrivalDate: string;
    orderedQuantity: number;
    receivedQuantity: number;
  }>;
  summary: {
    totalItems: number;
    readyItems: number;
    incomingItems: number;
    shortageItems: number;
    canStartRepair: boolean;
  };
};

type InspectionPartRequirement = { id?: number; partId: number | null; code: string; description: string; uom: string; quantity: number; unitPrice: number };
const blankInspectionPart = (): InspectionPartRequirement => ({ partId: null, code: "", description: "", uom: "", quantity: 1, unitPrice: 0 });

async function loadWorkOrderPartsOverview(workOrderId: number): Promise<WorkOrderPartsOverview> {
  try {
    return await apiRequest<WorkOrderPartsOverview>(`admin-work-order-parts-overview&id=${workOrderId}`);
  } catch {
    type InventoryPart = { id: number; sku: string; name: string; stock: number; uom?: string };
    type Quote = { quotationNo?: string; items?: Array<{ type: string; code: string; description: string; quantity: number }> } | null;
    type PurchaseOrder = { id: number; internalRef: string; autocountPoNo: string; workOrderId: number | null; supplierName: string; status: string; estimatedArrivalDate: string; items: Array<{ partId: number | null; itemCode: string; description: string; uom: string; quantity: number; receivedQuantity: number }> };
    const [inventory, quotation, allOrders] = await Promise.all([
      apiRequest<InventoryPart[]>("admin-parts"),
      apiRequest<Quote>(`admin-get-work-order-quotation&id=${workOrderId}`),
      apiRequest<PurchaseOrder[]>("admin-purchase-orders"),
    ]);
    const inventoryByCode = new Map(inventory.map((part) => [part.sku.trim().toUpperCase(), part]));
    const inventoryById = new Map(inventory.map((part) => [part.id, part]));
    const lines = new Map<string, { code: string; description: string; uom: string; required: number; ordered: number; received: number; purchaseOrders: Set<string> }>();
    const keyFor = (code: string, description: string) => code.trim() ? `code:${code.trim().toUpperCase()}` : `description:${description.trim().toUpperCase()}`;
    const lineFor = (code: string, description: string, uom = "") => {
      const key = keyFor(code, description);
      const existing = lines.get(key);
      if (existing) return existing;
      const created = { code: code.trim(), description: description.trim(), uom, required: 0, ordered: 0, received: 0, purchaseOrders: new Set<string>() };
      lines.set(key, created);
      return created;
    };
    quotation?.items?.filter((item) => item.type === "part").forEach((item) => { lineFor(item.code, item.description).required += Number(item.quantity || 0); });
    const purchaseOrders = allOrders.filter((order) => order.workOrderId === workOrderId && order.status !== "cancelled").map((order) => {
      const number = order.autocountPoNo || order.internalRef;
      order.items.forEach((item) => {
        const inventoryPart = item.partId ? inventoryById.get(item.partId) : undefined;
        const line = lineFor(item.itemCode || inventoryPart?.sku || "", item.description || inventoryPart?.name || "", item.uom || inventoryPart?.uom || "");
        line.ordered += Number(item.quantity || 0);
        line.received += Number(item.receivedQuantity || 0);
        line.purchaseOrders.add(number);
      });
      return { id: order.id, number, supplierName: order.supplierName, status: order.status, estimatedArrivalDate: order.estimatedArrivalDate, orderedQuantity: order.items.reduce((sum, item) => sum + Number(item.quantity || 0), 0), receivedQuantity: order.items.reduce((sum, item) => sum + Number(item.receivedQuantity || 0), 0) };
    });
    const items: WorkOrderPartOverviewItem[] = Array.from(lines.values()).map((line) => {
      const inventoryPart = inventoryByCode.get(line.code.toUpperCase());
      const requiredQuantity = line.required > 0 ? line.required : line.ordered;
      const stockOnHand = Number(inventoryPart?.stock || 0);
      const outstandingOrderQuantity = Math.max(0, line.ordered - line.received);
      const shortageQuantity = Math.max(0, requiredQuantity - stockOnHand);
      const availability: WorkOrderPartOverviewItem["availability"] = shortageQuantity <= 0 ? "ready" : stockOnHand + outstandingOrderQuantity >= requiredQuantity ? "incoming" : "shortage";
      return { inventoryPartId: inventoryPart?.id || null, code: line.code, description: line.description || inventoryPart?.name || "Unnamed part", uom: line.uom || inventoryPart?.uom || "", requiredQuantity, stockOnHand, shortageQuantity, orderedQuantity: line.ordered, receivedQuantity: line.received, outstandingOrderQuantity, projectedStock: stockOnHand + outstandingOrderQuantity, availability, purchaseOrderNumbers: Array.from(line.purchaseOrders) };
    }).sort((left, right) => ({ shortage: 0, incoming: 1, ready: 2 }[left.availability] - { shortage: 0, incoming: 1, ready: 2 }[right.availability]));
    const readyItems = items.filter((item) => item.availability === "ready").length;
    const incomingItems = items.filter((item) => item.availability === "incoming").length;
    const shortageItems = items.filter((item) => item.availability === "shortage").length;
    return { source: quotation ? "quotation_and_purchase_orders" : "purchase_orders", quotationNo: quotation?.quotationNo || null, items, purchaseOrders, summary: { totalItems: items.length, readyItems, incomingItems, shortageItems, canStartRepair: items.length === 0 || (incomingItems === 0 && shortageItems === 0) } };
  }
}

type WorkOrder = {
  id: number;
  workOrderNo: string;
  legacyStatus: number;
  canonicalStatus: string;
  vehicleId: number;
  vehicleNo: string;
  brand: string;
  model: string;
  equipmentType: string;
  companyId: number;
  companyName: string;
  customerId: number | null;
  contactName: string;
  contactType: string;
  customerPhone: string;
  serviceType: string;
  serviceCentre: string;
  reportedProblem: string;
  customerNotes: string;
  intakeType: string;
  requestChannel: string;
  broughtByDriverId: number | null;
  broughtByDriverName: string;
  foremanId: number | null;
  foremanName: string;
  checkinMileage: number | null;
  autocountJobNo: string;
  relatedVehicles: RelatedVehicle[];
  bay: string | null;
  priority: string;
  checkinAt: string | null;
  inspectedAt: string | null;
  quotationIssuedAt: string | null;
  approvedAt: string | null;
  partsReadyAt: string | null;
  partsStatus: string | null;
  partsExpectedDate: string | null;
  partsReference: string | null;
  partsNotes: string | null;
  partsStatusUpdatedAt: string | null;
  partsStatusUpdatedBy: number | null;
  partsAcknowledgedAt?: string | null;
  partsAcknowledgedBy?: number | null;
  hasUnacknowledgedParts?: boolean;
  underRepairAt: string | null;
  completedAt: string | null;
  collectedAt: string | null;
  estimatedOut: string | null;
  sourceBookingId: number | null;
  isBackOrder?: boolean;
  technicians: AssignedStaff[];
  photos: WorkOrderPhoto[];
};

type Company = {
  id: number;
  name: string;
};

type Vehicle = {
  id: number;
  vecNo?: string;
  unitNo?: string;
  regNo: string;
  brand: string;
  model: string;
  companyId: number;
};

type Customer = {
  id: number;
  name: string;
  type: string;
  companyId: number;
};

type CompanyDriver = {
  id: number;
  companyId: number;
  name: string;
  phone: string;
  status: "Active" | "Inactive";
};

const BAYS = ['Bay 1', 'Bay 2', 'Bay 3', 'Bay 4', 'Engine Bay', 'Trailer Bay'];
const PRIORITIES = ['Normal', 'High', 'Urgent'];
const PRIORITY_RANK: Record<string, number> = { urgent: 0, high: 1, normal: 2 };
const REQUEST_CHANNELS = ['WhatsApp', 'Verbal', 'Phone'];
const PARTS_STATUSES = [
  { value: "not_required", label: "Not Required" },
  { value: "pending_parts", label: "Pending Parts" },
  { value: "partially_arrived", label: "Partially Arrived" },
  { value: "parts_ready", label: "Parts Ready" },
] as const;

function calculatePartsStatus(overview: WorkOrderPartsOverview | null, fallback = "not_required", isBackOrder = false) {
  if (isBackOrder) return "parts_ready";
  if (!overview) return fallback;
  if (overview.summary.totalItems === 0) return "not_required";
  if (overview.summary.canStartRepair) return "parts_ready";
  if (overview.items.some((item) => item.receivedQuantity > 0)) return "partially_arrived";
  return "pending_parts";
}
const STATUSES = ['scheduled', 'checked_in', 'inspected', 'quotation_issued', 'approved', 'parts_ready', 'under_repair', 'ready_for_collection', 'collected'];
const WORK_ORDER_TRANSITIONS: Record<string, string[]> = {
  scheduled: ["checked_in"],
  checked_in: ["inspected"],
  inspected: [], // Next step requires reviewing and preparing quotation
  quotation_issued: [],
  approved: ["under_repair"],
  parts_ready: ["under_repair"],
  under_repair: ["ready_for_collection"],
  ready_for_collection: ["collected"],
  collected: [],
};

const HEAD_MANAGER_LIFECYCLE_STATUSES = new Set([
  "inspected", "quotation_issued", "approved", "under_repair", "ready_for_collection",
]);
const TECHNICIAN_LIFECYCLE_STATUSES = new Set([
  "inspected", "under_repair", "ready_for_collection",
]);

const WORK_ORDER_STAGES = [
  { key: "scheduled", label: "Scheduled" },
  { key: "checked_in", label: "Checked In" },
  { key: "inspected", label: "Inspection" },
  { key: "quotation_issued", label: "Quotation (Optional)", optional: true },
  { key: "approved", label: "Approved" },
  { key: "parts_ready", label: "Parts Ready", optional: true },
  { key: "under_repair", label: "Under Repair" },
  { key: "ready_for_collection", label: "Ready for Collection" },
  { key: "collected", label: "Collected" },
] as const;

type WorkOrderStage = (typeof WORK_ORDER_STAGES)[number];
type StageState = "completed" | "current" | "future" | "optional-history";

function getStageState(workOrder: WorkOrder, stage: WorkOrderStage, stageIndex: number): StageState {
  const currentIndex = WORK_ORDER_STAGES.findIndex((item) => item.key === workOrder.canonicalStatus);
  if (stage.key === workOrder.canonicalStatus) return "current";
  if (stage.optional && currentIndex > stageIndex && !getStageTimestamp(workOrder, stage.key)) return "optional-history";
  return stageIndex < currentIndex ? "completed" : "future";
}

function getStageTimestamp(workOrder: WorkOrder, stageKey: string) {
  const timestamps: Record<string, string | null> = {
    checked_in: workOrder.checkinAt,
    inspected: workOrder.inspectedAt,
    quotation_issued: workOrder.quotationIssuedAt,
    approved: workOrder.approvedAt,
    parts_ready: workOrder.partsReadyAt,
    under_repair: workOrder.underRepairAt,
    ready_for_collection: workOrder.completedAt,
    collected: workOrder.collectedAt,
  };
  return timestamps[stageKey] || null;
}

function formatStageTimestamp(value: string | null) {
  if (!value) return "";
  const date = new Date(value.includes("T") ? value : value.replace(" ", "T"));
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("en-MY", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

function getStageNodeClasses(state: StageState) {
  if (state === "current") return "maw-stage-current-node border-sky-400 bg-gradient-to-br from-sky-400 to-blue-600 text-white";
  if (state === "completed") return "border-blue-700 bg-[#1d4f91] text-white shadow-[0_4px_10px_rgba(29,79,145,0.18)]";
  if (state === "optional-history") return "border-dashed border-amber-400 bg-amber-50 text-amber-700";
  return "border-slate-200 bg-white text-slate-400 shadow-sm";
}

function getStageConnectorClasses(state: StageState) {
  if (state === "completed") return "bg-[#1d4f91]";
  if (state === "optional-history") return "bg-gradient-to-r from-amber-300 to-blue-700";
  return "bg-slate-200";
}

function getPartsStatusConfig(status: string | null | undefined, isBackOrder = false) {
  if (isBackOrder) {
    return {
      label: "Parts: Ready (Back Order)",
      className: "border-purple-200 bg-purple-50 text-purple-700"
    };
  }
  const configs: Record<string, { label: string; className: string }> = {
    not_required: { label: "Parts: Not Required", className: "border-slate-200 bg-slate-50 text-slate-600" },
    pending_parts: { label: "Parts: Pending", className: "border-amber-200 bg-amber-50 text-amber-700" },
    partially_arrived: { label: "Parts: Partially Arrived", className: "border-amber-200 bg-amber-50 text-amber-700" },
    parts_ready: { label: "Parts: Ready", className: "border-emerald-200 bg-emerald-50 text-emerald-700" },
  };
  const item = configs[status || ""] || { label: "Parts: Not Set", className: "border-slate-200 bg-slate-50 text-slate-600" };
  return item;
}

type ActiveDateGroup = "overdue" | "today" | "upcoming" | "no_eta";

function getActiveDateGroup(workOrder: WorkOrder): ActiveDateGroup {
  if (!workOrder.estimatedOut) return "no_eta";
  const dateKey = workOrder.estimatedOut.slice(0, 10);
  const now = new Date();
  const todayKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
  if (dateKey < todayKey) return "overdue";
  if (dateKey === todayKey) return "today";
  return "upcoming";
}

function getActiveDateBadge(group: ActiveDateGroup) {
  const badges: Record<ActiveDateGroup, { label: string; className: string }> = {
    overdue: { label: "Overdue", className: "border-rose-200 bg-rose-50 text-rose-700" },
    today: { label: "Today", className: "border-teal-200 bg-teal-50 text-teal-700" },
    upcoming: { label: "Upcoming", className: "border-sky-200 bg-sky-50 text-sky-700" },
    no_eta: { label: "No ETA", className: "border-slate-200 bg-slate-50 text-slate-500" },
  };
  return badges[group];
}

function SearchableVehicleSelect({
  vehicles,
  companies,
  value,
  onChange,
}: {
  vehicles: { id: number; vecNo?: string; unitNo?: string; regNo: string; brand: string; model: string; companyId?: number; driverId?: number }[];
  companies: { id: number; name: string }[];
  value: number | "";
  onChange: (vehicleId: number | "") => void;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const containerRef = useRef<HTMLDivElement>(null);

  const selectedVehicle = useMemo(
    () => (value ? vehicles.find((v) => v.id === value) : null),
    [value, vehicles],
  );

  const selectedCompany = useMemo(
    () => (selectedVehicle?.companyId ? companies.find((c) => c.id === selectedVehicle.companyId) : null),
    [selectedVehicle, companies],
  );

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return vehicles;
    return vehicles.filter((v) => {
      const comp = companies.find((c) => c.id === v.companyId);
      const unit = (v.unitNo || v.vecNo || "").toLowerCase();
      const reg = (v.regNo || "").toLowerCase();
      const brand = (v.brand || "").toLowerCase();
      const model = (v.model || "").toLowerCase();
      const companyName = (comp?.name || "").toLowerCase();
      return (
        unit.includes(q) ||
        reg.includes(q) ||
        brand.includes(q) ||
        model.includes(q) ||
        companyName.includes(q)
      );
    });
  }, [vehicles, companies, query]);

  const formatVehicleDisplay = (v: typeof vehicles[0]) => {
    const primaryUnit = v.unitNo || v.vecNo;
    if (primaryUnit && v.regNo && primaryUnit !== v.regNo) {
      return `${primaryUnit} · ${v.regNo}`;
    }
    return primaryUnit || v.regNo || "-";
  };

  return (
    <div ref={containerRef} className="relative">
      <div className="relative flex items-center">
        <input
          type="text"
          value={
            open
              ? query
              : selectedVehicle
              ? `${formatVehicleDisplay(selectedVehicle)}${selectedVehicle.brand || selectedVehicle.model ? ` (${[selectedVehicle.brand, selectedVehicle.model].filter(Boolean).join(" ")})` : ""}${selectedCompany ? ` — ${selectedCompany.name}` : ""}`
              : ""
          }
          placeholder="Type vehicle unit no (e.g. U-101) or plate no (e.g. JXY 8899)..."
          onFocus={() => {
            setOpen(true);
            setQuery("");
          }}
          onChange={(e) => {
            setQuery(e.target.value);
            if (!open) setOpen(true);
          }}
          className="h-10 w-full rounded-lg border border-gray-300 bg-white pl-9 pr-8 text-sm font-medium text-gray-900 placeholder:text-gray-400 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-100"
        />
        <Search className="pointer-events-none absolute left-3 h-4 w-4 text-gray-400" />
        {value ? (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onChange("");
              setQuery("");
            }}
            className="absolute right-2.5 rounded p-0.5 text-gray-400 hover:bg-gray-100 hover:text-gray-600"
            title="Clear vehicle"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        ) : (
          <ChevronDown className="pointer-events-none absolute right-3 h-4 w-4 text-gray-400" />
        )}
      </div>

      {open && (
        <div className="absolute left-0 right-0 top-full z-50 mt-1 max-h-64 overflow-y-auto rounded-xl border border-gray-200 bg-white p-1.5 shadow-xl animate-in fade-in-50">
          {filtered.length === 0 ? (
            <p className="p-3 text-center text-xs text-gray-500">No matching vehicle found.</p>
          ) : (
            filtered.map((v) => {
              const comp = companies.find((c) => c.id === v.companyId);
              const isSelected = v.id === value;
              const primaryUnit = v.unitNo || v.vecNo;
              const hasDistinctUnit = primaryUnit && primaryUnit !== v.regNo;
              return (
                <button
                  key={v.id}
                  type="button"
                  onClick={() => {
                    onChange(v.id);
                    setOpen(false);
                    setQuery("");
                  }}
                  className={`flex w-full items-center justify-between gap-2 rounded-lg px-3 py-2.5 text-left text-xs transition-colors ${
                    isSelected ? "bg-blue-50 text-[#1e3a8a] font-bold" : "text-gray-800 hover:bg-slate-50"
                  }`}
                >
                  <div className="min-w-0 flex items-center flex-wrap gap-1.5">
                    {/* Primary: Unit No */}
                    <span className="font-extrabold text-gray-900 text-[13px]">
                      {primaryUnit || v.regNo}
                    </span>
                    {/* Secondary: Plate / Reg No */}
                    {hasDistinctUnit && v.regNo ? (
                      <span className="rounded bg-blue-50/80 border border-blue-200/60 px-1.5 py-0.5 text-[10px] font-bold text-blue-700">
                        {v.regNo}
                      </span>
                    ) : null}
                    <span className="text-gray-500">
                      {[v.brand, v.model].filter(Boolean).join(" ")}
                    </span>
                    {comp ? (
                      <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[10px] text-gray-600">
                        {comp.name}
                      </span>
                    ) : null}
                  </div>
                  {isSelected ? <Check className="h-4 w-4 text-blue-600 shrink-0" /> : null}
                </button>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}

function StaffSelect({
  staff,
  selectedIds,
  onChange,
}: {
  staff: StaffMember[];
  selectedIds: number[];
  onChange: (ids: number[]) => void;
}) {
  const selectedId = selectedIds[0] || "";
  return (
    staff.length === 0 ? (
      <p className="rounded-xl border border-gray-200 bg-gray-50 px-3 py-3 text-center text-xs text-gray-500">No active technical staff. Add one under Staff.</p>
    ) : (
      <AdminSelect
        value={selectedId}
        onChange={(event) => onChange(event.target.value ? [Number(event.target.value)] : [])}
        className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
      >
        <option value="">-- Select Repair Person / Technician --</option>
        {staff.map((member) => (
          <option key={member.id} value={member.id}>{member.name} ({member.role})</option>
        ))}
      </AdminSelect>
    )
  );
}

function WorkOrderViewPartsSection({ workOrderId }: { workOrderId: number }) {
  const [overview, setOverview] = useState<WorkOrderPartsOverview | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setLoading(true);
    loadWorkOrderPartsOverview(workOrderId)
      .then((data) => {
        if (active) setOverview(data);
      })
      .catch(() => {})
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [workOrderId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center rounded-xl border border-slate-100 bg-slate-50/70 py-6 text-xs text-slate-500">
        <RefreshCw className="mr-2 h-4 w-4 animate-spin text-blue-600" />
        Loading spare parts requirements...
      </div>
    );
  }

  const items = overview?.items || [];

  return (
    <div className="rounded-xl border border-blue-100 bg-[#f8fbff] p-4 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3">
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-blue-100/70 text-[#1e3a8a]">
            <Package className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Required / Used Spare Parts ({items.length})
            </h3>
            <p className="text-[11px] text-slate-500">Parts requested from workshop inventory</p>
          </div>
        </div>
        {overview?.summary.canStartRepair && items.length > 0 ? (
          <span className="rounded-full bg-emerald-100 px-2.5 py-0.5 text-[10px] font-bold text-emerald-800 ring-1 ring-emerald-300">
            🟢 Parts Ready (In Stock)
          </span>
        ) : overview && overview.summary.shortageItems > 0 ? (
          <span className="rounded-full bg-amber-100 px-2.5 py-0.5 text-[10px] font-bold text-amber-800 ring-1 ring-amber-300">
            🟡 Shortage ({overview.summary.shortageItems} item{overview.summary.shortageItems > 1 ? "s" : ""})
          </span>
        ) : null}
      </div>

      {items.length === 0 ? (
        <p className="rounded-lg border border-dashed border-blue-200/60 bg-white p-4 text-center text-xs text-slate-500">
          No spare parts requested for this work order.
        </p>
      ) : (
        <div className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-xs">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-200 bg-slate-50/80 text-[10px] font-bold uppercase text-slate-500">
              <tr>
                <th className="px-3.5 py-2.5">Part & Code</th>
                <th className="px-3.5 py-2.5 text-center">Qty Required</th>
                <th className="px-3.5 py-2.5 text-center">Stock on Hand</th>
                <th className="px-3.5 py-2.5 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {items.map((item, idx) => {
                const isShortage = item.availability === "shortage";
                return (
                  <tr key={idx} className="hover:bg-slate-50/60">
                    <td className="px-3.5 py-2.5">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <p className="font-bold text-slate-900">{item.description}</p>
                        {item.isNewlyAdded ? (
                          <span className="inline-flex items-center gap-0.5 rounded-full bg-amber-100 border border-amber-300 px-1.5 py-0.5 text-[9px] font-extrabold text-amber-900 shadow-xs">
                            ✨ New
                          </span>
                        ) : null}
                      </div>
                      {item.code ? (
                        <span className="font-mono text-[10px] text-slate-500">{item.code}</span>
                      ) : null}
                    </td>
                    <td className="px-3.5 py-2.5 text-center font-extrabold text-slate-800">
                      {item.requiredQuantity} {item.uom}
                    </td>
                    <td className="px-3.5 py-2.5 text-center font-medium text-slate-600">
                      {item.stockOnHand} {item.uom}
                    </td>
                    <td className="px-3.5 py-2.5 text-right">
                      {isShortage ? (
                        <span className="h-6 px-2.5 inline-flex items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white shadow-xs">
                          Shortage (-{item.shortageQuantity})
                        </span>
                      ) : (
                        <span className="h-6 px-2.5 inline-flex items-center justify-center rounded-full bg-emerald-500 text-[10px] font-bold text-white shadow-xs">
                          Ready
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function WorkOrderReviewPartsDialog({
  workOrder,
  catalog,
  onClose,
  onSuccess,
}: {
  workOrder: WorkOrder;
  catalog: DocumentCatalogPart[];
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [items, setItems] = useState<{
    code: string;
    description: string;
    quantity: number;
    stock: number;
    uom: string;
    isNewlyAdded?: boolean;
    isQtyIncreased?: boolean;
    originalQuotationQty?: number;
  }[]>([]);
  const [removedItems, setRemovedItems] = useState<Array<{
    code: string;
    description: string;
    uom: string;
    originalQuantity: number;
  }>>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const catalogBySku = useMemo(() => {
    const map = new Map<string, DocumentCatalogPart>();
    catalog.forEach((p) => {
      if (p.sku) map.set(p.sku.trim().toUpperCase(), p);
    });
    return map;
  }, [catalog]);

  useEffect(() => {
    let active = true;
    setLoading(true);
    loadWorkOrderPartsOverview(workOrder.id)
      .then((data) => {
        if (!active) return;
        const mapped = (data?.items || []).map((item) => ({
          code: item.code || "",
          description: item.description || "",
          quantity: Math.max(1, Number(item.requiredQuantity) || 1),
          stock: Number(item.stockOnHand) || 0,
          uom: item.uom || "PCS",
          isNewlyAdded: Boolean(item.isNewlyAdded),
          isQtyIncreased: Boolean(item.isQtyIncreased),
          originalQuotationQty: item.originalQuotationQty,
        }));
        setItems(mapped);
        const removed = (data?.removedItems || []).map((r) => ({
          code: r.code || "",
          description: r.description || "",
          uom: r.uom || "",
          originalQuantity: Number(r.originalQuantity) || 1,
        }));
        setRemovedItems(removed);
      })
      .catch(() => {})
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [workOrder.id]);

  const handleQtyChange = (index: number, delta: number) => {
    setItems((current) =>
      current.map((item, idx) => {
        if (idx !== index) return item;
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      })
    );
  };

  const handleQtyInput = (index: number, val: number) => {
    const newQty = Math.max(1, isNaN(val) ? 1 : val);
    setItems((current) =>
      current.map((item, idx) => (idx === index ? { ...item, quantity: newQty } : item))
    );
  };

  const [partToRemove, setPartToRemove] = useState<{ index: number; name: string; code?: string } | null>(null);

  const confirmRemove = () => {
    if (partToRemove !== null) {
      setItems((current) => current.filter((_, idx) => idx !== partToRemove.index));
      setPartToRemove(null);
    }
  };

  const handleAddPart = () => {
    setItems((current) => [
      ...current,
      { code: "", description: "", quantity: 1, stock: 0, uom: "PCS", isNewlyAdded: true },
    ]);
  };

  const handleSelectCatalogPart = (index: number, selection: { code: string; description: string; unitPrice: number }) => {
    const catPart = catalogBySku.get((selection.code || "").trim().toUpperCase());
    setItems((current) =>
      current.map((item, idx) => {
        if (idx !== index) return item;
        return {
          ...item,
          code: selection.code,
          description: selection.description,
          stock: Number(catPart?.stock) || 0,
          uom: catPart?.uom || "PCS",
        };
      })
    );
  };

  const totalShortages = items.filter((i) => i.code && i.stock < i.quantity).length;
  const isReady = items.length > 0 && totalShortages === 0;

  const handleConfirmAndSave = async () => {
    try {
      setSaving(true);
      const validItems = items.filter((i) => (i.code || "").trim() || (i.description || "").trim());
      const payload = validItems.map((i) => ({
        code: i.code,
        itemCode: i.code,
        description: i.description || i.code,
        quantity: Math.max(1, Number(i.quantity) || 1),
      }));

      // 1. Save updated parts list to backend
      await postApi("admin-save-work-order-part-requirements", {
        workOrderId: workOrder.id,
        items: payload,
      });

      // 2. Acknowledge parts update
      await postApi("admin-acknowledge-work-order-parts", {
        workOrderId: workOrder.id,
      });

      toast.success("Parts updated and acknowledged successfully.");
      window.dispatchEvent(new CustomEvent("work-order-parts-updated"));
      onSuccess();
      onClose();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to update and acknowledge parts.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm transition-opacity">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full overflow-hidden border border-gray-100 animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-gradient-to-r from-amber-50/90 via-white to-blue-50/60 shrink-0">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-100 text-amber-800 ring-1 ring-amber-200">
              <Zap className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-gray-900 sm:text-lg">
                Review Mid-Repair Added Parts — {workOrder.workOrderNo}
              </h2>
              <p className="text-xs text-gray-500">
                {workOrder.vehicleNo} · {workOrder.companyName} · Added from Workshop Floor
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
            aria-label="Close"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 overflow-y-auto flex-1">
          <div className="rounded-xl border border-amber-200/80 bg-amber-50/60 p-3.5 text-xs text-amber-900 flex items-start gap-2.5">
            <AlertCircle className="h-4 w-4 shrink-0 text-amber-600 mt-0.5" />
            <div>
              <p className="font-bold">Workshop team added or updated spare parts for this job during repair.</p>
              <p className="mt-0.5 text-amber-800/90">
                You can review, adjust quantities, add, or remove parts below before confirming. Clicking &ldquo;Confirm &amp; Acknowledge Parts&rdquo; will save your changes and allow the repair workflow to proceed.
              </p>
            </div>
          </div>

          <div className="rounded-xl border border-blue-100 bg-[#f8fbff] p-4 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3.5 border-b border-blue-100/80 mb-3">
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-blue-100/70 text-[#1e3a8a]">
                  <Package className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                    Required / Used Spare Parts ({items.length})
                  </h3>
                  <p className="text-[11px] text-slate-500">Parts requested from workshop inventory</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {isReady ? (
                  <span className="rounded-full bg-emerald-100 px-2.5 py-0.5 text-[10px] font-bold text-emerald-800 ring-1 ring-emerald-300">
                    🟢 Parts Ready (In Stock)
                  </span>
                ) : totalShortages > 0 ? (
                  <span className="rounded-full bg-amber-100 px-2.5 py-0.5 text-[10px] font-bold text-amber-800 ring-1 ring-amber-300">
                    🟡 Shortage ({totalShortages} item{totalShortages > 1 ? "s" : ""})
                  </span>
                ) : null}

                <button
                  type="button"
                  onClick={handleAddPart}
                  className="inline-flex items-center gap-1 rounded-lg border border-blue-200 bg-white px-3 py-1.5 text-xs font-bold text-blue-700 shadow-xs hover:bg-blue-50 transition-colors"
                >
                  <Plus className="h-3.5 w-3.5" />
                  Add Part
                </button>
              </div>
            </div>

            {loading ? (
              <div className="flex items-center justify-center py-8 text-xs text-slate-500">
                <RefreshCw className="mr-2 h-4 w-4 animate-spin text-blue-600" />
                Loading spare parts requirements...
              </div>
            ) : items.length === 0 ? (
              <div className="text-center py-8">
                <PackageSearch className="mx-auto h-8 w-8 text-slate-300 mb-2" />
                <p className="text-xs font-bold text-slate-600">No spare parts listed for this work order.</p>
                <p className="text-[11px] text-slate-400 mt-0.5">Click &ldquo;Add Part&rdquo; above to add spare parts from inventory.</p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {items.map((item, idx) => {
                  const catPart = catalogBySku.get((item.code || "").trim().toUpperCase());
                  const stock = Number(catPart?.stock ?? item.stock) || 0;
                  const qty = Number(item.quantity) || 1;
                  const hasShortage = item.code && stock < qty;
                  const isReadyItem = item.code && stock >= qty;

                  return (
                    <div
                      key={idx}
                      className={`rounded-xl border p-3.5 shadow-xs transition-all flex flex-col gap-2.5 ${
                        item.isNewlyAdded
                          ? "border-amber-300 bg-amber-50/40 ring-1 ring-amber-200/60"
                          : "border-slate-200 bg-white hover:border-slate-300"
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-[10px] font-extrabold uppercase text-slate-400">
                            #{String(idx + 1).padStart(2, "0")}
                          </span>
                          <span
                            className={`inline-flex rounded-full px-2 py-0.5 text-[10px] font-extrabold uppercase ${
                              !item.code
                                ? "bg-slate-100 text-slate-500"
                                : isReadyItem
                                ? "bg-emerald-100 text-emerald-800"
                                : "bg-rose-100 text-rose-800"
                            }`}
                          >
                            {!item.code
                              ? "Select Part"
                              : isReadyItem
                              ? `Ready (Stock: ${stock})`
                              : `Shortage (-${qty - stock}) · Stock: ${stock}`}
                          </span>

                          {item.isNewlyAdded ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 border border-amber-300 px-2 py-0.5 text-[10px] font-extrabold text-amber-900 shadow-xs">
                              <span className="h-1.5 w-1.5 rounded-full bg-amber-600 animate-pulse" />
                              ✨ New Added (车间新增)
                            </span>
                          ) : item.isQtyIncreased ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-blue-100 border border-blue-300 px-2 py-0.5 text-[10px] font-extrabold text-blue-900 shadow-xs">
                              📈 Qty Increased (原报价: {item.originalQuotationQty})
                            </span>
                          ) : null}
                        </div>

                        <button
                          type="button"
                          onClick={() => setPartToRemove({ index: idx, name: item.description || item.code || `Item #${idx + 1}`, code: item.code })}
                          className="inline-flex items-center text-xs font-semibold text-rose-600 hover:text-rose-700 p-1 hover:bg-rose-50 rounded-lg transition-colors"
                          title="Remove part"
                        >
                          <Trash2 className="h-3.5 w-3.5 mr-1" />
                          Delete
                        </button>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
                        <div className="sm:col-span-8">
                          <DocumentItemCatalogSelect
                            compact
                            itemType="part"
                            code={item.code}
                            description={item.description}
                            parts={catalog}
                            services={[]}
                            onSelect={(selection) => handleSelectCatalogPart(idx, selection)}
                          />
                        </div>

                        <div className="sm:col-span-4 flex items-center justify-end gap-2">
                          <span className="text-xs font-bold text-slate-500">Qty:</span>
                          <div className="flex items-center rounded-lg border border-slate-200 bg-slate-50 p-0.5">
                            <button
                              type="button"
                              onClick={() => handleQtyChange(idx, -1)}
                              disabled={qty <= 1}
                              className="flex h-7 w-7 items-center justify-center rounded-md bg-white text-xs font-bold text-slate-700 shadow-xs hover:bg-slate-100 active:scale-95 disabled:opacity-30"
                            >
                              -
                            </button>
                            <input
                              type="number"
                              min="1"
                              value={qty}
                              onChange={(e) => handleQtyInput(idx, parseInt(e.target.value, 10))}
                              className="h-7 w-12 text-center text-xs font-extrabold text-slate-900 bg-transparent outline-none"
                            />
                            <button
                              type="button"
                              onClick={() => handleQtyChange(idx, 1)}
                              className="flex h-7 w-7 items-center justify-center rounded-md bg-white text-xs font-bold text-slate-700 shadow-xs hover:bg-slate-100 active:scale-95"
                            >
                              +
                            </button>
                          </div>
                          <span className="text-[11px] font-semibold text-slate-400 min-w-8">
                            {item.uom || "PCS"}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Removed Parts Section */}
            {removedItems.length > 0 ? (
              <div className="mt-3 space-y-2">
                <div className="flex items-center gap-2 pt-1">
                  <span className="h-px flex-1 bg-rose-200" />
                  <span className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-widest text-rose-500">
                    <Trash2 className="h-3 w-3" />
                    Removed by Manager ({removedItems.length})
                  </span>
                  <span className="h-px flex-1 bg-rose-200" />
                </div>
                {removedItems.map((removed, ridx) => (
                  <div
                    key={ridx}
                    className="flex items-center gap-3 rounded-xl border border-rose-200 bg-rose-50/60 px-3.5 py-2.5 opacity-70"
                  >
                    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-rose-100 text-rose-600">
                      <Trash2 className="h-3 w-3" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-xs font-bold text-rose-900 line-through decoration-rose-400">
                        {removed.description || removed.code}
                      </p>
                      {removed.code ? (
                        <span className="font-mono text-[10px] text-rose-600 line-through">{removed.code}</span>
                      ) : null}
                    </div>
                    <div className="flex shrink-0 items-center gap-1 rounded-lg bg-rose-100 px-2 py-1">
                      <span className="text-[10px] font-extrabold text-rose-700">Qty: {removed.originalQuantity}</span>
                      {removed.uom ? <span className="text-[10px] text-rose-500">{removed.uom}</span> : null}
                    </div>
                    <span className="inline-flex rounded-full border border-rose-300 bg-white px-1.5 py-0.5 text-[9px] font-extrabold uppercase text-rose-600">
                      Deleted
                    </span>
                  </div>
                ))}
              </div>
            ) : null}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-3 border-t border-gray-200 bg-gray-50 px-6 py-4 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl border border-gray-300 bg-white px-4 py-2.5 text-xs font-semibold text-gray-700 hover:bg-gray-50 active:bg-gray-100 transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={saving || loading}
            onClick={() => void handleConfirmAndSave()}
            className="inline-flex items-center rounded-xl bg-[#1e3a8a] px-5 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-blue-800 active:scale-98 transition-all disabled:opacity-50"
          >
            {saving ? (
              <RefreshCw className="mr-1.5 h-4 w-4 animate-spin" />
            ) : (
              <Check className="mr-1.5 h-4 w-4" />
            )}
            Confirm &amp; Acknowledge Parts
          </button>
        </div>
      </div>

      {/* Confirmation Modal for Removing Part */}
      {partToRemove && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-100">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-5 border border-slate-200 animate-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 mb-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rose-50 text-rose-600 ring-1 ring-rose-200">
                <Trash2 className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">Remove Spare Part?</h3>
                <p className="text-xs text-slate-500">Confirm removing this required part</p>
              </div>
            </div>
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 mb-4">
              <p className="text-xs font-bold text-slate-900">{partToRemove.name}</p>
              {partToRemove.code ? (
                <span className="mt-1 inline-block font-mono text-[10px] font-bold text-slate-500 bg-white px-1.5 py-0.5 rounded border border-slate-200">
                  {partToRemove.code}
                </span>
              ) : null}
            </div>
            <p className="text-xs text-slate-600 mb-4">
              Are you sure you want to remove this item from the required parts list?
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setPartToRemove(null)}
                className="rounded-xl border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 active:bg-slate-100 transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmRemove}
                className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white shadow-sm hover:bg-rose-700 active:scale-95 transition-all"
              >
                Confirm Remove
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function WorkOrders() {
  const canView = hasAdminPermission("workOrder.view");
  const canCreate = hasAdminPermission("workOrder.create");
  const canUpdateDetails = hasAdminPermission("workOrder.updateDetails");
  const canUpdateStatus = hasAdminPermission("workOrder.updateStatus");
  const canViewQuotation = hasAdminPermission("workOrder.viewQuotation");
  const canManageQuotation = hasAdminPermission("workOrder.manageQuotation");
  const signedInRole = (getSignedInAdmin().role || "").toLowerCase();
  const isAdminRole = ["admin", "super admin", "superadmin", "administrator"].includes(signedInRole);
  const isHeadManagerRole = ["head manager", "headmanager"].includes(signedInRole);
  const canManagePartsStatus = isAdminRole || isHeadManagerRole;
  const canRollbackStatus = isAdminRole || isHeadManagerRole;
  const { t } = useLanguage();
  const [searchParams, setSearchParams] = useSearchParams();

  // Filters from searchParams
  const initialStatus = searchParams.get("status") || "";
  const initialVehicleId = searchParams.get("vehicleId") || "";
  const initialRecordScope = searchParams.get("view") === "history" || initialStatus === "collected" ? "history" : "active";

  // Core list states
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([]);
  const [recordScope, setRecordScope] = useState<"active" | "history">(initialRecordScope);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [page, setPage] = useState(1);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");
  const [expandedWorkOrderIds, setExpandedWorkOrderIds] = useState<Set<number>>(() => new Set());

  const displayedWorkOrders = useMemo(() => {
    if (recordScope === "history") {
      return [...workOrders].sort((a, b) => {
        const timeA = new Date(a.collectedAt || a.completedAt || a.checkinAt || 0).getTime();
        const timeB = new Date(b.collectedAt || b.completedAt || b.checkinAt || 0).getTime();
        if (timeA !== timeB) return timeB - timeA;
        return b.id - a.id;
      });
    }
    return [...workOrders].sort((left, right) =>
      (PRIORITY_RANK[left.priority?.trim().toLowerCase()] ?? PRIORITY_RANK.normal) -
      (PRIORITY_RANK[right.priority?.trim().toLowerCase()] ?? PRIORITY_RANK.normal)
    );
  }, [workOrders, recordScope]);

  // Filters
  const [statusFilter, setStatusFilter] = useState(initialStatus);
  const [companyFilter, setCompanyFilter] = useState("");
  const [vehicleFilter, setVehicleFilter] = useState(initialVehicleId);
  const [searchTerm, setSearchTerm] = useState("");
  const [historyDateFrom, setHistoryDateFrom] = useState("");
  const [historyDateTo, setHistoryDateTo] = useState("");

  // Lookup options
  const [companies, setCompanies] = useState<Company[]>([]);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [drivers, setDrivers] = useState<CompanyDriver[]>([]);
  const [staff, setStaff] = useState<StaffMember[]>([]);

  // Modals & form state
  const [selectedWO, setSelectedWO] = useState<WorkOrder | null>(null);
  const [selectedPhoto, setSelectedPhoto] = useState<WorkOrderPhoto | null>(null);
  const [modalMode, setModalMode] = useState<"view" | "create" | "edit" | "status" | "quotation" | null>(null);
  const [formError, setFormError] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  // Creation form state
  const [formIntakeType, setFormIntakeType] = useState<"walk_in" | "rescue">("walk_in");
  const [formCompanyId, setFormCompanyId] = useState<number | "">("");
  const [formVehicleId, setFormVehicleId] = useState<number | "">("");
  const [formRelatedVehicleIds, setFormRelatedVehicleIds] = useState<number[]>([]);
  const [formCustomerId, setFormCustomerId] = useState<number | "">("");
  const [formDriverId, setFormDriverId] = useState<number | "">("");
  const [formForemanId, setFormForemanId] = useState<number | "">("");
  const [formRequestChannel, setFormRequestChannel] = useState("Walk-in");
  const [formReportedProblem, setFormReportedProblem] = useState("");
  const [formCheckinMileage, setFormCheckinMileage] = useState("");
  const [formCheckinAt, setFormCheckinAt] = useState("");
  const [formPriority, setFormPriority] = useState<string>("Normal");
  const [formBay, setFormBay] = useState<string>("");
  const [formEstimatedOut, setFormEstimatedOut] = useState<string>("");
  const [formTechnicianIds, setFormTechnicianIds] = useState<number[]>([]);
  const [formIsBackOrder, setFormIsBackOrder] = useState<boolean>(false);

  // Edit details form state
  const [editPriority, setEditPriority] = useState<string>("Normal");
  const [editBay, setEditBay] = useState<string>("");
  const [editEstimatedOut, setEditEstimatedOut] = useState<string>("");
  const [editTechnicianIds, setEditTechnicianIds] = useState<number[]>([]);
  const [editCheckinMileage, setEditCheckinMileage] = useState<string>("");
  const [editIsBackOrder, setEditIsBackOrder] = useState<boolean>(false);
  const [partsStatus, setPartsStatus] = useState<string>("not_required");
  const [partsExpectedDate, setPartsExpectedDate] = useState("");
  const [partsReference, setPartsReference] = useState("");
  const [partsNotes, setPartsNotes] = useState("");
  const [partsOverrideEnabled, setPartsOverrideEnabled] = useState(false);
  const [partsOverrideReason, setPartsOverrideReason] = useState("");
  const [rollbackConfirmOpen, setRollbackConfirmOpen] = useState(false);
  const [rollbackReason, setRollbackReason] = useState("");
  const [partsOverview, setPartsOverview] = useState<WorkOrderPartsOverview | null>(null);
  const [partsOverviewLoading, setPartsOverviewLoading] = useState(false);
  const [partsOverviewError, setPartsOverviewError] = useState("");
  const [inspectionPartCatalog, setInspectionPartCatalog] = useState<DocumentCatalogPart[]>([]);
  const [inspectionParts, setInspectionParts] = useState<InspectionPartRequirement[]>([]);
  const [inspectionPartsConfirmed, setInspectionPartsConfirmed] = useState(false);
  const [inspectionPartsLoading, setInspectionPartsLoading] = useState(false);
  const [initialInspectionPartsJson, setInitialInspectionPartsJson] = useState("");
  const [partToRemoveModal, setPartToRemoveModal] = useState<{ index: number; name: string; code?: string } | null>(null);
  const [isEditingParts, setIsEditingParts] = useState(false);

  const isInspectionPartsModified = useMemo(() => {
    const currentJson = JSON.stringify(
      inspectionParts.map((r) => ({
        code: (r.code || "").trim().toUpperCase(),
        description: (r.description || "").trim(),
        quantity: Number(r.quantity) || 1,
      }))
    );
    return currentJson !== initialInspectionPartsJson;
  }, [inspectionParts, initialInspectionPartsJson]);
  const calculatedPartsStatus = useMemo(
    () => calculatePartsStatus(partsOverview, selectedWO?.partsStatus || (selectedWO?.partsReadyAt ? "parts_ready" : "not_required"), Boolean(selectedWO?.isBackOrder)),
    [partsOverview, selectedWO?.partsReadyAt, selectedWO?.partsStatus, selectedWO?.isBackOrder],
  );
  const effectivePartsStatus = partsOverrideEnabled ? partsStatus : calculatedPartsStatus;
  const calculatedPartsStatusConfig = getPartsStatusConfig(calculatedPartsStatus, Boolean(selectedWO?.isBackOrder));
  const effectivePartsStatusConfig = getPartsStatusConfig(effectivePartsStatus, Boolean(selectedWO?.isBackOrder));
  const inspectionCatalogBySku = useMemo(() => {
    const map = new Map<string, DocumentCatalogPart>();
    for (const part of inspectionPartCatalog) {
      if (part.sku) {
        map.set(part.sku, part);
        map.set(part.sku.trim().toUpperCase(), part);
        map.set(part.sku.trim().toLowerCase(), part);
      }
      if (part.id) {
        map.set(String(part.id), part);
      }
    }
    return map;
  }, [inspectionPartCatalog]);

  // Sync state with URL params
  useEffect(() => {
    setStatusFilter(searchParams.get("status") || "");
    setVehicleFilter(searchParams.get("vehicleId") || "");
    setRecordScope(searchParams.get("view") === "history" || searchParams.get("status") === "collected" ? "history" : "active");
  }, [searchParams]);

  // Fetch Lookup Data once
  useEffect(() => {
    if (!canCreate && !canUpdateDetails) return;
    async function loadLookups() {
      try {
        const [comps, vehs, custs, driverProfiles, staffMembers] = await Promise.all([
          apiRequest<Company[]>("admin-companies"),
          apiRequest<Vehicle[]>("admin-vehicles"),
          apiRequest<Customer[]>("admin-customers"),
          apiRequest<CompanyDriver[]>("admin-drivers"),
          apiRequest<StaffMember[]>("admin-staff"),
        ]);
        setCompanies(comps || []);
        setVehicles(vehs || []);
        setCustomers(custs || []);
        setDrivers(driverProfiles || []);
        setStaff(staffMembers || []);
      } catch (err) {
        console.error("Error loading lookup lists", err);
      }
    }
    loadLookups();
  }, [canCreate, canUpdateDetails]);

  // Fetch Work Orders on filter/page change
  const fetchWorkOrders = async () => {
    setIsLoading(true);
    setError("");
    try {
      const response = await postApi<{
        workOrders: WorkOrder[];
        pagination?: { total: number; page: number; limit: number; pages: number };
        total?: number;
        totalPages?: number;
      }>("admin-work-orders", {
        canonicalStatus: statusFilter,
        recordScope,
        historyDateFrom: recordScope === "history" ? historyDateFrom : "",
        historyDateTo: recordScope === "history" ? historyDateTo : "",
        companyId: parseInt(companyFilter) || 0,
        vehicleId: parseInt(vehicleFilter) || 0,
        searchTerm: searchTerm.trim(),
        page,
        limit: 10
      });
      setWorkOrders(response.workOrders || []);
      setTotal(response.pagination?.total ?? response.total ?? 0);
      setTotalPages(response.pagination?.pages ?? response.totalPages ?? 1);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load work orders");
      setWorkOrders([]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchWorkOrders();
  }, [statusFilter, companyFilter, vehicleFilter, historyDateFrom, historyDateTo, recordScope, page]);

  // Debounced search trigger
  useEffect(() => {
    const delayDebounce = setTimeout(() => {
      setPage(1);
      fetchWorkOrders();
    }, 400);
    return () => clearTimeout(delayDebounce);
  }, [searchTerm]);

  // Clear filters helper
  const handleClearFilters = () => {
    setStatusFilter("");
    setCompanyFilter("");
    setVehicleFilter("");
    setSearchTerm("");
    setHistoryDateFrom("");
    setHistoryDateTo("");
    setPage(1);
    setSearchParams(recordScope === "history" ? { view: "history" } : {});
  };

  const changeRecordScope = (scope: "active" | "history") => {
    setRecordScope(scope);
    setStatusFilter("");
    setPage(1);
    setSearchParams(scope === "history" ? { view: "history" } : {});
  };

  // Filter vehicles dropdown in Create Form
  const formFilteredVehicles = useMemo(() => {
    if (!formCompanyId) return vehicles;
    return vehicles.filter(v => v.companyId === formCompanyId);
  }, [formCompanyId, vehicles]);

  // Filter drivers/contacts dropdown in Create Form
  const formFilteredCustomers = useMemo(() => {
    if (!formCompanyId) return [];
    return customers.filter(c => c.companyId === formCompanyId);
  }, [formCompanyId, customers]);

  const formFilteredDrivers = useMemo(() => {
    if (!formCompanyId) return [];
    return drivers.filter((driver) => driver.companyId === formCompanyId && driver.status === "Active");
  }, [drivers, formCompanyId]);

  const assignableStaff = useMemo(
    () => staff.filter((member) =>
      member.status === "Active" && ["Foreman", "Technician"].includes(member.role)
    ),
    [staff],
  );

  const activeForemen = useMemo(
    () => staff.filter((member) => member.status === "Active" && member.role === "Foreman"),
    [staff],
  );

  const defaultForemanId = useMemo(
    () => activeForemen[0]?.id || 0,
    [activeForemen],
  );

  const defaultTechnicianId = assignableStaff.find((member) => member.id === 1)?.id
    || assignableStaff[0]?.id
    || 0;

  useEffect(() => {
    if (defaultForemanId && modalMode === "create" && !formForemanId) {
      setFormForemanId(defaultForemanId);
    }
  }, [defaultForemanId, formForemanId, modalMode]);

  useEffect(() => {
    if (!defaultTechnicianId) return;
    if (modalMode === "create" && formTechnicianIds.length === 0) {
      setFormTechnicianIds([defaultTechnicianId]);
    }
    if (modalMode === "edit" && editTechnicianIds.length === 0) {
      setEditTechnicianIds([defaultTechnicianId]);
    }
  }, [defaultTechnicianId, editTechnicianIds.length, formTechnicianIds.length, modalMode]);

  const currentLocalDateTime = () => {
    const now = new Date();
    const offset = now.getTimezoneOffset() * 60_000;
    return new Date(now.getTime() - offset).toISOString().slice(0, 16);
  };

  const openCreateModal = () => {
    setFormIntakeType("walk_in");
    setFormCompanyId("");
    setFormVehicleId("");
    setFormRelatedVehicleIds([]);
    setFormCustomerId("");
    setFormDriverId("");
    setFormForemanId(defaultForemanId || "");
    setFormRequestChannel("Walk-in");
    setFormReportedProblem("");
    setFormCheckinMileage("");
    setFormCheckinAt(currentLocalDateTime());
    setFormPriority("Normal");
    setFormBay("");
    setFormEstimatedOut("");
    setFormTechnicianIds(defaultTechnicianId ? [defaultTechnicianId] : []);
    setFormIsBackOrder(false);
    setFormError("");
    setModalMode("create");
  };

  const openEditModal = (wo: WorkOrder) => {
    setSelectedWO(wo);
    setEditPriority(wo.priority || "Normal");
    setEditBay(wo.bay || "");
    setEditEstimatedOut(wo.estimatedOut || "");
    setEditCheckinMileage(wo.checkinMileage !== null && wo.checkinMileage !== undefined ? String(wo.checkinMileage) : "");
    const existingTechnicianId = wo.technicians?.[0]?.id || defaultTechnicianId;
    setEditTechnicianIds(existingTechnicianId ? [existingTechnicianId] : []);
    setEditIsBackOrder(Boolean(wo.isBackOrder));
    setFormError("");
    setModalMode("edit");
  };

  const openStatusModal = (wo: WorkOrder) => {
    if (wo.hasUnacknowledgedParts) {
      openPartsReviewModal(wo);
      return;
    }
    setSelectedWO(wo);
    setPartsStatus(wo.partsStatus || (wo.partsReadyAt ? "parts_ready" : "not_required"));
    setPartsExpectedDate(wo.partsExpectedDate || "");
    setPartsReference(wo.partsReference || "");
    setPartsNotes(wo.partsNotes || "");
    setPartsOverrideEnabled(false);
    setPartsOverrideReason("");
    setRollbackConfirmOpen(false);
    setRollbackReason("");
    setPartsOverview(null);
    setPartsOverviewError("");
    setPartsOverviewLoading(true);
    loadWorkOrderPartsOverview(wo.id)
      .then((overview) => {
        setPartsOverview(overview);
        setPartsStatus(calculatePartsStatus(overview, wo.partsStatus || (wo.partsReadyAt ? "parts_ready" : "not_required"), Boolean(wo.isBackOrder)));
      })
      .catch((caught) => setPartsOverviewError(caught instanceof Error ? caught.message : "Unable to load stock availability."))
      .finally(() => setPartsOverviewLoading(false));
    setInspectionPartsConfirmed(wo.canonicalStatus !== "checked_in");
    setInspectionParts([]);
    setIsEditingParts(false);
    setInspectionPartsLoading(true);
    Promise.all([
      apiRequest<DocumentCatalogPart[]>("admin-parts").catch(() => []),
      apiRequest<InspectionPartRequirement[]>(`admin-get-work-order-part-requirements&id=${wo.id}`).catch(() => []),
    ]).then(([catalog, requirements]) => {
      setInspectionPartCatalog(catalog);
      const validRequirements = requirements.filter((item) => Boolean(item.code?.trim() || item.description?.trim() || item.partId));
      setInspectionParts(validRequirements);
      setInitialInspectionPartsJson(
        JSON.stringify(
          validRequirements.map((r) => ({
            code: (r.code || "").trim().toUpperCase(),
            description: (r.description || "").trim(),
            quantity: Number(r.quantity) || 1,
          }))
        )
      );
    }).finally(() => setInspectionPartsLoading(false));
    setFormError("");
    setModalMode("status");
  };

  const openViewModal = (wo: WorkOrder) => {
    setSelectedWO(wo);
    setFormError("");
    setModalMode("view");
  };

  const openPartsReviewModal = (wo: WorkOrder) => {
    setSelectedWO(wo);
    setFormError("");
    setModalMode("review_parts");
  };

  const handleAcknowledgeParts = async () => {
    if (!selectedWO) return;
    try {
      await postApi("admin-acknowledge-work-order-parts", { workOrderId: selectedWO.id });
      setWorkOrders((current) =>
        current.map((wo) =>
          wo.id === selectedWO.id
            ? { ...wo, hasUnacknowledgedParts: false, partsAcknowledgedAt: new Date().toISOString() }
            : wo
        )
      );
      window.dispatchEvent(new CustomEvent("work-order-parts-updated"));
      toast.success("Parts update acknowledged successfully.");
      closeModal();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to acknowledge parts update.");
    }
  };

  const openQuotationModal = (wo: WorkOrder) => {
    setSelectedWO(wo);
    setFormError("");
    setModalMode("quotation");
  };

  const closeModal = () => {
    setSelectedPhoto(null);
    setSelectedWO(null);
    setModalMode(null);
    setFormError("");
  };

  useEffect(() => {
    if (!selectedPhoto) return;
    const closePhotoOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSelectedPhoto(null);
    };
    window.addEventListener("keydown", closePhotoOnEscape);
    return () => window.removeEventListener("keydown", closePhotoOnEscape);
  }, [selectedPhoto]);

  // Form submit handlers
  const handleCreateWorkOrder = async () => {
    setFormError("");
    if (!formCompanyId) {
      setFormError("Company selection is required.");
      return;
    }
    if (!formVehicleId) {
      setFormError("Vehicle selection is required.");
      return;
    }
    if (!formReportedProblem.trim()) {
      setFormError("Customer request is required.");
      return;
    }
    if (!formCheckinAt) {
      setFormError("Check-in date and time are required.");
      return;
    }

    setIsSaving(true);
    try {
      await postApi("admin-create-work-order", {
        companyId: formCompanyId,
        vehicleId: formVehicleId,
        relatedVehicleIds: formRelatedVehicleIds,
        customerId: formCustomerId || null,
        intakeType: formIntakeType,
        driverId: formDriverId || null,
        foremanId: formForemanId || null,
        requestChannel: formRequestChannel,
        reportedProblem: formReportedProblem.trim(),
        checkinMileage: formCheckinMileage === "" ? null : Number(formCheckinMileage),
        checkinAt: formCheckinAt,
        priority: formPriority,
        bay: formBay || null,
        estimatedOut: formEstimatedOut || null,
        technicianIds: formTechnicianIds,
        isBackOrder: formIsBackOrder,
      });
      fetchWorkOrders();
      closeModal();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Failed to create work order.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleUpdateWorkOrderDetails = async () => {
    if (!selectedWO) return;
    setFormError("");

    setIsSaving(true);
    try {
      await postApi("admin-update-work-order", {
        id: selectedWO.id,
        priority: editPriority,
        bay: editBay || null,
        estimatedOut: editEstimatedOut || null,
        technicianIds: editTechnicianIds,
        checkinMileage: editCheckinMileage !== "" ? Number(editCheckinMileage) : null,
        isBackOrder: editIsBackOrder,
      });
      fetchWorkOrders();
      closeModal();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Failed to update work order details.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleUpdateStatus = async (targetStatus: string) => {
    if (!selectedWO) return;
    if (targetStatus !== "inspected" && selectedWO.hasUnacknowledgedParts) {
      setFormError("Please review and acknowledge newly added parts before updating work order status.");
      return;
    }
    setFormError("");

    setIsSaving(true);
    try {
      if (targetStatus === "inspected") {
        if (!inspectionPartsConfirmed) throw new Error("Confirm the inspection parts assessment before completing inspection.");
        const validParts = inspectionParts.filter((item) => item.description.trim() || item.code.trim());
        if (validParts.some((item) => !item.description.trim() || Number(item.quantity) <= 0)) throw new Error("Every required part needs a description and quantity greater than zero.");
        await postApi("admin-save-work-order-part-requirements", { workOrderId: selectedWO.id, items: validParts });
      }
      await postApi("admin-update-work-order", {
        id: selectedWO.id,
        canonicalStatus: targetStatus
      });
      fetchWorkOrders();
      closeModal();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Failed to update status.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleUpdatePartsStatus = async () => {
    if (!selectedWO || !canManagePartsStatus) return;
    setFormError("");
    setIsSaving(true);
    try {
      if (!partsOverview) throw new Error("Wait for live stock availability to load before saving Parts Status.");
      if (partsOverrideEnabled && partsOverrideReason.trim().length < 5) {
        throw new Error("Enter a clear override reason of at least 5 characters.");
      }
      await postApi("admin-update-work-order", {
        id: selectedWO.id,
        partsStatus: calculatedPartsStatus,
        partsExpectedDate: ["pending_parts", "partially_arrived"].includes(calculatedPartsStatus) ? partsExpectedDate || null : null,
      });
      await fetchWorkOrders();
      closeModal();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Failed to update Parts Status.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveRequiredParts = async () => {
    if (!selectedWO) return;
    setFormError("");
    setIsSaving(true);
    try {
      const validParts = inspectionParts.filter((item) => item.description.trim() || item.code.trim());
      if (validParts.some((item) => !item.description.trim() || Number(item.quantity) <= 0)) {
        throw new Error("Every required part needs a description and quantity greater than zero.");
      }
      await postApi("admin-save-work-order-part-requirements", { workOrderId: selectedWO.id, items: validParts });
      setInitialInspectionPartsJson(
        JSON.stringify(
          validParts.map((r) => ({
            code: (r.code || "").trim().toUpperCase(),
            description: (r.description || "").trim(),
            quantity: Number(r.quantity) || 1,
          }))
        )
      );
      toast.success("Required parts updated.");
      setIsEditingParts(false);
      setPartsOverviewLoading(true);
      const overview = await loadWorkOrderPartsOverview(selectedWO.id);
      setPartsOverview(overview);
      const newCalculatedStatus = calculatePartsStatus(overview, selectedWO.partsStatus || (selectedWO.partsReadyAt ? "parts_ready" : "not_required"), Boolean(selectedWO.isBackOrder));
      setPartsStatus(newCalculatedStatus);
      await fetchWorkOrders();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Failed to save required parts.");
    } finally {
      setPartsOverviewLoading(false);
      setIsSaving(false);
    }
  };

  const handleRollbackStatus = async () => {
    if (!selectedWO || !canRollbackStatus) return;
    if (rollbackReason.trim().length < 1) {
      setFormError("Enter a rollback reason (at least 1 character).");
      return;
    }
    setFormError("");
    setIsSaving(true);
    try {
      await postApi("admin-rollback-work-order", { id: selectedWO.id, reason: rollbackReason.trim() });
      await fetchWorkOrders();
      closeModal();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Unable to roll back work order status.");
    } finally {
      setIsSaving(false);
    }
  };

  const getAllowedNextStatuses = (currentStatus: string, currentPartsStatus = "not_required", isBackOrder = false) => {
    const nextStatuses = WORK_ORDER_TRANSITIONS[currentStatus] || [];
    const isPartsPending = !isBackOrder && ["pending_parts", "partially_arrived"].includes(currentPartsStatus);
    const availableStatuses = isPartsPending
      ? nextStatuses.filter((status) => !["under_repair", "ready_for_collection", "collected"].includes(status))
      : nextStatuses;
    if (["manager", "head manager", "service advisor", "receptionist"].includes(signedInRole)) {
      return availableStatuses.filter((status) => HEAD_MANAGER_LIFECYCLE_STATUSES.has(status));
    }
    if (["foreman", "technician", "mechanic", "editor"].includes(signedInRole)) {
      return availableStatuses.filter((status) => TECHNICIAN_LIFECYCLE_STATUSES.has(status));
    }
    return availableStatuses;
  };

  // Badge styler helper
  const getStatusBadge = (status: string) => {
    const config: Record<string, string> = {
      scheduled: "border-sky-200 bg-sky-50 text-sky-700",
      checked_in: "border-indigo-200 bg-indigo-50 text-indigo-700",
      inspected: "border-purple-200 bg-purple-50 text-purple-700",
      quotation_issued: "border-cyan-200 bg-cyan-50 text-cyan-700",
      approved: "border-teal-200 bg-teal-50 text-teal-700",
      parts_ready: "border-emerald-200 bg-emerald-50 text-emerald-700",
      under_repair: "border-blue-200 bg-blue-50 text-blue-700",
      ready_for_collection: "border-emerald-200 bg-emerald-50 text-emerald-700",
      collected: "border-slate-200 bg-slate-100 text-slate-600"
    };
    return config[status] || "border-slate-200 bg-slate-50 text-slate-700";
  };

  const getPriorityBadge = (priority: string) => {
    const config: Record<string, string> = {
      Normal: "border-slate-200 bg-slate-50 text-slate-700",
      High: "border-amber-200 bg-amber-50 text-amber-700",
      Urgent: "border-rose-200 bg-rose-50 text-rose-700"
    };
    return config[priority] || "border-slate-200 bg-slate-50 text-slate-700";
  };

  const getPriorityCardAccent = (priority: string) => {
    const config: Record<string, string> = {
      Normal: "maw-priority-card maw-priority-normal bg-white",
      High: "maw-priority-card maw-priority-high bg-[#fffaf0]",
      Urgent: "maw-priority-card maw-priority-urgent bg-[#fff5f5]",
    };
    return config[priority] || config.Normal;
  };

  if (modalMode === "quotation" && selectedWO) {
    return (
      <WorkOrderQuotationDialog
        workOrder={selectedWO}
        canManage={canManageQuotation}
        onClose={closeModal}
        onChanged={fetchWorkOrders}
      />
    );
  }

  if (modalMode === "create") {
    return (
      <div className="space-y-4">
        {/* Header with Back Button */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={closeModal}
              className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Work Orders
            </button>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-extrabold text-slate-900">
                  {formIntakeType === "rescue" ? "New Emergency Rescue Intake" : "New Walk-in Intake"}
                </h1>
                <span className={`rounded-full px-2.5 py-0.5 text-[10px] font-black uppercase tracking-wider ${
                  formIntakeType === "rescue" ? "bg-red-100 text-red-700 border border-red-200" : "bg-blue-50 text-blue-700"
                }`}>
                  {formIntakeType === "rescue" ? "Emergency Rescue" : "Walk-in"}
                </span>
              </div>
              <p className="mt-0.5 text-xs text-slate-500">
                {formIntakeType === "rescue"
                  ? "Record an on-road breakdown rescue, towing, or emergency on-site repair work order."
                  : "Check in an unscheduled vehicle and create its work order directly in the workshop."}
              </p>
            </div>
          </div>
        </div>

        {/* Intake Type Selector */}
        <div className="grid grid-cols-2 gap-3 p-1.5 rounded-2xl bg-slate-100/90 border border-slate-200">
          <button
            type="button"
            onClick={() => {
              setFormIntakeType("walk_in");
              if (formPriority === "Urgent") setFormPriority("Normal");
              setFormRequestChannel("Walk-in");
            }}
            className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-extrabold transition-all ${
              formIntakeType === "walk_in"
                ? "bg-white text-[#173b75] shadow-sm ring-1 ring-slate-200/60"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <Building2 className="h-4 w-4" />
            Walk-in Intake (到厂接待)
          </button>
          <button
            type="button"
            onClick={() => {
              setFormIntakeType("rescue");
              setFormPriority("Urgent");
              setFormRequestChannel("Rescue Hotline");
            }}
            className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-extrabold transition-all ${
              formIntakeType === "rescue"
                ? "bg-gradient-to-r from-red-600 to-rose-600 text-white shadow-md shadow-red-500/20 ring-1 ring-red-400"
                : "text-red-700 hover:bg-red-50/50"
            }`}
          >
            <PhoneCall className="h-4 w-4" />
            Emergency Rescue (道路紧急救援)
          </button>
        </div>

        {formError && (
          <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm font-medium text-red-600">
            {formError}
          </div>
        )}

        <div className="space-y-4">
          <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div className="flex items-start gap-3 rounded-t-xl border-b border-slate-100 bg-white px-4 py-3.5 sm:px-5">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-50 text-blue-700">
                <Building2 className="h-4 w-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">1. Vehicle &amp; company</h3>
                <p className="mt-0.5 text-xs text-slate-500">Choose vehicle unit no or plate no to automatically populate company and fleet contacts.</p>
              </div>
            </div>
            <div className="space-y-4 p-4 sm:p-5">
              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">
                  Vehicle (Unit No / Reg No) *
                </label>
                <SearchableVehicleSelect
                  vehicles={formFilteredVehicles}
                  companies={companies}
                  value={formVehicleId}
                  onChange={(nextVehicleId) => {
                    setFormVehicleId(nextVehicleId);
                    if (nextVehicleId) {
                      setFormRelatedVehicleIds((current) => current.filter((id) => id !== nextVehicleId));
                      const chosenVeh = vehicles.find((v) => v.id === nextVehicleId);
                      if (chosenVeh && chosenVeh.companyId) {
                        setFormCompanyId(chosenVeh.companyId);
                      }
                    } else {
                      setFormRelatedVehicleIds([]);
                    }
                  }}
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">
                  Company (Automatic)
                </label>
                {formCompanyId ? (
                  <div className="flex h-10 w-full items-center justify-between rounded-lg border border-slate-200 bg-slate-50/80 px-3 py-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Building2 className="h-4 w-4 text-blue-700 shrink-0" />
                      <span className="font-bold text-gray-900">
                        {companies.find((c) => c.id === formCompanyId)?.name || `Company #${formCompanyId}`}
                      </span>
                      {companies.find((c) => c.id === formCompanyId)?.autocountDebtorCode ? (
                        <span className="rounded bg-blue-100 px-1.5 py-0.5 font-mono text-[10px] font-bold text-blue-800">
                          {companies.find((c) => c.id === formCompanyId)?.autocountDebtorCode}
                        </span>
                      ) : null}
                    </div>
                    <span className="text-[11px] font-semibold text-emerald-700 shrink-0">✓ Auto-identified</span>
                  </div>
                ) : (
                  <div className="flex h-10 w-full items-center rounded-lg border border-dashed border-slate-200 bg-slate-50/50 px-3 py-2 text-xs text-gray-400">
                    <Building2 className="mr-2 h-4 w-4 text-gray-300 shrink-0" />
                    Automatically identified once a vehicle is selected above.
                  </div>
                )}
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">
                  Company User Contact (Optional)
                </label>
                <AdminSelect
                  value={formCustomerId}
                  disabled={!formCompanyId}
                  onChange={(e) => setFormCustomerId(e.target.value ? parseInt(e.target.value) : "")}
                  className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500 disabled:bg-gray-50 disabled:opacity-60"
                >
                  <option value="">-- Select Company User / Contact --</option>
                  {formFilteredCustomers.map(c => (
                    <option key={c.id} value={c.id}>{c.name} ({c.type})</option>
                  ))}
                </AdminSelect>
              </div>
            </div>
          </section>

          <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div className="flex items-start gap-3 rounded-t-xl border-b border-slate-100 bg-white px-4 py-3.5 sm:px-5">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-50 text-amber-700">
                <Wrench className="h-4 w-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">2. Service request</h3>
                <p className="mt-0.5 text-xs text-slate-500">Record customer repair request and intake foreman.</p>
              </div>
            </div>
            <div className="space-y-4 p-4 sm:p-5">
              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">Foreman / Intake Owner</label>
                <AdminSelect
                  value={formForemanId}
                  onChange={(e) => setFormForemanId(e.target.value ? parseInt(e.target.value) : "")}
                  className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                >
                  <option value="">-- Unassigned --</option>
                  {activeForemen.map(member => <option key={member.id} value={member.id}>{member.name} ({member.role})</option>)}
                </AdminSelect>
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">Customer Request *</label>
                <textarea
                  rows={3}
                  value={formReportedProblem}
                  onChange={(e) => setFormReportedProblem(e.target.value)}
                  placeholder="What did the customer ask us to inspect or repair?"
                  className="w-full resize-y rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>
            </div>
          </section>

          <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div className="flex items-start gap-3 rounded-t-xl border-b border-slate-100 bg-white px-4 py-3.5 sm:px-5">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-50 text-indigo-700">
                <CalendarClock className="h-4 w-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">3. Check-in &amp; assignment</h3>
                <p className="mt-0.5 text-xs text-slate-500">Set arrival details, workshop priority and initial ownership.</p>
              </div>
            </div>
            <div className="space-y-4 p-4 sm:p-5">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">Check-in Mileage</label>
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={formCheckinMileage}
                    onChange={(e) => setFormCheckinMileage(e.target.value)}
                    placeholder="e.g. 125000"
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">Check-in Time *</label>
                  <DesktopDateTimePicker value={formCheckinAt} onChange={setFormCheckinAt} required />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">
                    Priority Level
                  </label>
                  <AdminSelect
                    value={formPriority}
                    onChange={(e) => setFormPriority(e.target.value)}
                    className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    {PRIORITIES.map(p => (
                      <option key={p} value={p}>{p}</option>
                    ))}
                  </AdminSelect>
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">
                    Workshop Bay
                  </label>
                  <AdminSelect
                    value={formBay}
                    onChange={(e) => setFormBay(e.target.value)}
                    className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="">Unassigned</option>
                    {BAYS.map(b => (
                      <option key={b} value={b}>{b}</option>
                    ))}
                  </AdminSelect>
                </div>
              </div>

              {/* Back Order Switch */}
              <div className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 bg-slate-50 p-3 shadow-2xs">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-slate-800">Back Order</span>
                    {formIsBackOrder ? (
                      <span className="rounded-full bg-purple-100 px-2 py-0.5 text-[10px] font-bold text-purple-700">
                        Bypass Stock
                      </span>
                    ) : null}
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {formIsBackOrder
                      ? "Enabled: Proceed even if parts are out of stock (protects VIP reserved inventory)."
                      : "Disabled: Standard inventory stock availability rules apply."}
                  </p>
                </div>
                <label className="relative inline-flex cursor-pointer items-center">
                  <input
                    type="checkbox"
                    checked={formIsBackOrder}
                    onChange={(e) => setFormIsBackOrder(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-purple-600"></div>
                </label>
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">
                  Expected Completion Date
                </label>
                <DesktopDatePicker
                  value={formEstimatedOut}
                  onChange={setFormEstimatedOut}
                  ariaLabel="Choose expected completion date"
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">
                  Assigned Repair Person
                </label>
                <StaffSelect staff={assignableStaff} selectedIds={formTechnicianIds} onChange={setFormTechnicianIds} />
              </div>
            </div>
          </section>
        </div>

        <div className="flex flex-col-reverse gap-3 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <p className="text-xs text-slate-500"><span className="font-bold text-red-500">*</span> Required fields must be completed</p>
          <div className="flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={closeModal}
              className="h-10 rounded-xl border border-slate-300 bg-white px-5 text-sm font-semibold text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={isSaving}
              onClick={handleCreateWorkOrder}
              className="inline-flex h-10 items-center gap-2 rounded-xl bg-[#1e3a8a] px-6 text-sm font-semibold text-white shadow-sm hover:bg-blue-800 disabled:opacity-50"
            >
              <Save className="h-4 w-4" />{isSaving ? "Checking in..." : "Create Walk-in"}
            </button>
          </div>
        </div>
      </div>
    );
  }

  const handleExportWorkOrders = async () => {
    if (displayedWorkOrders.length === 0) {
      toast.error("No work orders available to export.");
      return;
    }

    const columnDefs: ExcelColumnDef[] = [
      { header: "Work Order No", key: "workOrderNo", align: "left", minWidth: 18, numFmt: "@" },
      { header: "AutoCount Job No", key: "jobNo", align: "left", minWidth: 18, numFmt: "@" },
      { header: "Vehicle Plate", key: "vehicleNo", align: "left", minWidth: 14, numFmt: "@" },
      { header: "Vehicle Brand/Model", key: "vehicleModel", align: "left", minWidth: 22 },
      { header: "Customer / Contact", key: "customerName", align: "left", minWidth: 22 },
      { header: "Company Name", key: "companyName", align: "left", minWidth: 26 },
      { header: "Service Type", key: "serviceType", align: "left", minWidth: 18 },
      { header: "Reported Problem", key: "reportedProblem", align: "left", minWidth: 32 },
      { header: "Assigned Technicians", key: "technicians", align: "left", minWidth: 24 },
      { header: "Bay / Station", key: "bay", align: "left", minWidth: 14 },
      { header: "Status", key: "status", align: "center", minWidth: 16 },
      { header: "Entry / Created Date", key: "createdAt", align: "center", minWidth: 20 },
      { header: "Completed Date", key: "completedAt", align: "center", minWidth: 20 },
      { header: "Total Amount (RM)", key: "totalAmount", align: "right", minWidth: 18, numFmt: "#,##0.00" },
    ];

    const rows = displayedWorkOrders.map((wo) => {
      const techNames = (wo.technicians || []).map((m: any) => m.name).join(", ");
      return {
        workOrderNo: String(wo.workOrderNo || `WO-${wo.id}`),
        jobNo: String(wo.autocountJobNo || "-"),
        vehicleNo: String(wo.vehicleNo || ""),
        vehicleModel: [wo.brand, wo.model].filter(Boolean).join(" "),
        customerName: String(wo.customerName || "-"),
        companyName: String(wo.companyName || "-"),
        serviceType: String(wo.serviceType || "-"),
        reportedProblem: String(wo.reportedProblem || "-"),
        technicians: techNames || "-",
        bay: String(wo.assignedBay || "-"),
        status: String(wo.status || "-"),
        createdAt: wo.createdAt ? String(wo.createdAt).slice(0, 19).replace("T", " ") : "-",
        completedAt: (wo.completedAt || wo.collectedAt) ? String(wo.completedAt || wo.collectedAt).slice(0, 19).replace("T", " ") : "-",
        totalAmount: Number(wo.totalAmount ?? wo.quotationTotal ?? wo.estimatedCost ?? 0),
      };
    });

    const fileName = `maw-work-orders-${recordScope}-${new Date().toISOString().slice(0, 10)}.xlsx`;
    await exportTableToExcel({
      fileName,
      sheetName: recordScope === "history" ? "Completed Orders" : "Active Work Orders",
      columns: columnDefs,
      data: rows,
      successMessage: `Exported ${displayedWorkOrders.length} work orders to ${fileName}`,
    });
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{t('work_orders')}</h1>
        </div>
        <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row sm:items-center">
          <div className="inline-flex h-10 w-full items-center rounded-xl border border-slate-200 bg-white p-1 shadow-sm sm:w-auto" role="tablist" aria-label="Work order records">
            <button
              type="button"
              role="tab"
              aria-selected={recordScope === "active"}
              onClick={() => changeRecordScope("active")}
              className={`inline-flex h-8 flex-1 items-center justify-center rounded-lg px-4 text-xs font-bold transition-colors sm:flex-none ${recordScope === "active" ? "bg-[#1e3a8a] text-white shadow-sm" : "text-slate-600 hover:bg-slate-50"}`}
            >
              <ListTodo className="mr-1.5 h-3.5 w-3.5" />Active Work Orders
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={recordScope === "history"}
              onClick={() => changeRecordScope("history")}
              className={`inline-flex h-8 flex-1 items-center justify-center rounded-lg px-4 text-xs font-bold transition-colors sm:flex-none ${recordScope === "history" ? "bg-[#1e3a8a] text-white shadow-sm" : "text-slate-600 hover:bg-slate-50"}`}
            >
              <HistoryIcon className="mr-1.5 h-3.5 w-3.5" />History
            </button>
          </div>
          <button
            type="button"
            onClick={handleExportWorkOrders}
            disabled={isLoading || displayedWorkOrders.length === 0}
            className="inline-flex h-10 items-center justify-center rounded-xl border border-gray-300 bg-white px-4 text-sm font-semibold text-gray-700 shadow-sm transition-colors hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Download className="mr-2 h-4 w-4" />
            Export Excel
          </button>
          {canCreate ? <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex h-10 items-center justify-center rounded-xl bg-[#1e3a8a] px-4 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-blue-800"
          >
            <Plus className="mr-2 h-4 w-4" />
            New Walk-in
          </button> : null}
        </div>
      </div>

      {/* Filters Panel */}
      <div className="maw-filter-bar">
        <div className={`grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 ${recordScope === "history" ? "xl:grid-cols-[minmax(220px,1.6fr)_repeat(6,minmax(130px,1fr))]" : "xl:grid-cols-[minmax(260px,2fr)_repeat(4,minmax(150px,1fr))]"}`}>
          {/* Text Search */}
          <div className="maw-search-field">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search WO#, plate, or vehicle..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm"
            />
          </div>

          {/* Status Filter */}
          <AdminSelect
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm bg-white"
            aria-label="Filter work order status"
          >
            <option value="">{recordScope === "active" ? "All Active Statuses" : "Collected"}</option>
            {STATUSES.filter((status) => recordScope === "active" ? status !== "collected" : status === "collected").map(s => (
              <option key={s} value={s}>{t(`status_${s}`)}</option>
            ))}
          </AdminSelect>

          {recordScope === "history" ? (
            <DesktopDatePicker
              value={historyDateFrom}
              onChange={(value) => { setHistoryDateFrom(value); setPage(1); }}
              placeholder="Completed from"
              ariaLabel="Filter history completed from date"
              className="maw-filter-control"
            />
          ) : null}

          {recordScope === "history" ? (
            <DesktopDatePicker
              value={historyDateTo}
              onChange={(value) => { setHistoryDateTo(value); setPage(1); }}
              placeholder="Completed to"
              ariaLabel="Filter history completed to date"
              className="maw-filter-control"
            />
          ) : null}

          {/* Company Filter */}
          <AdminSelect
            value={companyFilter}
            onChange={(e) => { setCompanyFilter(e.target.value); setPage(1); }}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm bg-white"
            aria-label="Filter work order company"
          >
            <option value="">All Companies</option>
            {companies.map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </AdminSelect>

          {/* Vehicle Filter */}
          <AdminSelect
            value={vehicleFilter}
            onChange={(e) => { setVehicleFilter(e.target.value); setPage(1); }}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm bg-white"
            aria-label="Filter work order vehicle"
          >
            <option value="">All Vehicles</option>
            {vehicles.map(v => (
              <option key={v.id} value={v.id}>{v.regNo} ({v.brand})</option>
            ))}
          </AdminSelect>

          {/* Action buttons */}
          <button
            type="button"
            onClick={handleClearFilters}
            className="maw-filter-action w-full border border-gray-300 px-3 text-gray-700 font-semibold hover:bg-gray-50 transition-colors"
          >
            Clear Filters
          </button>
        </div>
      </div>

      {/* Work Order Lifecycle Cards */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="rounded-xl border border-gray-200 bg-white px-6 py-12 text-center shadow-sm">
            <Clock className="mx-auto mb-2 h-6 w-6 animate-spin text-gray-400" />
            <p className="text-sm text-gray-500">Loading work orders...</p>
          </div>
        ) : error ? (
          <div className="rounded-2xl border border-red-100 bg-white px-6 py-12 text-center shadow-sm">
            <AlertCircle className="mx-auto mb-2 h-6 w-6 text-red-500" />
            <p className="text-sm font-medium text-red-700">Unable to load work orders</p>
            <p className="mt-1 text-xs text-red-600">{error}</p>
            <button
              type="button"
              onClick={fetchWorkOrders}
              className="mt-3 rounded-lg border border-red-200 px-3 py-1.5 text-xs font-semibold text-red-700 hover:bg-red-50"
            >
              Try Again
            </button>
          </div>
        ) : workOrders.length === 0 ? (
          <div className="rounded-xl border border-gray-200 bg-white px-6 py-12 text-center text-sm text-gray-500 shadow-sm">
            {recordScope === "active" ? "No active work orders found matching these criteria." : "No completed work orders found in history."}
          </div>
        ) : recordScope === "history" ? (
          <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-200 text-left text-xs">
                <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                  <tr>
                    <th scope="col" className="px-4 py-3.5">Work Order</th>
                    <th scope="col" className="px-4 py-3.5">Vehicle</th>
                    <th scope="col" className="px-4 py-3.5">Customer / Company</th>
                    <th scope="col" className="px-4 py-3.5">Service & Problem</th>
                    <th scope="col" className="px-4 py-3.5">Assigned Team / Bay</th>
                    <th scope="col" className="px-4 py-3.5">Completed Date</th>
                    <th scope="col" className="px-4 py-3.5 text-center">Status</th>
                    <th scope="col" className="px-4 py-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {displayedWorkOrders.map((wo) => {
                    const technicianNames = (wo.technicians || []).map((member) => member.name).join(", ");
                    const completedDate = wo.collectedAt || wo.completedAt;
                    return (
                      <tr key={wo.id} className="transition-colors hover:bg-slate-50/80">
                        <td className="px-4 py-3.5">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-extrabold text-[#173b75]">{wo.workOrderNo}</span>
                            {wo.isBackOrder ? (
                              <span className="inline-flex items-center rounded-full border border-purple-200 bg-purple-50 px-2.5 py-0.5 text-xs font-semibold text-purple-700 whitespace-nowrap">
                                <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                                Back Order
                              </span>
                            ) : null}
                            {isRescueWorkOrder(wo) ? (
                              <span className="inline-flex items-center rounded-full border border-red-200 bg-red-50 px-2.5 py-0.5 text-xs font-semibold text-red-700 whitespace-nowrap">
                                <PhoneCall className="mr-1 h-3 w-3" />
                                Rescue
                              </span>
                            ) : null}
                            {wo.photos?.length ? (
                              <span className="inline-flex items-center rounded-full border border-violet-200 bg-violet-50 px-2.5 py-0.5 text-xs font-semibold text-violet-700 whitespace-nowrap" title={`${wo.photos.length} workshop photos`}>
                                <Camera className="mr-1 h-3 w-3" />{wo.photos.length}
                              </span>
                            ) : null}
                          </div>
                          {wo.autocountJobNo ? (
                            <p className="mt-0.5 font-mono text-[10px] text-slate-400">Job: {wo.autocountJobNo}</p>
                          ) : (
                            <p className="mt-0.5 text-[10px] text-slate-400">ID #{wo.id}</p>
                          )}
                        </td>
                        <td className="px-4 py-3.5">
                          <p className="font-bold text-slate-900">{wo.vehicleNo}</p>
                          <p className="text-[11px] text-slate-500">{wo.brand} {wo.model}</p>
                          {wo.equipmentType && wo.equipmentType !== "-" ? (
                            <span className="text-[10px] text-slate-400">{wo.equipmentType}</span>
                          ) : null}
                        </td>
                        <td className="px-4 py-3.5">
                          <p className="font-semibold text-slate-800">{wo.companyName || "-"}</p>
                          {wo.contactName && wo.contactName !== "-" ? (
                            <p className="text-[11px] text-slate-500">{wo.contactName}{wo.customerPhone ? ` · ${wo.customerPhone}` : ""}</p>
                          ) : wo.customerPhone ? (
                            <p className="text-[11px] text-slate-500">{wo.customerPhone}</p>
                          ) : null}
                        </td>
                        <td className="px-4 py-3.5 max-w-xs">
                          <p className="font-semibold text-slate-800 truncate">{wo.serviceType || "Service / Repair"}</p>
                          {wo.reportedProblem ? (
                            <p className="truncate text-[11px] text-slate-500" title={wo.reportedProblem}>{wo.reportedProblem}</p>
                          ) : (
                            <p className="text-[11px] text-slate-400">No issue specified</p>
                          )}
                        </td>
                        <td className="px-4 py-3.5">
                          <p className="font-medium text-slate-800">{technicianNames || wo.foremanName || "-"}</p>
                          <p className="text-[11px] text-slate-500">{wo.bay ? `Bay: ${wo.bay}` : "Bay: Unassigned"}</p>
                        </td>
                        <td className="px-4 py-3.5 whitespace-nowrap">
                          <p className="font-semibold text-slate-800">{completedDate ? formatStageTimestamp(completedDate) : "-"}</p>
                          {wo.checkinAt ? (
                            <p className="text-[10px] text-slate-400">In: {formatStageTimestamp(wo.checkinAt)}</p>
                          ) : null}
                        </td>
                        <td className="px-4 py-3.5 text-center whitespace-nowrap">
                          <span className={getStatusBadge(wo.canonicalStatus)}>{t(`status_${wo.canonicalStatus}`)}</span>
                        </td>
                        <td className="px-4 py-3.5 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-1.5">
                            {canView ? (
                              <button
                                type="button"
                                onClick={() => openViewModal(wo)}
                                className="inline-flex items-center rounded-lg border border-blue-200 bg-white px-2.5 py-1.5 text-xs font-semibold text-blue-700 shadow-xs transition-colors hover:border-blue-300 hover:bg-blue-50"
                                title="View Details"
                              >
                                <Eye className="mr-1 h-3.5 w-3.5" />View Details
                              </button>
                            ) : null}
                            {canViewQuotation ? (
                              <button
                                type="button"
                                onClick={() => openQuotationModal(wo)}
                                className="inline-flex items-center rounded-lg border border-cyan-600 bg-cyan-600 px-2.5 py-1.5 text-xs font-bold text-white shadow-xs transition-colors hover:bg-cyan-700 hover:border-cyan-700"
                                title="Quotation"
                              >
                                <FileText className="mr-1 h-3.5 w-3.5 text-white" />Quotation
                              </button>
                            ) : null}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          displayedWorkOrders.map((wo) => {
            const currentStageIndex = Math.max(0, WORK_ORDER_STAGES.findIndex((stage) => stage.key === wo.canonicalStatus));
            const allowedNextStatuses = getAllowedNextStatuses(wo.canonicalStatus, wo.partsStatus || "not_required", Boolean(wo.isBackOrder));
            const technicianNames = (wo.technicians || []).map((member) => member.name).join(", ");
            const activeDateBadge = recordScope === "active" ? getActiveDateBadge(getActiveDateGroup(wo)) : null;
            const isExpanded = expandedWorkOrderIds.has(wo.id);
            const isHistory = recordScope === "history" || wo.canonicalStatus === "collected";
            const effectivePriority = isHistory ? "Normal" : (wo.priority || "Normal");
            const partsStatusConfig = getPartsStatusConfig(wo.partsStatus || (wo.partsReadyAt ? "parts_ready" : null), Boolean(wo.isBackOrder));
            const partsStatusAvailable = currentStageIndex >= WORK_ORDER_STAGES.findIndex((stage) => stage.key === "approved");
            const lifecycleProgress = Math.round((currentStageIndex / (WORK_ORDER_STAGES.length - 1)) * 100);

            return (
              <article
                key={wo.id}
                className={`overflow-hidden rounded-2xl border border-l-4 transition-[border-color,box-shadow,background-color] duration-300 ${getPriorityCardAccent(effectivePriority)} ${
                  wo.hasUnacknowledgedParts
                    ? "border-amber-400 shadow-[0_8px_24px_rgba(245,158,11,0.18)] ring-2 ring-amber-300/60"
                    : isExpanded
                    ? "border-blue-300 shadow-[0_8px_24px_rgba(30,58,138,0.12)] ring-1 ring-blue-100"
                    : "border-slate-200 shadow-[0_4px_14px_rgba(15,23,42,0.08)] hover:border-slate-300 hover:shadow-[0_8px_22px_rgba(15,23,42,0.11)]"
                }`}
              >
                <div className={`border-b px-5 py-4 ${
                  effectivePriority === "Urgent"
                    ? "border-rose-100 bg-gradient-to-r from-rose-100/70 via-rose-50/40 to-white/70"
                    : effectivePriority === "High"
                    ? "border-amber-100 bg-gradient-to-r from-amber-100/70 via-amber-50/40 to-white/70"
                    : "border-slate-100 bg-gradient-to-r from-slate-50/90 via-white to-blue-50/50"
                }`}>
                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <div className="flex min-w-0 flex-wrap items-center gap-x-4 gap-y-2">
                      <div className="border-r border-slate-200 pr-4">
                        <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-400">Work Order</p>
                        <div className="mt-0.5 flex flex-wrap items-center gap-2">
                          <h2 className="whitespace-nowrap text-lg font-extrabold tracking-tight text-[#173b75]">{wo.workOrderNo}</h2>
                          {wo.isBackOrder ? (
                            <span className="inline-flex items-center rounded-full border border-purple-200 bg-purple-50 px-2.5 py-1 text-xs font-semibold text-purple-700 whitespace-nowrap">
                              <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                              Back Order
                            </span>
                          ) : null}
                          {isRescueWorkOrder(wo) ? (
                            <span className="inline-flex items-center rounded-full border border-red-200 bg-red-50 px-2.5 py-1 text-xs font-semibold text-red-700 whitespace-nowrap">
                              <PhoneCall className="mr-1 h-3 w-3" />
                              Rescue
                            </span>
                          ) : null}
                          <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold whitespace-nowrap ${getPriorityBadge(effectivePriority)}`}>
                            <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                            {effectivePriority}
                          </span>
                          {activeDateBadge ? (
                            <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold whitespace-nowrap ${activeDateBadge.className}`}>
                              <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                              {activeDateBadge.label}
                            </span>
                          ) : null}
                          {wo.photos?.length ? (
                            <span className="inline-flex items-center rounded-full border border-violet-200 bg-violet-50 px-2.5 py-1 text-xs font-semibold text-violet-700 whitespace-nowrap">
                              <Camera className="mr-1 h-3 w-3" />{wo.photos.length}
                            </span>
                          ) : null}
                        </div>
                      </div>
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold whitespace-nowrap ${getStatusBadge(wo.canonicalStatus)}`}>
                            <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                            {t(`status_${wo.canonicalStatus}`)}
                          </span>
                          {partsStatusAvailable ? (
                            <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold whitespace-nowrap ${partsStatusConfig.className}`}>
                              <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                              {partsStatusConfig.label}
                            </span>
                          ) : null}
                          <span className="inline-flex items-center rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs font-semibold text-slate-600 whitespace-nowrap">
                            Stage {currentStageIndex + 1}/{WORK_ORDER_STAGES.length}
                          </span>
                        </div>
                        <p className="mt-1 text-[11px] font-medium text-slate-500">
                          {allowedNextStatuses.length > 0
                            ? `Next: ${allowedNextStatuses.map((status) => t(`status_${status}`)).join(" or ")}`
                            : wo.canonicalStatus === "inspected" ? "Next: Review quotation from inspection (Issue to customer or approve internally)"
                            : wo.canonicalStatus === "quotation_issued" ? "Waiting for customer quotation response"
                            : wo.canonicalStatus === "collected" ? "Lifecycle completed" : "No status action available for this role"}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      {wo.hasUnacknowledgedParts ? (
                        <button
                          type="button"
                          onClick={() => openPartsReviewModal(wo)}
                          className="inline-flex min-h-9 animate-bounce items-center rounded-lg border border-amber-300 bg-amber-50 px-3 py-1.5 text-xs font-bold text-amber-800 shadow-sm transition-colors hover:border-amber-400 hover:bg-amber-100 ring-2 ring-amber-300/60"
                        >
                          <Zap className="mr-1.5 h-3.5 w-3.5 text-amber-600" />New Parts Added
                        </button>
                      ) : null}
                      {canView ? (
                        <button type="button" onClick={() => openViewModal(wo)} className="inline-flex min-h-9 items-center rounded-lg border border-blue-200 bg-white px-3 py-1.5 text-xs font-semibold text-blue-700 shadow-sm transition-colors hover:border-blue-300 hover:bg-blue-50">
                          <Eye className="mr-1.5 h-3.5 w-3.5" />View Details
                        </button>
                      ) : null}
                      {canViewQuotation && currentStageIndex >= 2 ? (
                        <button type="button" onClick={() => openQuotationModal(wo)} className="inline-flex min-h-9 items-center rounded-lg border border-cyan-600 bg-cyan-600 px-3 py-1.5 text-xs font-bold text-white shadow-xs transition-colors hover:bg-cyan-700 hover:border-cyan-700">
                          <FileText className="mr-1.5 h-3.5 w-3.5 text-white" />Quotation
                        </button>
                      ) : null}
                      {recordScope === "active" && canUpdateDetails ? (
                        <button type="button" onClick={() => openEditModal(wo)} className="inline-flex min-h-9 items-center rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 shadow-sm transition-colors hover:bg-slate-50">
                          <Edit className="mr-1.5 h-3.5 w-3.5" />Edit
                        </button>
                      ) : null}
                      {recordScope === "active" && canUpdateStatus ? (
                        <button
                          type="button"
                          onClick={() => openStatusModal(wo)}
                          className="inline-flex min-h-9 items-center rounded-lg bg-[#1e3a8a] px-3 py-1.5 text-xs font-bold text-white shadow-sm transition-colors hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-200 cursor-pointer"
                        >
                          <ClipboardList className="mr-1.5 h-3.5 w-3.5" />Update Status
                        </button>
                      ) : null}
                      <button
                        type="button"
                        onClick={() => setExpandedWorkOrderIds((current) => {
                          const next = new Set(current);
                          if (next.has(wo.id)) next.delete(wo.id);
                          else next.add(wo.id);
                          return next;
                        })}
                        className="inline-flex min-h-9 items-center rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-bold text-slate-600 shadow-sm transition-colors hover:border-blue-200 hover:bg-blue-50 hover:text-blue-700"
                        aria-expanded={isExpanded}
                        aria-controls={`work-order-flow-${wo.id}`}
                      >
                        Flow
                        <ChevronDown className={`ml-1.5 h-4 w-4 transition-transform duration-300 ease-out ${isExpanded ? "rotate-180" : "rotate-0"}`} />
                      </button>
                    </div>
                  </div>
                </div>

                <div className="px-5 py-3">
                  <dl className="grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
                    <div className="flex min-w-0 items-center gap-3 rounded-xl border border-slate-100 bg-slate-50/70 px-3 py-2.5">
                      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white text-blue-600 shadow-sm"><Car className="h-4 w-4" /></span>
                      <div className="min-w-0"><dt className="text-[9px] font-bold uppercase tracking-wider text-slate-400">Vehicle</dt><dd className="truncate text-xs font-bold text-slate-800">{wo.vehicleNo}</dd><dd className="truncate text-[10px] text-slate-500">{wo.brand} {wo.model}</dd></div>
                    </div>
                    <div className="flex min-w-0 items-center gap-3 rounded-xl border border-slate-100 bg-slate-50/70 px-3 py-2.5">
                      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white text-blue-600 shadow-sm"><Building2 className="h-4 w-4" /></span>
                      <div className="min-w-0"><dt className="text-[9px] font-bold uppercase tracking-wider text-slate-400">Company</dt><dd className="truncate text-xs font-bold text-slate-800">{wo.companyName || "-"}</dd><dd className="truncate text-[10px] text-slate-500">{wo.contactName || "No contact"}</dd></div>
                    </div>
                    <div className="flex min-w-0 items-center gap-3 rounded-xl border border-slate-100 bg-slate-50/70 px-3 py-2.5">
                      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white text-blue-600 shadow-sm"><MapPin className="h-4 w-4" /></span>
                      <div className="min-w-0"><dt className="text-[9px] font-bold uppercase tracking-wider text-slate-400">Workshop Bay</dt><dd className="truncate text-xs font-bold text-slate-800">{wo.bay || "Not assigned"}</dd></div>
                    </div>
                    <div className="flex min-w-0 items-center gap-3 rounded-xl border border-slate-100 bg-slate-50/70 px-3 py-2.5">
                      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white text-blue-600 shadow-sm"><Clock className="h-4 w-4" /></span>
                      <div className="min-w-0"><dt className="text-[9px] font-bold uppercase tracking-wider text-slate-400">Estimated Out</dt><dd className="truncate text-xs font-bold text-slate-800">{wo.estimatedOut || "No ETA"}</dd></div>
                    </div>
                    <div className="flex min-w-0 items-center gap-3 rounded-xl border border-blue-100 bg-blue-50/70 px-3 py-2.5">
                      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white text-blue-600 shadow-sm"><Users className="h-4 w-4" /></span>
                      <div className="min-w-0"><dt className="text-[9px] font-bold uppercase tracking-wider text-blue-400">Assigned Team</dt><dd className="truncate text-xs font-bold text-blue-900">{technicianNames || "Not assigned"}</dd></div>
                    </div>
                  </dl>
                </div>

                <div
                  id={`work-order-flow-${wo.id}`}
                  className="maw-work-order-flow"
                  data-expanded={isExpanded ? "true" : "false"}
                  aria-hidden={!isExpanded}
                >
                  <div className="maw-work-order-flow-clip">
                    <div className="maw-work-order-flow-content border-t border-slate-100 px-5 pb-4 pt-3">
                      <div className="overflow-x-auto rounded-xl border border-slate-100 bg-gradient-to-b from-slate-50/80 to-white px-3 pb-3 pt-4" aria-label={`Lifecycle for ${wo.workOrderNo}`}>
                        <ol className="flex min-w-[1000px] items-start px-2">
                      {WORK_ORDER_STAGES.map((stage, stageIndex) => {
                        const state = getStageState(wo, stage, stageIndex);
                        const timestamp = getStageTimestamp(wo, stage.key);
                        return (
                          <li key={stage.key} className="relative min-w-0 flex-1 px-1 text-center">
                            {stageIndex < WORK_ORDER_STAGES.length - 1 ? (
                              <span className={`absolute left-[calc(50%+22px)] right-[calc(-50%+22px)] top-[19px] h-[3px] rounded-full ${getStageConnectorClasses(state)}`} aria-hidden="true" />
                            ) : null}
                            <div aria-current={state === "current" ? "step" : undefined} className="relative z-[1] flex flex-col items-center">
                              <div className="relative flex items-center justify-center">
                                {state === "current" ? (
                                  <span className="absolute -inset-1 rounded-full bg-sky-400/40 animate-ping pointer-events-none opacity-60" />
                                ) : null}
                                <span className={`relative flex h-10 w-10 items-center justify-center rounded-full border-2 text-xs font-extrabold transition-[color,background-color,border-color,box-shadow] duration-300 ${getStageNodeClasses(state)}`}>
                                  {state === "completed" ? <Check className="h-4 w-4" strokeWidth={3} /> : state === "current" ? <Wrench className="h-4 w-4" /> : stageIndex + 1}
                                </span>
                              </div>
                              <span className={`mt-2 max-w-[112px] text-[10px] font-extrabold leading-tight ${state === "current" ? "text-sky-700" : state === "completed" ? "text-[#173b75]" : state === "optional-history" ? "text-amber-700" : "text-slate-500"}`}>{stage.label}</span>
                              <span className="mt-1 flex min-h-[16px] items-center justify-center">
                                {state === "optional-history" ? (
                                  <span className="rounded-full border border-amber-200 bg-amber-50 px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wide text-amber-700">Skipped</span>
                                ) : stage.optional ? (
                                  <span className="rounded-full bg-slate-100 px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wide text-slate-400">Optional</span>
                                ) : state === "current" ? (
                                  <span className="rounded-full bg-sky-50 px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wide text-sky-600">Current</span>
                                ) : null}
                              </span>
                              <span className="mt-1 min-h-[12px] text-[8px] font-medium leading-tight text-slate-400">{timestamp ? formatStageTimestamp(timestamp) : ""}</span>
                            </div>
                          </li>
                        );
                      })}
                        </ol>
                      </div>
                    </div>
                  </div>
                </div>
              </article>
            );
          })
        )}

        {/* Pagination Footer */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between rounded-xl border border-gray-100 bg-white px-5 py-4 shadow-sm">
            <div className="text-sm text-gray-500">
              Showing <span className="font-semibold">{workOrders.length}</span> of{" "}
              <span className="font-semibold">{total}</span> {recordScope === "active" ? "active work orders" : "history records"}
            </div>
            <div className="flex space-x-2">
              <button
                type="button"
                disabled={page <= 1}
                onClick={() => setPage(page - 1)}
                className="inline-flex items-center p-1.5 border border-gray-300 rounded-lg bg-white text-gray-500 hover:bg-gray-50 disabled:opacity-40"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              <button
                type="button"
                disabled={page >= totalPages}
                onClick={() => setPage(page + 1)}
                className="inline-flex items-center p-1.5 border border-gray-300 rounded-lg bg-white text-gray-500 hover:bg-gray-50 disabled:opacity-40"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Review Mid-Repair Parts Modal */}
      {modalMode === "review_parts" && selectedWO && (
        <WorkOrderReviewPartsDialog
          workOrder={selectedWO}
          catalog={inspectionPartCatalog}
          onClose={closeModal}
          onSuccess={fetchWorkOrders}
        />
      )}

      {modalMode === "view" && selectedWO && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm transition-opacity">
          <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/80">
              <div className="flex flex-wrap items-center gap-3">
                <h2 className="text-lg font-extrabold text-[#173b75]">
                  Work Order Details — {selectedWO.workOrderNo}
                </h2>
                <span className="rounded-md bg-slate-200/80 px-2 py-0.5 text-xs font-mono font-bold text-slate-700">
                  ID #{selectedWO.id}
                </span>
                <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold whitespace-nowrap ${getStatusBadge(selectedWO.canonicalStatus)}`}>
                  <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                  {t(`status_${selectedWO.canonicalStatus}`)}
                </span>
                {selectedWO.isBackOrder ? (
                  <span className="inline-flex items-center rounded-full border border-purple-200 bg-purple-50 px-2.5 py-1 text-xs font-semibold text-purple-700 whitespace-nowrap">
                    <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                    Back Order
                  </span>
                ) : null}
                {(() => {
                  const detailsPriority = selectedWO.canonicalStatus === "collected" ? "Normal" : (selectedWO.priority || "Normal");
                  return (
                    <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold whitespace-nowrap ${getPriorityBadge(detailsPriority)}`}>
                      <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                      {detailsPriority}
                    </span>
                  );
                })()}
              </div>
              <button
                type="button"
                onClick={closeModal}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-200/60 hover:text-slate-600 transition-colors"
                aria-label="Close dialog"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-5 overflow-y-auto flex-1 text-xs">
              {/* Lifecycle Flow Timeline */}
              <div className="rounded-xl border border-slate-200 bg-gradient-to-b from-slate-50/80 to-white p-4">
                <div className="mb-3 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ListTodo className="h-4 w-4 text-blue-700" />
                    <span className="font-extrabold uppercase tracking-wider text-slate-700">Repair Lifecycle Timeline</span>
                  </div>
                  <span className="font-bold text-slate-500">
                    Stage {Math.max(1, WORK_ORDER_STAGES.findIndex((s) => s.key === selectedWO.canonicalStatus) + 1)} of {WORK_ORDER_STAGES.length}
                  </span>
                </div>
                <div className="overflow-x-auto pb-2">
                  <ol className="flex min-w-[780px] items-start px-2">
                    {WORK_ORDER_STAGES.map((stage, stageIndex) => {
                      const state = getStageState(selectedWO, stage, stageIndex);
                      const timestamp = getStageTimestamp(selectedWO, stage.key);
                      return (
                        <li key={stage.key} className="relative min-w-0 flex-1 px-1 text-center">
                          {stageIndex < WORK_ORDER_STAGES.length - 1 ? (
                            <span className={`absolute left-[calc(50%+16px)] right-[calc(-50%+16px)] top-[14px] h-[2.5px] rounded-full ${getStageConnectorClasses(state)}`} aria-hidden="true" />
                          ) : null}
                          <div aria-current={state === "current" ? "step" : undefined} className="relative z-[1] flex flex-col items-center">
                            <div className="relative flex items-center justify-center">
                              {state === "current" ? (
                                <span className="absolute -inset-0.5 rounded-full bg-sky-400/40 animate-ping pointer-events-none opacity-60" />
                              ) : null}
                              <span className={`relative flex h-8 w-8 items-center justify-center rounded-full border-2 text-[11px] font-extrabold transition-colors ${getStageNodeClasses(state)}`}>
                                {state === "completed" ? <Check className="h-3.5 w-3.5" strokeWidth={3} /> : state === "current" ? <Wrench className="h-3.5 w-3.5" /> : stageIndex + 1}
                              </span>
                            </div>
                            <span className={`mt-1.5 max-w-[90px] text-[10px] font-extrabold leading-tight ${state === "current" ? "text-sky-700" : state === "completed" ? "text-[#173b75]" : state === "optional-history" ? "text-amber-700" : "text-slate-500"}`}>{stage.label}</span>
                            <span className="mt-0.5 min-h-[12px] text-[8px] font-medium leading-tight text-slate-400">{timestamp ? formatStageTimestamp(timestamp) : ""}</span>
                          </div>
                        </li>
                      );
                    })}
                  </ol>
                </div>
              </div>

              {/* Emergency Rescue Indicator Banner */}
              {isRescueWorkOrder(selectedWO) ? (
                <div className="rounded-2xl border border-red-300 bg-gradient-to-r from-red-50 via-rose-50 to-amber-50 p-4 flex items-center justify-between gap-3 text-red-950 shadow-xs">
                  <div className="flex items-center gap-3">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-600 text-white shadow-sm shadow-red-500/30">
                      <PhoneCall className="h-5 w-5 animate-pulse" />
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="rounded-full bg-red-600 px-2 py-0.5 text-[9px] font-black uppercase tracking-wider text-white">24/7 SOS</span>
                        <p className="text-xs font-black uppercase tracking-wide text-red-900">Emergency Roadside Rescue Job (道路救援单)</p>
                      </div>
                      <p className="mt-0.5 text-[11px] text-red-700 font-medium">Request Channel: {selectedWO.requestChannel || "Rescue Hotline"}</p>
                    </div>
                  </div>
                  <span className="rounded-full bg-red-600/10 border border-red-300 px-3 py-1 text-xs font-black text-red-800">
                    Priority: {selectedWO.priority || "Urgent"}
                  </span>
                </div>
              ) : null}

              {/* Vehicle & Customer Info Grid */}
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                {/* Vehicle & Intake Information Card */}
                <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3 shadow-xs">
                  <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
                    <Car className="h-4 w-4 text-blue-600" />
                    <h3 className="font-bold uppercase tracking-wider text-slate-800">Vehicle &amp; Intake</h3>
                  </div>
                  <dl className="grid grid-cols-2 gap-3">
                    <div>
                      <dt className="text-[10px] font-bold uppercase text-slate-400">Plate No / Unit</dt>
                      <dd className="font-extrabold text-slate-900 text-sm">{selectedWO.vehicleNo}</dd>
                    </div>
                    <div>
                      <dt className="text-[10px] font-bold uppercase text-slate-400">Make &amp; Model</dt>
                      <dd className="font-semibold text-slate-800">{selectedWO.brand} {selectedWO.model}</dd>
                    </div>
                    <div>
                      <dt className="text-[10px] font-bold uppercase text-slate-400">Equipment Type</dt>
                      <dd className="font-medium text-slate-700">{selectedWO.equipmentType || "-"}</dd>
                    </div>
                    <div>
                      <dt className="text-[10px] font-bold uppercase text-slate-400">Check-in Mileage</dt>
                      <dd className="font-medium text-slate-700">
                        {selectedWO.checkinMileage !== null && selectedWO.checkinMileage !== undefined ? `${selectedWO.checkinMileage.toLocaleString()} km` : "Not recorded"}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-[10px] font-bold uppercase text-slate-400">Intake Type</dt>
                      <dd className="font-medium text-slate-700">
                        {selectedWO.intakeType === "rescue" || isRescueWorkOrder(selectedWO) ? "🚨 Emergency Rescue (道路救援)" : selectedWO.intakeType === "walk_in" ? "Walk-in Intake" : "Customer App Booking"}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-[10px] font-bold uppercase text-slate-400">Request Channel</dt>
                      <dd className="font-medium text-slate-700">{selectedWO.requestChannel || "Direct Intake"}</dd>
                    </div>
                    <div>
                      <dt className="text-[10px] font-bold uppercase text-slate-400">Driver Bringing Vehicle</dt>
                      <dd className="font-medium text-slate-700">{selectedWO.broughtByDriverName || "Not specified"}</dd>
                    </div>
                    <div>
                      <dt className="text-[10px] font-bold uppercase text-slate-400">Intake Foreman</dt>
                      <dd className="font-medium text-slate-700">{selectedWO.foremanName || "Unassigned"}</dd>
                    </div>
                  </dl>

                  {selectedWO.relatedVehicles?.length > 0 ? (
                    <div className="border-t border-slate-100 pt-2">
                      <dt className="text-[10px] font-bold uppercase text-slate-400 mb-1">Related Vehicle / Trailer</dt>
                      <div className="flex flex-wrap gap-1.5">
                        {selectedWO.relatedVehicles.map((vehicle) => (
                          <span key={vehicle.id} className="rounded-full bg-slate-100 px-2 py-0.5 text-[11px] font-semibold text-slate-700">
                            {vehicle.vehicleNo}
                          </span>
                        ))}
                      </div>
                    </div>
                  ) : null}
                </div>

                {/* Company & Workshop Operations Card */}
                <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3 shadow-xs">
                  <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
                    <Building2 className="h-4 w-4 text-blue-600" />
                    <h3 className="font-bold uppercase tracking-wider text-slate-800">Customer &amp; Workshop Bay</h3>
                  </div>
                  <dl className="grid grid-cols-2 gap-3">
                    <div>
                      <dt className="text-[10px] font-bold uppercase text-slate-400">Company</dt>
                      <dd className="font-extrabold text-slate-900 text-sm">{selectedWO.companyName || "-"}</dd>
                    </div>
                    <div>
                      <dt className="text-[10px] font-bold uppercase text-slate-400">Contact Person</dt>
                      <dd className="font-semibold text-slate-800">
                        {selectedWO.contactName && selectedWO.contactName !== "-" ? `${selectedWO.contactName} (${selectedWO.contactType})` : "-"}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-[10px] font-bold uppercase text-slate-400">Phone</dt>
                      <dd className="font-medium text-slate-700">{selectedWO.customerPhone || "-"}</dd>
                    </div>
                    <div>
                      <dt className="text-[10px] font-bold uppercase text-slate-400">AutoCount Job No.</dt>
                      <dd className="font-mono font-bold text-blue-800">{selectedWO.autocountJobNo || "-"}</dd>
                    </div>
                    <div>
                      <dt className="text-[10px] font-bold uppercase text-slate-400">Workshop Bay</dt>
                      <dd className="font-medium text-slate-700">{selectedWO.bay || "Not assigned"}</dd>
                    </div>
                    <div>
                      <dt className="text-[10px] font-bold uppercase text-slate-400">Expected Out / ETA</dt>
                      <dd className="font-medium text-slate-700">{selectedWO.estimatedOut || "No ETA"}</dd>
                    </div>
                    <div>
                      <dt className="text-[10px] font-bold uppercase text-slate-400">Service Type</dt>
                      <dd className="font-medium text-slate-700">{selectedWO.serviceType || "-"}</dd>
                    </div>
                    <div>
                      <dt className="text-[10px] font-bold uppercase text-slate-400">Service Centre</dt>
                      <dd className="font-medium text-slate-700">{selectedWO.serviceCentre || "Main Centre"}</dd>
                    </div>
                  </dl>

                  <div className="border-t border-slate-100 pt-2">
                    <dt className="text-[10px] font-bold uppercase text-slate-400 mb-1">Assigned Repair Team</dt>
                    <div className="flex flex-wrap gap-1.5">
                      {(selectedWO.technicians || []).length > 0 ? (
                        selectedWO.technicians.map((member) => (
                          <span key={member.id} className="rounded-full bg-blue-50 px-2.5 py-0.5 text-[11px] font-semibold text-blue-800">
                            {member.name} · {member.role}
                          </span>
                        ))
                      ) : (
                        <span className="text-slate-400">Unassigned</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Problem description & Notes */}
              {(selectedWO.reportedProblem || selectedWO.customerNotes) && (
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  {selectedWO.reportedProblem ? (
                    <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-3.5">
                      <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">Customer Reported Problem / Request</span>
                      <p className="whitespace-pre-wrap text-slate-800 font-medium">{selectedWO.reportedProblem}</p>
                    </div>
                  ) : null}
                  {selectedWO.customerNotes ? (
                    <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-3.5">
                      <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">Driver / Customer Notes</span>
                      <p className="whitespace-pre-wrap text-slate-800 font-medium">{selectedWO.customerNotes}</p>
                    </div>
                  ) : null}
                </div>
              )}

              {/* Spare Parts Section */}
              <WorkOrderViewPartsSection workOrderId={selectedWO.id} />

              {/* Workshop Photos */}
              <div className="rounded-xl border border-slate-200 bg-white p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Camera className="h-4 w-4 text-violet-600" />
                    <span className="font-bold uppercase tracking-wider text-slate-800">Workshop Photos</span>
                  </div>
                  <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-600">
                    {selectedWO.photos?.length || 0} photo(s)
                  </span>
                </div>
                {selectedWO.photos?.length ? (
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
                    {selectedWO.photos.map((photo) => (
                      <figure key={photo.id} className="overflow-hidden rounded-lg border border-slate-200 bg-slate-50">
                        <button
                          type="button"
                          onClick={() => setSelectedPhoto(photo)}
                          className="block w-full cursor-zoom-in overflow-hidden bg-slate-100 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
                          aria-label={`Enlarge ${photo.caption || "workshop photo"}`}
                        >
                          <img src={apiAssetUrl("work-order-photo-file", { id: photo.id })} alt={photo.caption || "Workshop photo"} loading="lazy" className="aspect-square w-full object-cover transition-transform hover:scale-105" />
                        </button>
                        <figcaption className="p-2 space-y-0.5">
                          <p className="text-[10px] font-bold uppercase text-blue-700">{photo.category.replaceAll("_", " ")}</p>
                          {photo.caption ? <p className="text-[11px] text-slate-700 truncate">{photo.caption}</p> : null}
                          <p className="text-[9px] text-slate-400">{photo.uploadedBy}{photo.customerVisible ? " · Customer Visible" : " · Internal"}</p>
                        </figcaption>
                      </figure>
                    ))}
                  </div>
                ) : (
                  <p className="rounded-lg border border-dashed border-slate-200 p-4 text-center text-slate-400">No workshop photos uploaded for this work order.</p>
                )}
              </div>

              {/* Milestone Timestamps Grid */}
              <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Clock className="h-4 w-4 text-blue-600" />
                  <span className="font-bold uppercase tracking-wider text-slate-800">All Milestone Timestamps</span>
                </div>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
                  <div className="rounded-lg bg-white p-2.5 border border-slate-200/80">
                    <span className="block text-[10px] font-bold uppercase text-slate-400">Checked In</span>
                    <span className="font-bold text-slate-800">{selectedWO.checkinAt ? formatStageTimestamp(selectedWO.checkinAt) : "-"}</span>
                  </div>
                  <div className="rounded-lg bg-white p-2.5 border border-slate-200/80">
                    <span className="block text-[10px] font-bold uppercase text-slate-400">Inspected</span>
                    <span className="font-bold text-slate-800">{selectedWO.inspectedAt ? formatStageTimestamp(selectedWO.inspectedAt) : "-"}</span>
                  </div>
                  <div className="rounded-lg bg-white p-2.5 border border-slate-200/80">
                    <span className="block text-[10px] font-bold uppercase text-slate-400">Quotation Issued</span>
                    <span className="font-bold text-slate-800">{selectedWO.quotationIssuedAt ? formatStageTimestamp(selectedWO.quotationIssuedAt) : "-"}</span>
                  </div>
                  <div className="rounded-lg bg-white p-2.5 border border-slate-200/80">
                    <span className="block text-[10px] font-bold uppercase text-slate-400">Approved</span>
                    <span className="font-bold text-slate-800">{selectedWO.approvedAt ? formatStageTimestamp(selectedWO.approvedAt) : "-"}</span>
                  </div>
                  <div className="rounded-lg bg-white p-2.5 border border-slate-200/80">
                    <span className="block text-[10px] font-bold uppercase text-slate-400">Parts Ready</span>
                    <span className="font-bold text-slate-800">{selectedWO.partsReadyAt ? formatStageTimestamp(selectedWO.partsReadyAt) : "-"}</span>
                  </div>
                  <div className="rounded-lg bg-white p-2.5 border border-slate-200/80">
                    <span className="block text-[10px] font-bold uppercase text-slate-400">Under Repair</span>
                    <span className="font-bold text-slate-800">{selectedWO.underRepairAt ? formatStageTimestamp(selectedWO.underRepairAt) : "-"}</span>
                  </div>
                  <div className="rounded-lg bg-white p-2.5 border border-slate-200/80">
                    <span className="block text-[10px] font-bold uppercase text-slate-400">Completed</span>
                    <span className="font-bold text-slate-800">{selectedWO.completedAt ? formatStageTimestamp(selectedWO.completedAt) : "-"}</span>
                  </div>
                  <div className="rounded-lg bg-white p-2.5 border border-slate-200/80">
                    <span className="block text-[10px] font-bold uppercase text-slate-400">Collected</span>
                    <span className="font-bold text-slate-800">{selectedWO.collectedAt ? formatStageTimestamp(selectedWO.collectedAt) : "-"}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-between px-6 py-4 bg-slate-50 border-t border-slate-200">
              <div>
                {canViewQuotation ? (
                  <button
                    type="button"
                    onClick={() => {
                      const wo = selectedWO;
                      closeModal();
                      openQuotationModal(wo);
                    }}
                    className="inline-flex items-center rounded-lg border border-cyan-300 bg-cyan-50 px-3.5 py-2 text-xs font-bold text-cyan-800 shadow-xs hover:bg-cyan-100 transition-colors"
                  >
                    <FileText className="mr-1.5 h-4 w-4" />View Quotation Document
                  </button>
                ) : null}
              </div>
              <button
                type="button"
                onClick={closeModal}
                className="px-5 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {selectedPhoto && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-slate-950/70 p-6 backdrop-blur-sm animate-in fade-in-0 duration-200"
          role="dialog"
          aria-modal="true"
          aria-label="Workshop photo preview"
          onClick={(event) => {
            if (event.target === event.currentTarget) setSelectedPhoto(null);
          }}
        >
          <div className="relative flex max-h-[92vh] w-full max-w-5xl flex-col overflow-hidden rounded-[1.75rem] border border-white/70 bg-white shadow-[0_28px_90px_rgba(2,6,23,0.42)] animate-in fade-in-0 zoom-in-95 duration-200" onClick={(event) => event.stopPropagation()}>
            <button
              type="button"
              onClick={() => setSelectedPhoto(null)}
              className="absolute right-4 top-4 z-10 flex h-10 w-10 items-center justify-center rounded-full border border-white/80 bg-white/90 text-slate-700 shadow-lg backdrop-blur transition-colors hover:bg-white focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
              aria-label="Close photo preview"
            >
              <X className="h-5 w-5" />
            </button>
            <div className="flex min-h-0 flex-1 items-center justify-center overflow-auto bg-slate-100">
              <img
                src={apiAssetUrl("work-order-photo-file", { id: selectedPhoto.id })}
                alt={selectedPhoto.caption || "Workshop photo"}
                className="max-h-[78vh] max-w-full select-none object-contain"
              />
            </div>
            <div className="flex flex-wrap items-start justify-between gap-3 border-t border-slate-100 bg-white px-5 py-4 text-slate-800">
              <div className="min-w-0">
                <span className="inline-flex rounded-full border border-blue-100 bg-blue-50 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-[#2563eb]">{selectedPhoto.category.replaceAll("_", " ")}</span>
                {selectedPhoto.caption ? <p className="mt-2 text-sm leading-5 text-slate-600">{selectedPhoto.caption}</p> : null}
              </div>
              <p className="shrink-0 pt-1 text-xs font-medium text-slate-400">{selectedPhoto.uploadedBy}{selectedPhoto.customerVisible ? " · Customer visible" : " · Internal"}</p>
            </div>
          </div>
        </div>
      )}

      {/* Edit Details Modal */}
      {modalMode === "edit" && selectedWO && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-3 backdrop-blur-sm transition-opacity sm:p-5">
          <div className="flex max-h-[94vh] w-full max-w-5xl flex-col overflow-hidden rounded-2xl border border-white/70 bg-white shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 bg-white px-5 py-4 sm:px-7 sm:py-5">
              <div className="flex items-start gap-3.5"><div className="mt-0.5 flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-[#1e3a8a] ring-1 ring-blue-100"><ClipboardList className="h-5 w-5" /></div><div><h2 className="text-lg font-bold tracking-tight text-slate-900 sm:text-xl">Edit Work Order</h2><p className="mt-1 text-xs leading-5 text-slate-500 sm:text-sm">{selectedWO.workOrderNo} · Update scheduling and workshop ownership.</p></div></div>
              <button
                type="button"
                onClick={closeModal}
                className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                aria-label="Close work order dialog"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto bg-slate-50/80 p-4 sm:p-6">
              {formError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600 font-medium">
                  {formError}
                </div>
              )}

              <section className="grid gap-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5 md:grid-cols-2">
              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                  Priority level
                </label>
                <AdminSelect
                  value={editPriority}
                  onChange={(e) => setEditPriority(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm"
                >
                  {PRIORITIES.map(p => (
                    <option key={p} value={p}>{p}</option>
                  ))}
                </AdminSelect>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                  Workshop Bay
                </label>
                <AdminSelect
                  value={editBay}
                  onChange={(e) => setEditBay(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm bg-white"
                >
                  <option value="">Unassigned</option>
                  {BAYS.map(b => (
                    <option key={b} value={b}>{b}</option>
                  ))}
                </AdminSelect>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                  Expected Completion Date
                </label>
                <DesktopDatePicker
                  value={editEstimatedOut}
                  onChange={setEditEstimatedOut}
                  ariaLabel="Choose expected completion date"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                  Check-in Mileage (km)
                </label>
                <input
                  type="number"
                  min="0"
                  placeholder="e.g. 125000"
                  value={editCheckinMileage}
                  onChange={(e) => setEditCheckinMileage(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm bg-white"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                  Assigned Repair Person
                </label>
                <StaffSelect staff={assignableStaff} selectedIds={editTechnicianIds} onChange={setEditTechnicianIds} />
              </div>

              {/* Back Order Switch in Edit Modal */}
              <div className="md:col-span-2 flex items-center justify-between gap-3 rounded-xl border border-slate-200 bg-slate-50 p-3.5 shadow-2xs">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-slate-800">Back Order</span>
                    {editIsBackOrder ? (
                      <span className="rounded-full bg-purple-100 px-2 py-0.5 text-[10px] font-bold text-purple-700">
                        Bypass Stock
                      </span>
                    ) : null}
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {editIsBackOrder
                      ? "Enabled: Proceed with repair even if parts are out of stock (VIP reserved stock protected)."
                      : "Disabled: Standard inventory stock availability rules apply."}
                  </p>
                </div>
                <label className="relative inline-flex cursor-pointer items-center">
                  <input
                    type="checkbox"
                    checked={editIsBackOrder}
                    onChange={(e) => setEditIsBackOrder(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-purple-600"></div>
                </label>
              </div>
              </section>
            </div>

            <div className="flex flex-col-reverse gap-3 border-t border-slate-200 bg-white px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between sm:px-7">
              <p className="text-xs text-slate-500">Changes apply to this work order only</p><div className="flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={closeModal}
                className="h-10 rounded-lg border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isSaving}
                onClick={handleUpdateWorkOrderDetails}
                className="inline-flex h-10 items-center gap-2 rounded-lg bg-[#1e3a8a] px-5 text-sm font-semibold text-white shadow-sm hover:bg-blue-800 disabled:opacity-50"
              >
                <Save className="h-4 w-4" />{isSaving ? "Saving..." : "Save Changes"}
              </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Lifecycle Status Modal */}
      {modalMode === "status" && selectedWO && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-3 backdrop-blur-sm transition-opacity sm:p-5">
          <div className="flex max-h-[94vh] w-full max-w-2xl flex-col overflow-hidden rounded-2xl border border-white/70 bg-white shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 bg-white px-5 py-4 sm:px-7 sm:py-5">
              <div className="flex items-start gap-3.5"><div className="mt-0.5 flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-[#1e3a8a] ring-1 ring-blue-100"><ListTodo className="h-5 w-5" /></div><div><h2 className="text-lg font-bold tracking-tight text-slate-900 sm:text-xl">Update Work Order Status</h2><p className="mt-1 text-xs leading-5 text-slate-500 sm:text-sm">{selectedWO.workOrderNo} · Complete the next allowed workflow action.</p></div></div>
              <button
                type="button"
                onClick={closeModal}
                className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                aria-label="Close status dialog"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 space-y-4 overflow-y-auto bg-slate-50/80 p-4 sm:p-6">
              {formError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600 font-medium">
                  {formError}
                </div>
              )}

              <div className="rounded-xl border border-blue-100 bg-blue-50/70 px-4 py-3 text-sm text-blue-900">Current status <span className="ml-1 font-bold">{t(`status_${selectedWO.canonicalStatus}`)}</span></div>

              {WORK_ORDER_STAGES.findIndex((stage) => stage.key === selectedWO.canonicalStatus) >= WORK_ORDER_STAGES.findIndex((stage) => stage.key === "approved") ? (
                <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm space-y-4">
                  {/* 1. Clear Headline Status Banner */}
                  <div className={`rounded-xl border p-4 flex flex-wrap items-center justify-between gap-3 ${
                    selectedWO.isBackOrder
                      ? "border-purple-200 bg-purple-50/80 text-purple-900"
                      : ["pending_parts", "partially_arrived"].includes(calculatedPartsStatus)
                      ? "border-amber-200 bg-amber-50/80 text-amber-900"
                      : "border-emerald-200 bg-emerald-50/80 text-emerald-900"
                  }`}>
                    <div className="flex items-center gap-3">
                      <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${
                        selectedWO.isBackOrder
                          ? "bg-purple-100 text-purple-700 ring-1 ring-purple-200"
                          : ["pending_parts", "partially_arrived"].includes(calculatedPartsStatus)
                          ? "bg-amber-100 text-amber-700 ring-1 ring-amber-200"
                          : "bg-emerald-100 text-emerald-700 ring-1 ring-emerald-200"
                      }`}>
                        <PackageSearch className="h-5 w-5" />
                      </span>
                      <div>
                        <h3 className="text-sm font-extrabold tracking-tight">
                          {selectedWO.isBackOrder
                            ? "Back Order Bypass Active · Inventory shortage bypassed"
                            : calculatedPartsStatus === "not_required"
                            ? "No Parts Required for this Work Order"
                            : calculatedPartsStatus === "parts_ready"
                            ? "Parts Ready · All items available in stock"
                            : "Pending Parts · Warehouse shortage detected"}
                        </h3>
                        <p className="mt-0.5 text-xs opacity-80">
                          {selectedWO.isBackOrder
                            ? "Shortage checks are bypassed for this work order to protect VIP reserved stock. Repair and collection can proceed without delay."
                            : calculatedPartsStatus === "parts_ready"
                            ? "All required quantities are in stock. Repair can proceed."
                            : ["pending_parts", "partially_arrived"].includes(calculatedPartsStatus)
                            ? "Some items are out of stock. Please set expected arrival date or order via PO."
                            : "No inventory items are locked for this repair."}
                        </p>
                      </div>
                    </div>
                    <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold whitespace-nowrap ${calculatedPartsStatusConfig.className}`}>
                      <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                      {calculatedPartsStatusConfig.label}
                    </span>
                  </div>

                  {/* 2. Unified Parts List & Selector */}
                  <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xs">
                    <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50/90 px-4 py-3">
                      <div>
                        <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-800">Required Parts List</h4>
                        <p className="mt-0.5 text-[11px] text-slate-500">Pick spare parts and quantities required for this repair</p>
                      </div>
                      {canManagePartsStatus ? (
                        <button
                          type="button"
                          onClick={() => setInspectionParts((current) => [...current, blankInspectionPart()])}
                          className="inline-flex items-center rounded-lg border border-blue-200 bg-blue-50 px-3 py-1.5 text-xs font-bold text-blue-700 hover:bg-blue-100 transition-colors shadow-xs"
                        >
                          <Plus className="mr-1 h-3.5 w-3.5" />Add Part
                        </button>
                      ) : null}
                    </div>

                    {inspectionPartsLoading ? (
                      <p className="py-8 text-center text-xs text-slate-500">Loading parts catalogue...</p>
                    ) : inspectionParts.length === 0 ? (
                      <div className="py-8 text-center">
                        <PackageSearch className="mx-auto h-7 w-7 text-slate-300" />
                        <p className="mt-2 text-xs font-bold text-slate-600">No parts listed for this repair</p>
                        <p className="mt-0.5 text-[11px] text-slate-400">Click &ldquo;Add Part&rdquo; above if parts are needed.</p>
                      </div>
                    ) : (
                      <div className="divide-y divide-slate-100">
                        {inspectionParts.map((item, index) => {
                          const cataloguePart = inspectionCatalogBySku.get(item.code);
                          const stock = Number(cataloguePart?.stock || 0);
                          const shortage = Math.max(0, Number(item.quantity || 0) - stock);
                          const isReady = Boolean(cataloguePart) && shortage <= 0;
                          return (
                            <div key={item.id || index} className="p-3 sm:p-4 bg-white hover:bg-slate-50/40 transition-colors flex flex-col gap-2.5">
                              <div className="flex items-center justify-between gap-2">
                                <div className="flex items-center gap-2">
                                  <span className="text-[10px] font-extrabold uppercase text-slate-400">#{String(index + 1).padStart(2, "0")}</span>
                                  <span className={`inline-flex rounded-full px-2 py-0.5 text-[10px] font-extrabold uppercase ${
                                    !cataloguePart ? "bg-slate-100 text-slate-500" : isReady ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"
                                  }`}>
                                    {!cataloguePart ? "Choose Part" : isReady ? `In Stock (${stock})` : `${shortage} Short (Stock: ${stock})`}
                                  </span>
                                </div>
                                {canManagePartsStatus ? (
                                  <button
                                    type="button"
                                    onClick={() => setPartToRemoveModal({ index, name: item.description || item.code || `Item #${index + 1}`, code: item.code })}
                                    className="inline-flex items-center text-[11px] font-semibold text-rose-600 hover:text-rose-700"
                                  >
                                    <Trash2 className="mr-1 h-3.5 w-3.5" />Remove
                                  </button>
                                ) : null}
                              </div>

                              <div className="grid gap-2 sm:grid-cols-12 sm:items-center">
                                <div className="sm:col-span-8">
                                  {canManagePartsStatus ? (
                                    <DocumentItemCatalogSelect
                                      compact
                                      itemType="part"
                                      code={item.code}
                                      description={item.description}
                                      parts={inspectionPartCatalog}
                                      services={[]}
                                      onSelect={(selection) => {
                                        const selectedCatalogPart = inspectionCatalogBySku.get(selection.code);
                                        setInspectionParts((current) => current.map((line, lineIndex) => lineIndex === index ? { ...line, partId: selectedCatalogPart?.id || null, code: selection.code, description: selection.description, unitPrice: selection.unitPrice, uom: selectedCatalogPart?.uom || "" } : line));
                                      }}
                                    />
                                  ) : (
                                    <p className="font-bold text-slate-800 text-xs">{item.description || item.code}</p>
                                  )}
                                </div>
                                <div className="sm:col-span-4 flex items-center justify-end gap-2">
                                  <span className="text-[11px] font-bold text-slate-500">Qty:</span>
                                  <input
                                    type="number"
                                    min="1"
                                    step="1"
                                    disabled={!canManagePartsStatus}
                                    value={item.quantity}
                                    onChange={(e) => setInspectionParts((current) => current.map((line, lineIndex) => lineIndex === index ? { ...line, quantity: Number(e.target.value) } : line))}
                                    className="h-9 w-20 text-center font-extrabold text-sm rounded-lg border border-slate-300 bg-white outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                                  />
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {canManagePartsStatus && inspectionParts.length > 0 ? (
                      <div className="flex items-center justify-end border-t border-slate-200 bg-slate-50/80 p-3">
                        <button
                          type="button"
                          disabled={isSaving || !isInspectionPartsModified}
                          onClick={handleSaveRequiredParts}
                          className={`inline-flex h-9 items-center rounded-lg px-4 text-xs font-bold shadow-sm transition-all ${
                            isInspectionPartsModified && !isSaving
                              ? "bg-[#1e3a8a] text-white hover:bg-blue-800 active:scale-98 cursor-pointer"
                              : "bg-slate-200 text-slate-400 cursor-not-allowed opacity-60"
                          }`}
                          title={!isInspectionPartsModified ? "No changes to required parts" : "Save parts & verify stock"}
                        >
                          <Check className="mr-1.5 h-3.5 w-3.5" />Save Parts &amp; Verify Stock
                        </button>
                      </div>
                    ) : null}
                  </div>

                  {/* 3. Shortage Action: Expected Arrival Date */}
                  {!selectedWO.isBackOrder && ["pending_parts", "partially_arrived"].includes(calculatedPartsStatus) && canManagePartsStatus ? (
                    <div className="rounded-xl border border-amber-200 bg-amber-50/80 p-4 space-y-3">
                      <label className="block text-xs font-semibold text-amber-900">
                        Expected parts arrival date <span className="text-rose-500">*</span>
                        <DesktopDatePicker value={partsExpectedDate} onChange={setPartsExpectedDate} ariaLabel="Choose expected parts arrival date" className="mt-1 h-10 w-full font-normal bg-white" />
                      </label>
                      <button
                        type="button"
                        disabled={isSaving || !partsExpectedDate}
                        onClick={handleUpdatePartsStatus}
                        className="inline-flex min-h-10 w-full items-center justify-center rounded-lg bg-amber-600 px-4 text-sm font-bold text-white hover:bg-amber-700 disabled:cursor-not-allowed disabled:opacity-50 shadow-sm"
                      >
                        {isSaving ? "Saving..." : "Save Expected Arrival Date"}
                      </button>
                    </div>
                  ) : null}
                </section>
              ) : null}

              {selectedWO.canonicalStatus === "checked_in" ? (
                <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                  <div className="flex items-start gap-3 rounded-t-2xl border-b border-slate-200 bg-white px-5 py-4">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-violet-100 text-violet-700"><PackageSearch className="h-5 w-5" /></span>
                    <div><div className="flex items-center gap-2"><span className="rounded-full bg-violet-100 px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-wider text-violet-700">Inspection step</span><h3 className="text-sm font-extrabold text-slate-900">Required parts</h3></div><p className="mt-1 text-xs leading-5 text-slate-500">Record what this repair needs. Stock availability is checked immediately and the same items will carry into a quotation.</p></div>
                  </div>
                  <div className="space-y-4 p-4 sm:p-5">
                    {inspectionPartsLoading ? <p className="py-6 text-center text-xs text-slate-500">Loading parts catalogue...</p> : (
                      <>
                        {inspectionParts.length ? <div className="space-y-4">{inspectionParts.map((item, index) => {
                          const cataloguePart = inspectionCatalogBySku.get(item.code);
                          const stock = Number(cataloguePart?.stock || 0);
                          const shortage = Math.max(0, Number(item.quantity || 0) - stock);
                          const isReady = Boolean(cataloguePart) && shortage <= 0;
                          return <div key={item.id || index} className="rounded-xl border border-slate-200 bg-slate-50/70">
                            <div className="flex items-center justify-between rounded-t-xl border-b border-slate-200 bg-white px-4 py-2.5">
                              <div className="flex items-center gap-2"><span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500">Part {String(index + 1).padStart(2, "0")}</span><span className={`rounded-full px-2 py-0.5 text-[9px] font-bold ${!cataloguePart ? "bg-slate-100 text-slate-500" : isReady ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"}`}>{!cataloguePart ? "Select stock item" : isReady ? "Stock available" : `${shortage} short`}</span></div>
                              <button type="button" onClick={() => setPartToRemoveModal({ index, name: item.description || item.code || `Part ${index + 1}`, code: item.code })} className="inline-flex items-center rounded-lg px-2 py-1.5 text-[10px] font-bold text-rose-600 transition-colors hover:bg-rose-50" aria-label={`Remove required part ${index + 1}`}><Trash2 className="mr-1 h-3.5 w-3.5" />Remove part</button>
                            </div>
                            <div className="space-y-3 p-4">
                              <label className="block"><span className="mb-1.5 block text-[10px] font-extrabold uppercase tracking-wide text-slate-500">Stock catalogue</span><DocumentItemCatalogSelect compact itemType="part" code={item.code} description={item.description} parts={inspectionPartCatalog} services={[]} onSelect={(selection) => { const selectedCatalogPart = inspectionCatalogBySku.get(selection.code); setInspectionParts((current) => current.map((line, lineIndex) => lineIndex === index ? { ...line, partId: selectedCatalogPart?.id || null, code: selection.code, description: selection.description, unitPrice: selection.unitPrice, uom: selectedCatalogPart?.uom || "" } : line)); setInspectionPartsConfirmed(false); }} /></label>
                              <label className="block"><span className="mb-1.5 block text-[10px] font-extrabold uppercase tracking-wide text-slate-500">Part description</span><input value={item.description} onChange={(event) => { setInspectionParts((current) => current.map((line, lineIndex) => lineIndex === index ? { ...line, description: event.target.value } : line)); setInspectionPartsConfirmed(false); }} placeholder="Part description" className="h-10 w-full rounded-lg border border-slate-300 bg-white px-3 text-xs outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100" /></label>
                              <div className="grid grid-cols-3 gap-2">
                                <label className="rounded-lg border border-slate-200 bg-white px-3 py-2"><span className="block text-[9px] font-extrabold uppercase tracking-wide text-slate-500">Required qty</span><input type="number" min="0.01" step="0.01" value={item.quantity} onChange={(event) => { setInspectionParts((current) => current.map((line, lineIndex) => lineIndex === index ? { ...line, quantity: Number(event.target.value) } : line)); setInspectionPartsConfirmed(false); }} className="mt-1 h-7 w-full border-0 bg-transparent p-0 text-base font-extrabold text-slate-900 outline-none" /></label>
                                <div className="rounded-lg border border-slate-200 bg-white px-3 py-2"><p className="text-[9px] font-extrabold uppercase tracking-wide text-slate-500">Stock now</p><p className={`mt-1 text-base font-extrabold ${cataloguePart ? "text-slate-900" : "text-slate-400"}`}>{cataloguePart ? stock : "—"}</p></div>
                                <div className={`rounded-lg border px-3 py-2 ${!cataloguePart ? "border-slate-200 bg-white" : shortage > 0 ? "border-rose-200 bg-rose-50" : "border-emerald-200 bg-emerald-50"}`}><p className="text-[9px] font-extrabold uppercase tracking-wide text-slate-500">Shortage</p><p className={`mt-1 text-base font-extrabold ${!cataloguePart ? "text-slate-400" : shortage > 0 ? "text-rose-700" : "text-emerald-700"}`}>{cataloguePart ? shortage : "—"}</p></div>
                              </div>
                            </div>
                          </div>;
                        })}</div> : <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 px-5 py-7 text-center"><PackageSearch className="mx-auto h-6 w-6 text-slate-300" /><p className="mt-2 text-xs font-bold text-slate-700">No parts required?</p><p className="mt-1 text-[10px] text-slate-500">Leave this list empty and confirm the assessment below.</p></div>}
                        <button type="button" onClick={() => { setInspectionParts((current) => [...current, blankInspectionPart()]); setInspectionPartsConfirmed(false); }} className="inline-flex h-11 w-full items-center justify-center rounded-xl border border-dashed border-violet-300 bg-violet-50/60 px-4 text-xs font-bold text-violet-800 transition-colors hover:border-violet-400 hover:bg-violet-100"><Plus className="mr-1.5 h-4 w-4" />Add another required part</button>
                        <label className={`flex cursor-pointer items-start gap-3 rounded-xl border p-4 transition-colors ${inspectionPartsConfirmed ? "border-emerald-300 bg-emerald-50" : "border-slate-200 bg-slate-50 hover:border-violet-300"}`}><input type="checkbox" checked={inspectionPartsConfirmed} onChange={(event) => setInspectionPartsConfirmed(event.target.checked)} className="sr-only" /><span className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border ${inspectionPartsConfirmed ? "border-emerald-600 bg-emerald-600 text-white" : "border-slate-300 bg-white text-transparent"}`}><Check className="h-3.5 w-3.5" /></span><span><span className="block text-xs font-extrabold text-slate-900">Confirm parts assessment</span><span className="mt-1 block text-[10px] leading-4 text-slate-500">All required parts and quantities are recorded, or this repair does not require any parts.</span></span></label>
                      </>
                    )}
                  </div>
                </section>
              ) : null}

              {selectedWO.canonicalStatus === "inspected" ? (
                <div className="rounded-xl border border-blue-200 bg-blue-50/60 p-5 shadow-sm">
                  <div className="flex items-start gap-3">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#1e3a8a] text-white shadow-sm">
                      <FileText className="h-5 w-5" />
                    </span>
                    <div>
                      <h4 className="text-sm font-extrabold text-slate-900">Mandatory Step: Review & Prepare Quotation</h4>
                      <p className="mt-1 text-xs leading-5 text-slate-600">
                        Vehicle inspection is complete. You must review diagnosed parts, labor pricing and terms first, then choose whether to issue to customer or internally approve.
                      </p>
                    </div>
                  </div>
                  {canManageQuotation ? (
                    <button
                      type="button"
                      disabled={isSaving}
                      onClick={() => openQuotationModal(selectedWO)}
                      className="mt-4 inline-flex min-h-14 w-full items-center justify-center rounded-xl bg-[#1e3a8a] px-6 py-4 text-center text-base font-bold text-white shadow-md transition-all hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-200 disabled:opacity-50 cursor-pointer"
                    >
                      <FileText className="mr-2 h-5 w-5" />
                      Review & Prepare Quotation
                    </button>
                  ) : (
                    <p className="mt-3 text-xs font-semibold text-slate-500">Waiting for Head Manager or Admin to review quotation.</p>
                  )}
                </div>
              ) : selectedWO.canonicalStatus === "quotation_issued" ? (
                <div className="rounded-xl border border-cyan-200 bg-cyan-50/60 p-5 shadow-sm">
                  <div className="flex items-start gap-3">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-cyan-700 text-white shadow-sm">
                      <Send className="h-5 w-5" />
                    </span>
                    <div>
                      <h4 className="text-sm font-extrabold text-cyan-950">Quotation Issued to Customer</h4>
                      <p className="mt-1 text-xs leading-5 text-cyan-800">
                        Waiting for digital customer approval via app, or open quotation to authorize internally if verbally agreed.
                      </p>
                    </div>
                  </div>
                  {canManageQuotation ? (
                    <button
                      type="button"
                      disabled={isSaving}
                      onClick={() => openQuotationModal(selectedWO)}
                      className="mt-4 inline-flex min-h-12 w-full items-center justify-center rounded-xl border-2 border-cyan-300 bg-white px-6 py-3 text-center text-sm font-bold text-cyan-900 shadow-sm transition-colors hover:bg-cyan-100 focus:outline-none focus:ring-4 focus:ring-cyan-100 disabled:opacity-50 cursor-pointer"
                    >
                      <FileText className="mr-2 h-4 w-4" />
                      View Quotation / Internal Approve
                    </button>
                  ) : null}
                </div>
              ) : getAllowedNextStatuses(selectedWO.canonicalStatus, effectivePartsStatus || selectedWO.partsStatus || "not_required", Boolean(selectedWO.isBackOrder)).length > 0 ? (
                <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
                  <p className="text-center text-xs font-semibold uppercase tracking-wider text-gray-500">Next allowed action</p>
                  <div className="flex flex-col items-center gap-3 pt-3">
                    {getAllowedNextStatuses(selectedWO.canonicalStatus, effectivePartsStatus || selectedWO.partsStatus || "not_required", Boolean(selectedWO.isBackOrder)).map((status) => (
                      <button
                        key={status}
                        type="button"
                        disabled={isSaving || (status === "inspected" && (!inspectionPartsConfirmed || inspectionPartsLoading))}
                        onClick={() => handleUpdateStatus(status)}
                        className="min-h-14 w-full rounded-xl border-2 border-blue-600 bg-[#1e3a8a] px-6 py-4 text-center text-base font-bold text-white shadow-sm transition-colors hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-200 disabled:opacity-50 cursor-pointer"
                      >
                        {t(`status_${status}`)}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="rounded-lg border border-gray-200 bg-gray-50 p-4 text-sm text-gray-600">
                  {["pending_parts", "partially_arrived"].includes(effectivePartsStatus || selectedWO.partsStatus || "")
                    ? "Repair is locked while parts are pending. Update stock receiving, then mark Parts Status as Parts Ready."
                    : selectedWO.canonicalStatus === "collected"
                    ? "This work order is completed and locked. Collected is the final status."
                    : "No lifecycle action is available for your role. The next step must be completed by a Head Manager or Admin."}
                </div>
              )}

              {canRollbackStatus && !["scheduled", "collected"].includes(selectedWO.canonicalStatus) && !(isHeadManagerRole && selectedWO.canonicalStatus === "checked_in") ? (
                <section className={`rounded-xl border p-4 ${rollbackConfirmOpen ? "border-amber-300 bg-amber-50" : "border-slate-200 bg-white"}`}>
                  {!rollbackConfirmOpen ? <div className="flex flex-wrap items-center justify-between gap-3"><div><p className="text-xs font-extrabold text-slate-800">Pressed the wrong status?</p><p className="mt-1 text-[10px] leading-4 text-slate-500">Restore only the previous valid workflow step. The correction is recorded and notifications are sent.</p></div><button type="button" disabled={isSaving} onClick={() => setRollbackConfirmOpen(true)} className="inline-flex h-10 items-center rounded-lg border border-amber-300 bg-amber-50 px-3 text-xs font-bold text-amber-800 hover:bg-amber-100 disabled:opacity-50"><Undo2 className="mr-1.5 h-4 w-4" />Undo last status</button></div> : <div className="space-y-3"><div className="flex items-start gap-3"><span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-amber-100 text-amber-700"><Undo2 className="h-4 w-4" /></span><div><p className="text-sm font-extrabold text-amber-950">Confirm status rollback</p><p className="mt-0.5 text-[10px] leading-4 text-amber-800">The previous valid step will be restored. Admin, customer and workshop notifications will identify this as a correction.</p></div></div><label className="block text-xs font-semibold text-slate-700">Reason <span className="text-rose-500">*</span><textarea autoFocus maxLength={500} rows={2} value={rollbackReason} onChange={(event) => setRollbackReason(event.target.value)} placeholder="Example: Status selected by mistake" className="mt-1 w-full resize-none rounded-lg border border-amber-300 bg-white px-3 py-2 text-sm font-normal outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-100" /></label><div className="grid grid-cols-2 gap-2"><button type="button" disabled={isSaving} onClick={() => { setRollbackConfirmOpen(false); setRollbackReason(""); }} className="h-10 rounded-lg border border-slate-300 bg-white text-xs font-bold text-slate-700 hover:bg-slate-50">Keep current status</button><button type="button" disabled={isSaving || rollbackReason.trim().length < 1} onClick={handleRollbackStatus} className="inline-flex h-10 items-center justify-center rounded-lg bg-amber-600 px-3 text-xs font-bold text-white hover:bg-amber-700 disabled:opacity-50"><Undo2 className="mr-1.5 h-4 w-4" />{isSaving ? "Rolling back..." : "Confirm rollback"}</button></div></div>}
                </section>
              ) : null}
            </div>

            <div className="flex items-center justify-end border-t border-slate-200 bg-white px-4 py-3.5 sm:px-7">
              <button
                type="button"
                onClick={closeModal}
                className="h-10 rounded-lg border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Confirmation Modal for Removing Inspection Part */}
      {partToRemoveModal && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-100">
          <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-5 border border-slate-200 animate-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 mb-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rose-50 text-rose-600 ring-1 ring-rose-200">
                <Trash2 className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">Remove Spare Part?</h3>
                <p className="text-xs text-slate-500">Confirm removing this required part</p>
              </div>
            </div>
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 mb-4">
              <p className="text-xs font-bold text-slate-900">{partToRemoveModal.name}</p>
              {partToRemoveModal.code ? (
                <span className="mt-1 inline-block font-mono text-[10px] font-bold text-slate-500 bg-white px-1.5 py-0.5 rounded border border-slate-200">
                  {partToRemoveModal.code}
                </span>
              ) : null}
            </div>
            <p className="text-xs text-slate-600 mb-4">
              Are you sure you want to remove this item from the required parts list?
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setPartToRemoveModal(null)}
                className="rounded-xl border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 active:bg-slate-100 transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  setInspectionParts((current) => current.filter((_, lineIndex) => lineIndex !== partToRemoveModal.index));
                  setInspectionPartsConfirmed(false);
                  setPartToRemoveModal(null);
                  toast.success("Part removed from requirements list.");
                }}
                className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white shadow-sm hover:bg-rose-700 active:scale-95 transition-all"
              >
                Confirm Remove
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
