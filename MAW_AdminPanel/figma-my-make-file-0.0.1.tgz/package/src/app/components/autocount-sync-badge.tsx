import { CheckCircle2, Clock, RefreshCw } from "lucide-react";

interface AutoCountSyncBadgeProps {
  lastSync?: string | null;
  status?: "success" | "pending" | "failed" | string | null;
  label?: string;
  className?: string;
  onRefresh?: () => void;
  isRefreshing?: boolean;
}

function formatSyncTime(value?: string | null): string {
  if (!value) return "Live Sync";
  const parsed = new Date(value.includes("T") ? value : value.replace(" ", "T"));
  if (Number.isNaN(parsed.getTime())) return value;

  const now = new Date();
  const diffMs = now.getTime() - parsed.getTime();
  const diffMins = Math.floor(diffMs / 60000);

  if (diffMins < 1) return "Just now";
  if (diffMins === 1) return "1 min ago";
  if (diffMins < 60) return `${diffMins} mins ago`;

  const isToday = now.toDateString() === parsed.toDateString();
  const timeStr = parsed.toLocaleTimeString("en-MY", {
    hour: "2-digit",
    minute: "2-digit",
  });

  if (isToday) return `Today ${timeStr}`;

  return parsed.toLocaleDateString("en-MY", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function AutoCountSyncBadge({
  lastSync,
  status = "success",
  label = "AutoCount Synced",
  className = "",
  onRefresh,
  isRefreshing = false,
}: AutoCountSyncBadgeProps) {
  const formattedTime = formatSyncTime(lastSync);

  return (
    <div
      className={`inline-flex items-center gap-1.5 rounded-full border border-emerald-200/80 bg-emerald-50/70 px-3 py-1 text-xs font-medium text-emerald-800 shadow-sm backdrop-blur-sm transition-all hover:bg-emerald-50 ${className}`}
      title={lastSync ? `AutoCount Sync Time: ${lastSync}` : "Connected to AutoCount ERP"}
    >
      <span className="relative flex h-2 w-2">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
        <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
      </span>
      <span className="font-semibold text-emerald-900">{label}</span>
      <span className="text-emerald-300">·</span>
      <span className="text-emerald-700 flex items-center gap-1 font-normal">
        <Clock className="h-3 w-3 inline text-emerald-600/70" />
        {formattedTime}
      </span>
      {onRefresh && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onRefresh();
          }}
          disabled={isRefreshing}
          className="ml-1 rounded-full p-0.5 text-emerald-600 hover:bg-emerald-100/60 hover:text-emerald-900 focus:outline-none"
          title="Refresh synced data"
        >
          <RefreshCw className={`h-3 w-3 ${isRefreshing ? "animate-spin" : ""}`} />
        </button>
      )}
    </div>
  );
}
