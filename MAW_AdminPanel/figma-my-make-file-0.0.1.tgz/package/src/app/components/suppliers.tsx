import { useMemo, useState } from "react";
import { CheckCircle2, Clock3, Eye, Package, RefreshCw, Search, Truck, X, Download } from "lucide-react";
import { useApiData } from "../lib/use-api-data";
import { AdminSelect } from "./ui/admin-select";
import { AutoCountSyncBadge } from "./autocount-sync-badge";
import { exportTableToExcel, ExcelColumnDef } from "../lib/excel-export";
import { toast } from "sonner";

type Supplier = {
  code: string;
  name: string;
  registrationNo: string;
  attention: string;
  phone: string;
  mobile: string;
  email: string;
  address: string;
  purchaseAgent: string;
  term: string;
  currency: string;
  creditLimit: number;
  creditorType: string;
  taxCode: string;
  active: boolean;
  lastModified: string | null;
  itemCount: number;
  fields: Record<string, string | number | null>;
};

type SupplierResponse = {
  suppliers: Supplier[];
  lastSync: { status: string; remark: string; date: string | null } | null;
};

const pageSize = 25;

function displayDateTime(value: string | null) {
  if (!value) return "—";
  const parsed = new Date(value.includes("T") ? value : value.replace(" ", "T"));
  if (Number.isNaN(parsed.getTime())) return value;
  return parsed.toLocaleString("en-MY", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function displayMoney(value: number, currency: string) {
  return new Intl.NumberFormat("en-MY", {
    style: "currency",
    currency: currency || "MYR",
    maximumFractionDigits: 2,
  }).format(value || 0);
}

function Detail({ label, value }: { label: string; value: string | number }) {
  return (
    <div>
      <dt className="text-[10px] font-bold uppercase tracking-wide text-slate-400">{label}</dt>
      <dd className="mt-1 break-words text-sm font-semibold text-slate-800">{value === "" ? "—" : value}</dd>
    </div>
  );
}

function SupplierDetails({ supplier, onClose }: { supplier: Supplier; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-labelledby="supplier-detail-title">
      <div className="flex max-h-[92vh] w-full max-w-5xl flex-col overflow-hidden rounded-2xl bg-white shadow-2xl">
        <header className="flex items-start justify-between border-b border-slate-200 p-5">
          <div>
            <p className="text-xs font-bold uppercase tracking-wide text-blue-700">AutoCount Supplier · {supplier.code}</p>
            <h2 id="supplier-detail-title" className="mt-1 text-xl font-extrabold text-slate-900">{supplier.name}</h2>
          </div>
          <button type="button" onClick={onClose} className="rounded-lg bg-slate-100 p-2 text-slate-600" aria-label="Close supplier details"><X className="h-5 w-5" /></button>
        </header>
        <div className="space-y-5 overflow-y-auto p-5">
          <section>
            <h3 className="mb-3 text-xs font-extrabold uppercase tracking-wide text-slate-500">Summary</h3>
            <dl className="grid gap-4 rounded-xl border border-slate-200 bg-slate-50 p-4 sm:grid-cols-2 lg:grid-cols-4">
              <Detail label="Registration No." value={supplier.registrationNo} />
              <Detail label="Attention" value={supplier.attention} />
              <Detail label="Purchase Agent" value={supplier.purchaseAgent} />
              <Detail label="Phone" value={supplier.mobile || supplier.phone} />
              <Detail label="Email" value={supplier.email} />
              <Detail label="Payment Term" value={supplier.term} />
              <Detail label="Credit Limit" value={displayMoney(supplier.creditLimit, supplier.currency)} />
              <Detail label="Linked Items" value={supplier.itemCount.toLocaleString()} />
              <div className="sm:col-span-2 lg:col-span-4"><Detail label="Address" value={supplier.address} /></div>
            </dl>
          </section>
          <section>
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-xs font-extrabold uppercase tracking-wide text-slate-500">All AutoCount Fields</h3>
              <span className="rounded-full bg-blue-50 px-2.5 py-1 text-xs font-bold text-blue-700">{Object.keys(supplier.fields).length} fields</span>
            </div>
            <dl className="grid gap-x-5 gap-y-4 rounded-xl border border-slate-200 p-4 sm:grid-cols-2 lg:grid-cols-3">
              {Object.entries(supplier.fields).map(([field, value]) => (
                <Detail key={field} label={field} value={value === null || value === "" ? "—" : String(value)} />
              ))}
            </dl>
          </section>
        </div>
      </div>
    </div>
  );
}

export function Suppliers() {
  const { data, isLoading, error, reload } = useApiData<SupplierResponse>("admin-suppliers", { suppliers: [], lastSync: null });
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<"all" | "active" | "inactive" | "linked" | "unlinked">("all");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Supplier | null>(null);

  const filtered = useMemo(() => {
    const needle = search.trim().toLowerCase();
    return data.suppliers.filter((supplier) => {
      const matchesStatus = status === "all"
        || (status === "active" && supplier.active)
        || (status === "inactive" && !supplier.active)
        || (status === "linked" && supplier.itemCount > 0)
        || (status === "unlinked" && supplier.itemCount === 0);
      if (!matchesStatus) return false;
      if (!needle) return true;
      return [supplier.code, supplier.name, supplier.registrationNo, supplier.attention, supplier.phone, supplier.mobile, supplier.email]
        .some((value) => value.toLowerCase().includes(needle));
    });
  }, [data.suppliers, search, status]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const visible = filtered.slice((safePage - 1) * pageSize, safePage * pageSize);
  const activeCount = data.suppliers.reduce((count, supplier) => count + (supplier.active ? 1 : 0), 0);
  const linkedItems = data.suppliers.reduce((count, supplier) => count + supplier.itemCount, 0);

  const handleExportSuppliers = async () => {
    if (filtered.length === 0) {
      toast.error("No suppliers available to export.");
      return;
    }

    const columnDefs: ExcelColumnDef[] = [
      { header: "Supplier Code", key: "code", align: "left", minWidth: 16, numFmt: "@" },
      { header: "Supplier Name", key: "name", align: "left", minWidth: 28 },
      { header: "Registration No", key: "registrationNo", align: "left", minWidth: 18, numFmt: "@" },
      { header: "Attention Person", key: "attention", align: "left", minWidth: 20 },
      { header: "Phone", key: "phone", align: "left", minWidth: 16, numFmt: "@" },
      { header: "Mobile", key: "mobile", align: "left", minWidth: 16, numFmt: "@" },
      { header: "Email Address", key: "email", align: "left", minWidth: 26 },
      { header: "Address", key: "address", align: "left", minWidth: 36 },
      { header: "Credit Terms", key: "term", align: "center", minWidth: 14 },
      { header: "Credit Limit (RM)", key: "creditLimit", align: "right", minWidth: 18, numFmt: "#,##0.00" },
      { header: "Tax Code", key: "taxCode", align: "center", minWidth: 12 },
      { header: "Linked Items", key: "itemCount", align: "right", minWidth: 14, numFmt: "#,##0" },
      { header: "Status", key: "status", align: "center", minWidth: 14 },
    ];

    const rows = filtered.map((s) => ({
      code: String(s.code || "-"),
      name: String(s.name || "-"),
      registrationNo: String(s.registrationNo || "-"),
      attention: String(s.attention || "-"),
      phone: String(s.phone || "-"),
      mobile: String(s.mobile || "-"),
      email: String(s.email || "-"),
      address: String(s.address || "-"),
      term: String(s.term || "-"),
      creditLimit: Number(s.creditLimit || 0),
      taxCode: String(s.taxCode || "-"),
      itemCount: Number(s.itemCount || 0),
      status: s.active ? "ACTIVE" : "INACTIVE",
    }));

    const fileName = `maw-suppliers-${new Date().toISOString().slice(0, 10)}.xlsx`;
    await exportTableToExcel({
      fileName,
      sheetName: "Suppliers",
      columns: columnDefs,
      data: rows,
      successMessage: `Exported ${filtered.length} suppliers to ${fileName}`,
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-2xl font-extrabold text-slate-900">Suppliers</h1>
            <AutoCountSyncBadge
              label="Suppliers Synced"
              lastSync={data.lastSync?.date}
              onRefresh={() => void reload()}
              isRefreshing={isLoading}
            />
          </div>
          <p className="mt-0.5 text-xs text-slate-500">
            Synchronized supplier & creditor master from AutoCount ERP
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportSuppliers}
            disabled={isLoading || filtered.length === 0}
            className="inline-flex h-10 items-center justify-center rounded-xl border border-gray-300 bg-white px-4 text-sm font-semibold text-gray-700 shadow-sm transition-colors hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Download className="mr-2 h-4 w-4" />
            Export Excel
          </button>
        </div>
      </div>
      {error ? <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</p> : null}
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm"><Truck className="h-5 w-5 text-blue-600" /><p className="mt-3 text-xs font-semibold uppercase tracking-wide text-gray-500">Total Suppliers</p><p className="mt-1 text-2xl font-bold text-gray-900">{data.suppliers.length}</p></div>
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm"><CheckCircle2 className="h-5 w-5 text-emerald-600" /><p className="mt-3 text-xs font-semibold uppercase tracking-wide text-gray-500">Active</p><p className="mt-1 text-2xl font-bold text-gray-900">{activeCount}</p></div>
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm"><Package className="h-5 w-5 text-indigo-600" /><p className="mt-3 text-xs font-semibold uppercase tracking-wide text-gray-500">Linked Items</p><p className="mt-1 text-2xl font-bold text-gray-900">{linkedItems.toLocaleString()}</p></div>
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm"><Clock3 className="h-5 w-5 text-amber-600" /><p className="mt-3 text-xs font-semibold uppercase tracking-wide text-gray-500">Last Sync</p><p className="mt-1 text-sm font-bold text-gray-900">{displayDateTime(data.lastSync?.date || null)}</p><p className="mt-1 truncate text-xs text-gray-500" title={data.lastSync?.remark || undefined}>{data.lastSync?.status || "No sync log"}</p></div>
      </div>
      <div className="maw-filter-bar">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
          <div className="md:col-span-2">
            <div className="maw-search-field">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                value={search}
                onChange={(event) => { setSearch(event.target.value); setPage(1); }}
                placeholder="Search supplier code, company, registration, phone or email..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
              />
            </div>
          </div>
          <div>
            <AdminSelect
              value={status}
              onChange={(event) => { setStatus(event.target.value as typeof status); setPage(1); }}
              className="w-full"
              aria-label="Filter suppliers"
            >
              <option value="all">All suppliers</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="linked">Linked to items</option>
              <option value="unlinked">No linked items</option>
            </AdminSelect>
          </div>
        </div>
      </div>
      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50"><tr>{["Supplier", "Contact", "Terms / Credit", "Linked Items", "Status", "Last Modified", ""].map((heading) => <th key={heading || "action"} scope="col" className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">{heading}</th>)}</tr></thead>
            <tbody className="divide-y divide-gray-100 bg-white">
              {isLoading && data.suppliers.length === 0 ? <tr><td colSpan={7} className="px-5 py-12 text-center text-sm text-gray-500">Loading Suppliers…</td></tr> : null}
              {!isLoading && visible.length === 0 ? <tr><td colSpan={7} className="px-5 py-12 text-center text-sm text-gray-500">No suppliers match the current filters.</td></tr> : null}
              {visible.map((supplier) => (
                <tr key={supplier.code} className="align-top transition-colors hover:bg-gray-50 [content-visibility:auto]">
                  <td className="px-5 py-4"><p className="font-semibold text-gray-900">{supplier.name || "Unnamed supplier"}</p><p className="mt-1 font-mono text-xs font-bold text-blue-700">{supplier.code}</p>{supplier.registrationNo ? <p className="mt-1 text-xs text-gray-500">Reg: {supplier.registrationNo}</p> : null}</td>
                  <td className="px-5 py-4 text-sm text-gray-600"><p>{supplier.attention || "—"}</p><p className="mt-1 text-xs">{supplier.mobile || supplier.phone || "No phone"}</p><p className="mt-1 max-w-52 truncate text-xs text-gray-500" title={supplier.email}>{supplier.email || "No email"}</p></td>
                  <td className="px-5 py-4 text-sm text-gray-700"><p>{supplier.term || "No term"}</p><p className="mt-1 text-xs text-gray-500">{displayMoney(supplier.creditLimit, supplier.currency)}</p></td>
                  <td className="px-5 py-4"><span className="rounded-full bg-indigo-50 px-2.5 py-1 text-xs font-bold text-indigo-700">{supplier.itemCount.toLocaleString()} items</span></td>
                  <td className="px-5 py-4"><span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-bold ${supplier.active ? "bg-emerald-50 text-emerald-700" : "bg-gray-100 text-gray-600"}`}>{supplier.active ? "Active" : "Inactive"}</span>{supplier.creditorType ? <p className="mt-2 text-xs text-gray-500">{supplier.creditorType}</p> : null}</td>
                  <td className="whitespace-nowrap px-5 py-4 text-xs text-gray-500">{displayDateTime(supplier.lastModified)}</td>
                  <td className="px-5 py-4 text-right"><button type="button" onClick={() => setSelected(supplier)} className="rounded-lg p-2 text-blue-700 transition-colors hover:bg-blue-50" aria-label={`View ${supplier.name || supplier.code}`}><Eye className="h-4 w-4" /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-gray-200 px-5 py-3 text-sm text-gray-600"><p>Showing {visible.length} of {filtered.length} suppliers</p><div className="flex items-center gap-2"><button type="button" onClick={() => setPage((current) => Math.max(1, current - 1))} disabled={safePage === 1} className="rounded-lg border border-gray-200 px-3 py-1.5 font-semibold disabled:opacity-40">Previous</button><span>Page {safePage} of {totalPages}</span><button type="button" onClick={() => setPage((current) => Math.min(totalPages, current + 1))} disabled={safePage === totalPages} className="rounded-lg border border-gray-200 px-3 py-1.5 font-semibold disabled:opacity-40">Next</button></div></div>
      </div>
      {selected ? <SupplierDetails supplier={selected} onClose={() => setSelected(null)} /> : null}
    </div>
  );
}
