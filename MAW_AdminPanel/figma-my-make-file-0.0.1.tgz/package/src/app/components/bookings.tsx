import { useState, useMemo } from "react";
import { useNavigate } from "react-router";
import {
  Search,
  Plus,
  Eye,
  Edit,
  CheckCircle,
  XCircle,
  Trash2,
  X,
  ClipboardPlus,
  CalendarPlus2,
  UserRound,
  CalendarClock,
  Wrench,
  ClipboardList,
  Save,
  ArrowLeft,
  Download,
} from "lucide-react";
import { useLanguage } from "../contexts/language-context";
import { useApiData } from "../lib/use-api-data";
import { postApi } from "../lib/api";
import { toast } from "sonner";
import { useConfirmationDialog } from "../contexts/confirmation-dialog-context";
import { DesktopDatePicker } from "./ui/desktop-date-picker";
import { DesktopTimePicker } from "./ui/desktop-time-picker";
import { AdminSelect } from "./ui/admin-select";
import type { StaffMember } from "./staff";
import { hasAdminPermission } from "../lib/admin-permissions";
import { exportTableToExcel, ExcelColumnDef } from "../lib/excel-export";

interface BookingItem {
  id: string;
  idVal?: number;
  customerId?: number;
  customer: string;
  companyId?: number;
  companyName?: string;
  vehicleId?: number;
  vehicle: string;
  service: string;
  date: string;
  time: string;
  location: string;
  status: string;
  technician: string;
  staffId?: number;
  customerNotes: string;
  reportedProblem: string;
  technicianNotes: string;
}

const mockBookings: BookingItem[] = [];

const statusColors: Record<string, string> = {
  Pending: "bg-yellow-100 text-yellow-800",
  Confirmed: "bg-green-100 text-green-800",
  "In Progress": "bg-blue-100 text-blue-800",
  Completed: "bg-gray-100 text-gray-800",
  Cancelled: "bg-red-100 text-red-800",
};

const knownServiceCentres = [
  "Pasir Gudang HQ",
  "MEWAH TRANS LOGISTIC SDN BHD",
  "Mewah AutoWorks Kuala Lumpur",
  "Mewah AutoWorks Petaling Jaya",
];

const formatBookingTime = (value: string) => {
  const match = /^(\d{1,2}):(\d{2})/.exec(value || "");
  if (!match) return value || "-";
  const hour = Number(match[1]);
  const minute = match[2];
  const period = hour >= 12 ? "PM" : "AM";
  const displayHour = hour % 12 || 12;
  return `${String(displayHour).padStart(2, "0")}:${minute} ${period}`;
};

export function Bookings() {
  const navigate = useNavigate();
  const canCreate = hasAdminPermission("booking.create");
  const canUpdate = hasAdminPermission("booking.update");
  const canDelete = hasAdminPermission("booking.delete");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("All");
  const [modalMode, setModalMode] = useState<"create" | "edit" | "view" | null>(null);
  const [selectedBooking, setSelectedBooking] = useState<BookingItem | null>(null);
  const [checkInTarget, setCheckInTarget] = useState<BookingItem | null>(null);
  const [checkInForm, setCheckInForm] = useState({
    priority: "Normal",
    bay: "",
    estimatedOut: "",
    technicianIds: [] as number[],
    checkinMileage: "",
  });
  const [isCheckingIn, setIsCheckingIn] = useState(false);

  const { t } = useLanguage();
  const confirmAction = useConfirmationDialog();
  
  // Api Data Fetching
  const { data: bookingsData, isLoading, error, reload, hasLoaded } = useApiData<BookingItem[]>("admin-bookings", []);
  const { data: customersData } = useApiData<{ id: number; name: string; phone: string; companyId: number }[]>("admin-customers", []);
  const { data: vehiclesData } = useApiData<{ id: number; regNo: string; brand: string; model: string; companyId: number }[]>("admin-vehicles", []);
  const { data: companiesData } = useApiData<{ id: number; name: string }[]>("admin-companies", []);
  const { data: staffData } = useApiData<StaffMember[]>("admin-staff", []);

  // Form State
  const [form, setForm] = useState({
    id: "",
    idVal: 0,
    customerId: 0,
    vehicleId: 0,
    service: "",
    date: "",
    time: "",
    location: "Pasir Gudang HQ",
    status: "Pending",
    technician: "",
    staffId: "",
    customerNotes: "",
    reportedProblem: "",
    technicianNotes: "",
  });

  const bookings = useMemo(() => {
    if (isLoading && !hasLoaded) {
      return [];
    }
    if (error && bookingsData.length === 0) {
      return mockBookings;
    }
    return bookingsData;
  }, [bookingsData, isLoading, hasLoaded, error]);

  const filteredBookings = bookings.filter((booking) => {
    const matchesSearch =
      booking.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      booking.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (booking.companyName && booking.companyName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      booking.vehicle.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = selectedStatus === "All" || booking.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  const stats = [
    { label: "Total Bookings", value: bookings.length, color: "text-gray-900" },
    {
      label: "Pending",
      value: bookings.filter((b) => b.status === "Pending").length,
      color: "text-yellow-600",
    },
    {
      label: "Confirmed",
      value: bookings.filter((b) => b.status === "Confirmed").length,
      color: "text-green-600",
    },
    {
      label: "In Progress",
      value: bookings.filter((b) => b.status === "In Progress").length,
      color: "text-blue-600",
    },
  ];

  // Dynamic filter for vehicles selection based on selected customer's company
  const filteredVehiclesForForm = useMemo(() => {
    if (!form.customerId) return vehiclesData;
    const selectedCust = customersData.find((c) => c.id === form.customerId);
    if (!selectedCust || !selectedCust.companyId) return vehiclesData;
    return vehiclesData.filter((v) => v.companyId === selectedCust.companyId);
  }, [form.customerId, customersData, vehiclesData]);

  // Find customer company name dynamically for Form display
  const formCustomerCompanyName = useMemo(() => {
    if (!form.customerId) return "";
    const selectedCust = customersData.find((c) => c.id === form.customerId);
    if (!selectedCust || !selectedCust.companyId) return "";
    const comp = companiesData.find((c) => c.id === selectedCust.companyId);
    return comp ? comp.name : "";
  }, [form.customerId, customersData, companiesData]);

  const bookingStaff = useMemo(
    () => staffData.filter((member) =>
      member.status === "Active" &&
      member.role === "Foreman"
    ),
    [staffData],
  );

  const defaultBookingForemanId = useMemo(
    () => bookingStaff[0]?.id || "",
    [bookingStaff],
  );

  const openCreateModal = () => {
    setForm({
      id: "",
      idVal: 0,
      customerId: 0,
      vehicleId: 0,
      service: "",
      date: new Date().toISOString().substring(0, 10),
      time: "09:00",
      location: "Pasir Gudang HQ",
      status: "Pending",
      technician: bookingStaff[0]?.name || "",
      staffId: defaultBookingForemanId ? String(defaultBookingForemanId) : "",
      customerNotes: "",
      reportedProblem: "",
      technicianNotes: "",
    });
    setModalMode("create");
  };

  const openEditModal = (booking: BookingItem) => {
    setForm({
      id: booking.id,
      idVal: booking.idVal || 0,
      customerId: booking.customerId || 0,
      vehicleId: booking.vehicleId || 0,
      service: booking.service || "",
      date: booking.date || "",
      time: booking.time || "",
      location: booking.location || "",
      status: booking.status || "Pending",
      technician: booking.technician === "-" ? "" : booking.technician,
      staffId: booking.staffId
        ? String(booking.staffId)
        : booking.technician && booking.technician !== "-"
          ? `legacy:${booking.technician}`
          : "",
      customerNotes: booking.customerNotes || "",
      reportedProblem: booking.reportedProblem || "",
      technicianNotes: booking.technicianNotes || "",
    });
    setModalMode("edit");
  };

  const openViewModal = (booking: BookingItem) => {
    setSelectedBooking(booking);
    setModalMode("view");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.customerId || !form.vehicleId || !form.service) {
      toast.error("Please fill in all required fields (*).");
      return;
    }

    try {
      const idParam = form.idVal > 0 ? form.idVal : form.id;
      const endpoint = modalMode === "create" ? "admin-create-booking" : "admin-update-booking";
      const payload = {
        id: modalMode === "edit" ? idParam : undefined,
        customerId: form.customerId,
        vehicleId: form.vehicleId,
        service: form.service,
        date: form.date,
        time: form.time,
        location: form.location,
        technician: form.technician,
        staffId: Number(form.staffId) || null,
        customerNotes: form.customerNotes,
        reportedProblem: form.reportedProblem,
        technicianNotes: form.technicianNotes,
      };

      await postApi(endpoint, payload);
      setModalMode(null);
      reload();
    } catch (err: any) {
      toast.error("Failed to save booking: " + err.message);
    }
  };

  const handleUpdateStatus = async (booking: BookingItem, newStatus: string) => {
    try {
      const idParam = booking.idVal && booking.idVal > 0 ? booking.idVal : booking.id;
      const payload = {
        id: idParam,
        status: newStatus,
        statusOnly: true,
      };

      await postApi("admin-update-booking", payload);
      reload();
    } catch (err: any) {
      toast.error("Failed to update status: " + err.message);
    }
  };

  const workOrderStaff = useMemo(
    () => staffData.filter((member) =>
      member.status === "Active" && ["Foreman", "Technician"].includes(member.role)
    ),
    [staffData],
  );

  const openCheckInModal = (booking: BookingItem) => {
    const preselectedStaffId = booking.staffId && workOrderStaff.some((member) => member.id === booking.staffId)
      ? [booking.staffId]
      : [];
    setCheckInForm({
      priority: "Normal",
      bay: "",
      estimatedOut: "",
      technicianIds: preselectedStaffId,
      checkinMileage: "",
    });
    setCheckInTarget(booking);
  };

  const handleCheckIn = async () => {
    if (!checkInTarget) return;
    setIsCheckingIn(true);
    try {
      const idParam = checkInTarget.idVal && checkInTarget.idVal > 0
        ? checkInTarget.idVal
        : checkInTarget.id;
      const workOrder = await postApi<{ id: number; workOrderNo: string }>("admin-check-in-booking", {
        id: idParam,
        priority: checkInForm.priority,
        bay: checkInForm.bay || null,
        estimatedOut: checkInForm.estimatedOut || null,
        technicianIds: checkInForm.technicianIds,
        checkinMileage: checkInForm.checkinMileage ? Number(checkInForm.checkinMileage) : null,
      });
      setCheckInTarget(null);
      reload();
      toast.success(`Vehicle checked in. Work order ${workOrder.workOrderNo} created.`);
      navigate("/work-orders?status=checked_in");
    } catch (err: any) {
      toast.error("Failed to check in vehicle: " + err.message);
    } finally {
      setIsCheckingIn(false);
    }
  };

  const handleDeleteBooking = async (booking: BookingItem) => {
    const confirmed = await confirmAction({
      title: `Delete booking "${booking.id}"?`,
      description: "This booking will be permanently removed. This action cannot be undone.",
      confirmLabel: "Delete booking",
      tone: "danger",
    });
    if (!confirmed) {
      return;
    }
    try {
      const idParam = booking.idVal && booking.idVal > 0 ? booking.idVal : booking.id;
      await postApi("admin-delete-booking", { id: idParam });
      reload();
      toast.success(`Booking "${booking.id}" deleted.`);
    } catch (err: any) {
      toast.error("Failed to delete booking: " + err.message);
    }
  };

  if (modalMode === "create" || modalMode === "edit") {
    return (
      <div className="space-y-4">
        {/* Header with Back Button */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setModalMode(null)}
              className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Bookings
            </button>
            <div>
              <h1 className="text-2xl font-extrabold text-slate-900">
                {modalMode === "create" ? "New Service Booking" : "Edit Service Booking"}
              </h1>
              <p className="mt-0.5 text-xs text-slate-500">
                {modalMode === "create" ? "Record and schedule a vehicle maintenance appointment." : "Update appointment time, technician or service details."}
              </p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div className="flex items-start gap-3 rounded-t-xl border-b border-slate-100 bg-white px-4 py-3.5 sm:px-5">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-blue-50 text-blue-700">
                <UserRound className="h-4 w-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">1. Customer &amp; vehicle</h3>
                <p className="mt-0.5 text-xs text-slate-500">Choose the company user first to show their available vehicles.</p>
              </div>
            </div>
            <div className="grid gap-4 p-4 sm:p-5 md:grid-cols-2">
              <div>
                <label htmlFor="booking-customer" className="mb-1.5 block text-xs font-semibold text-slate-700">
                  Company user <span className="text-red-500">*</span>
                </label>
                <AdminSelect
                  id="booking-customer"
                  value={form.customerId}
                  onChange={(e) => setForm({ ...form, customerId: Number(e.target.value), vehicleId: 0 })}
                  className="w-full"
                  required
                >
                  <option value={0}>Select company user</option>
                  {customersData.map((c) => (
                    <option key={c.id} value={c.id}>{c.name} ({c.phone})</option>
                  ))}
                </AdminSelect>
              </div>
              <div>
                <label htmlFor="booking-vehicle" className="mb-1.5 block text-xs font-semibold text-slate-700">
                  Vehicle <span className="text-red-500">*</span>
                </label>
                <AdminSelect
                  id="booking-vehicle"
                  value={form.vehicleId}
                  onChange={(e) => setForm({ ...form, vehicleId: Number(e.target.value) })}
                  className="w-full"
                  required
                  disabled={!form.customerId}
                >
                  <option value={0}>{!form.customerId ? "Select a company user first" : "Select company vehicle"}</option>
                  {filteredVehiclesForForm.map((v) => (
                    <option key={v.id} value={v.id}>{v.regNo} - {v.brand} {v.model}</option>
                  ))}
                </AdminSelect>
              </div>
              <div className="md:col-span-2 flex flex-wrap items-center gap-x-2 gap-y-1 rounded-lg border border-blue-100 bg-blue-50/70 px-3.5 py-2.5 text-xs">
                <span className="font-semibold text-blue-900">Linked company</span>
                <span className="text-blue-700">{form.customerId ? (formCustomerCompanyName || "No company linked") : "Selected automatically after choosing a user"}</span>
              </div>
            </div>
          </section>

          <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div className="flex items-start gap-3 rounded-t-xl border-b border-slate-100 bg-white px-4 py-3.5 sm:px-5">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-indigo-50 text-indigo-700">
                <CalendarClock className="h-4 w-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">2. Appointment</h3>
                <p className="mt-0.5 text-xs text-slate-500">Set what service is needed, then choose when and where.</p>
              </div>
            </div>
            <div className="grid gap-4 p-4 sm:p-5 md:grid-cols-2">
              <div className="md:col-span-2">
                <label htmlFor="booking-service" className="mb-1.5 block text-xs font-semibold text-slate-700">
                  Service type <span className="text-red-500">*</span>
                </label>
                <input
                  id="booking-service"
                  type="text"
                  placeholder="e.g. Engine maintenance or brake system repair"
                  value={form.service}
                  onChange={(e) => setForm({ ...form, service: e.target.value })}
                  className="h-10 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 hover:border-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
                  required
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-slate-700">Service date <span className="text-red-500">*</span></label>
                <DesktopDatePicker
                  value={form.date}
                  onChange={(value) => setForm({ ...form, date: value })}
                  ariaLabel="Choose service date"
                  className="h-10 w-full"
                  required
                />
              </div>
              <div>
                <label htmlFor="booking-time" className="mb-1.5 block text-xs font-semibold text-slate-700">Service time <span className="text-red-500">*</span></label>
                <DesktopTimePicker
                  value={form.time}
                  onChange={(value) => setForm({ ...form, time: value })}
                  ariaLabel="Choose service time"
                  className="h-10"
                  required
                />
              </div>
              <div className="md:col-span-2">
                <label htmlFor="booking-location" className="mb-1.5 block text-xs font-semibold text-slate-700">Service centre</label>
                <AdminSelect
                  id="booking-location"
                  value={form.location}
                  onChange={(e) => setForm({ ...form, location: e.target.value })}
                  className="w-full"
                >
                  {form.location && !knownServiceCentres.includes(form.location) ? <option value={form.location}>{form.location}</option> : null}
                  {knownServiceCentres.map((centre) => <option key={centre} value={centre}>{centre}</option>)}
                </AdminSelect>
              </div>
            </div>
          </section>

          <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div className="flex items-start gap-3 rounded-t-xl border-b border-slate-100 bg-white px-4 py-3.5 sm:px-5">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-amber-50 text-amber-700">
                <Wrench className="h-4 w-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">3. Service request</h3>
                <p className="mt-0.5 text-xs text-slate-500">Capture the main issue first; supporting notes can be added below.</p>
              </div>
            </div>
            <div className="grid gap-4 p-4 sm:p-5 md:grid-cols-2">
              <div className="md:col-span-2">
                <label htmlFor="booking-problem" className="mb-1.5 block text-xs font-semibold text-slate-700">Reported problem</label>
                <textarea
                  id="booking-problem"
                  placeholder="Describe the symptoms or issue reported by the driver..."
                  value={form.reportedProblem}
                  onChange={(e) => setForm({ ...form, reportedProblem: e.target.value })}
                  className="min-h-24 w-full resize-y rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 hover:border-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
                />
              </div>
              <div>
                <label htmlFor="booking-customer-notes" className="mb-1.5 block text-xs font-semibold text-slate-700">Customer notes <span className="font-normal text-slate-400">(optional)</span></label>
                <textarea
                  id="booking-customer-notes"
                  placeholder="Driver comments or special requests..."
                  value={form.customerNotes}
                  onChange={(e) => setForm({ ...form, customerNotes: e.target.value })}
                  className="min-h-20 w-full resize-y rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 hover:border-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
                />
              </div>
              <div>
                <label htmlFor="booking-technician-notes" className="mb-1.5 block text-xs font-semibold text-slate-700">Foreman notes <span className="font-normal text-slate-400">(optional)</span></label>
                <textarea
                  id="booking-technician-notes"
                  placeholder="Planned checks, measurements or repair notes..."
                  value={form.technicianNotes}
                  onChange={(e) => setForm({ ...form, technicianNotes: e.target.value })}
                  className="min-h-20 w-full resize-y rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 hover:border-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
                />
              </div>
            </div>
          </section>

          <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div className="flex items-start gap-3 rounded-t-xl border-b border-slate-100 bg-white px-4 py-3.5 sm:px-5">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-emerald-50 text-emerald-700">
                <ClipboardList className="h-4 w-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">4. Internal assignment</h3>
                <p className="mt-0.5 text-xs text-slate-500">Optional internal ownership and the current workflow state.</p>
              </div>
            </div>
            <div className="grid gap-4 p-4 sm:p-5 md:grid-cols-2">
              <div>
                <label htmlFor="booking-staff" className="mb-1.5 block text-xs font-semibold text-slate-700">Assigned foreman</label>
                <AdminSelect
                  id="booking-staff"
                  value={form.staffId}
                  onChange={(event) => {
                    const nextValue = event.target.value;
                    const staffId = Number(nextValue) || 0;
                    const selected = bookingStaff.find((member) => member.id === staffId);
                    setForm({ ...form, staffId: nextValue, technician: selected?.name ?? (nextValue.startsWith("legacy:") ? form.technician : "") });
                  }}
                  className="w-full"
                >
                  <option value="">Unassigned</option>
                  {form.technician && String(form.staffId).startsWith("legacy:") ? <option value={form.staffId}>{form.technician} (existing record)</option> : null}
                  {bookingStaff.map((member) => <option key={member.id} value={member.id}>{member.name} — {member.role}</option>)}
                </AdminSelect>
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-slate-700">Workflow status</label>
                <div className="flex h-10 items-center justify-between rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm font-semibold text-slate-700">
                  <span>{form.status}</span>
                  <span className="text-[10px] font-medium uppercase tracking-wider text-slate-400">Read only</span>
                </div>
                <p className="mt-1.5 text-[11px] text-slate-500">Change status later from the booking action buttons.</p>
              </div>
            </div>
          </section>

          <div className="flex flex-col-reverse gap-3 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:flex-row sm:items-center sm:justify-between sm:px-6">
            <p className="text-xs text-slate-500"><span className="font-bold text-red-500">*</span> Required fields must be completed</p>
            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setModalMode(null)}
                className="h-10 rounded-xl border border-slate-300 bg-white px-5 text-sm font-semibold text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="inline-flex h-10 items-center gap-2 rounded-xl bg-[#1e3a8a] px-6 text-sm font-semibold text-white shadow-sm hover:bg-blue-800"
              >
                <Save className="h-4 w-4" />
                {modalMode === "create" ? "Create Booking" : "Save Changes"}
              </button>
            </div>
          </div>
        </form>
      </div>
    );
  }

  const handleExportBookings = async () => {
    if (filteredBookings.length === 0) {
      toast.error("No bookings available to export.");
      return;
    }

    const columnDefs: ExcelColumnDef[] = [
      { header: "Booking ID", key: "id", align: "left", minWidth: 16, numFmt: "@" },
      { header: "Customer Name", key: "customer", align: "left", minWidth: 22 },
      { header: "Company", key: "companyName", align: "left", minWidth: 26 },
      { header: "Contact Phone", key: "phone", align: "left", minWidth: 18, numFmt: "@" },
      { header: "Vehicle", key: "vehicle", align: "left", minWidth: 16, numFmt: "@" },
      { header: "Service Type", key: "service", align: "left", minWidth: 22 },
      { header: "Booking Date", key: "date", align: "center", minWidth: 14 },
      { header: "Time Slot", key: "time", align: "center", minWidth: 14 },
      { header: "Service Location", key: "location", align: "left", minWidth: 24 },
      { header: "Status", key: "status", align: "center", minWidth: 16 },
      { header: "Remarks / Notes", key: "notes", align: "left", minWidth: 30 },
    ];

    const rows = filteredBookings.map((b) => ({
      id: String(b.id),
      customer: String(b.customer || "-"),
      companyName: String(b.companyName || "-"),
      phone: String(b.phone || "-"),
      vehicle: String(b.vehicle || "-"),
      service: String(b.service || "-"),
      date: String(b.date || "-").slice(0, 10),
      time: String(b.time || "-"),
      location: String(b.location || "Workshop"),
      status: String(b.status || "-").toUpperCase(),
      notes: String(b.notes || "-"),
    }));

    const fileName = `maw-bookings-${new Date().toISOString().slice(0, 10)}.xlsx`;
    await exportTableToExcel({
      fileName,
      sheetName: "Bookings",
      columns: columnDefs,
      data: rows,
      successMessage: `Exported ${filteredBookings.length} bookings to ${fileName}`,
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl text-gray-900 font-semibold">{t("booking_management")}</h1>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportBookings}
            disabled={isLoading || filteredBookings.length === 0}
            className="inline-flex h-10 items-center justify-center rounded-xl border border-gray-300 bg-white px-4 text-sm font-semibold text-gray-700 shadow-sm transition-colors hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Download className="mr-2 h-4 w-4" />
            Export Excel
          </button>
          {canCreate ? <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex h-10 items-center justify-center rounded-xl bg-[#1e3a8a] px-4 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-blue-800"
          >
            <Plus className="h-4 w-4 mr-2" />
            {t("add_booking")}
          </button> : null}
        </div>
      </div>

      {error && (
        <div className="rounded-lg border border-yellow-200 bg-yellow-50 px-4 py-3 text-sm text-yellow-800">
          Database connection check: {error}. Showing local data values.
        </div>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((stat, index) => (
          <div key={index} className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
            <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">{stat.label}</p>
            <p className={`mt-3 text-2xl font-bold ${stat.color}`}>{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="maw-filter-bar">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
          <div className="md:col-span-2">
            <div className="maw-search-field">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search bookings, drivers, companies or vehicles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
          <div>
            <AdminSelect
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full"
              aria-label="Filter booking status"
            >
              <option value="All">All Statuses</option>
              <option value="Pending">Pending</option>
              <option value="Confirmed">Confirmed</option>
              <option value="In Progress">In Progress</option>
              <option value="Completed">Completed</option>
              <option value="Cancelled">Cancelled</option>
            </AdminSelect>
          </div>
        </div>
      </div>

      {/* Bookings Table */}
      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">ID</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Company User</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Company</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Vehicle</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Service Type</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Date & Time</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Foreman</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredBookings.length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-6 py-10 text-center text-sm text-gray-500">
                    No bookings found.
                  </td>
                </tr>
              ) : (
                filteredBookings.map((booking) => (
                  <tr key={booking.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">{booking.id}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{booking.customer}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{booking.companyName || "-"}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{booking.vehicle}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{booking.service}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {booking.date} {formatBookingTime(booking.time)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{booking.technician}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2.5 py-1 inline-flex text-xs font-semibold leading-5 rounded-full ${statusColors[booking.status] || "bg-gray-100"}`}>
                        {booking.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <div className="flex space-x-2">
                        <button
                          onClick={() => openViewModal(booking)}
                          className="rounded-lg p-2 text-gray-500 transition-colors hover:bg-blue-50 hover:text-blue-700"
                          title="View Details"
                          aria-label="View booking details"
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                        {canUpdate && ["Pending", "Confirmed"].includes(booking.status) ? <button
                          onClick={() => openEditModal(booking)}
                          className="rounded-lg p-2 text-gray-500 transition-colors hover:bg-green-50 hover:text-green-700"
                          title="Edit Booking"
                          aria-label="Edit booking"
                        >
                          <Edit className="h-4 w-4" />
                        </button> : null}
                        {canUpdate && booking.status === "Pending" && (
                          <button
                            onClick={() => handleUpdateStatus(booking, "Confirmed")}
                            className="rounded-lg p-2 text-gray-500 transition-colors hover:bg-green-50 hover:text-green-700"
                            title="Confirm Booking"
                            aria-label="Confirm booking"
                          >
                            <CheckCircle className="h-4 w-4" />
                          </button>
                        )}
                        {canUpdate && booking.status === "Confirmed" && (
                          <button
                            onClick={() => openCheckInModal(booking)}
                            className="rounded-lg p-2 text-gray-500 transition-colors hover:bg-indigo-50 hover:text-indigo-700"
                            title="Check In / Create Work Order"
                            aria-label="Check in and create work order"
                          >
                            <ClipboardPlus className="h-4 w-4" />
                          </button>
                        )}
                        {canUpdate && ["Pending", "Confirmed"].includes(booking.status) && (
                          <button
                            onClick={() => handleUpdateStatus(booking, "Cancelled")}
                            className="rounded-lg p-2 text-gray-500 transition-colors hover:bg-red-50 hover:text-red-700"
                            title="Cancel Booking"
                            aria-label="Cancel booking"
                          >
                            <XCircle className="h-4 w-4" />
                          </button>
                        )}
                        {canDelete && ["Pending", "Cancelled"].includes(booking.status) ? <button
                          onClick={() => handleDeleteBooking(booking)}
                          className="rounded-lg p-2 text-gray-500 transition-colors hover:bg-red-50 hover:text-red-700"
                          title="Delete Booking"
                          aria-label="Delete booking"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button> : null}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Dialog */}
      {modalMode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-3 backdrop-blur-sm transition-opacity sm:p-5">
          <div className={`flex max-h-[94vh] w-full flex-col overflow-hidden rounded-2xl border border-white/70 bg-white shadow-2xl animate-in fade-in zoom-in-95 duration-150 ${modalMode === "view" ? "max-w-lg" : "max-w-4xl"}`}>
            {/* Header */}
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 bg-white px-5 py-4 sm:px-7 sm:py-5">
              <div className="flex min-w-0 items-start gap-3.5">
                {modalMode !== "view" ? (
                  <div className="mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-[#1e3a8a] ring-1 ring-blue-100">
                    <CalendarPlus2 className="h-5 w-5" />
                  </div>
                ) : null}
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="text-lg font-bold tracking-tight text-slate-900 sm:text-xl">
                      {modalMode === "create" ? "New Service Booking" : modalMode === "edit" ? "Edit Service Booking" : "Service Booking Details"}
                    </h2>
                    {modalMode !== "view" ? (
                      <span className="hidden rounded-full bg-blue-50 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-blue-700 sm:inline-flex">
                        {modalMode === "create" ? "New" : form.id || "Editing"}
                      </span>
                    ) : null}
                  </div>
                  <p className="mt-1 text-xs leading-5 text-slate-500 sm:text-sm">
                    {modalMode === "view" ? "View detailed service booking information." : "Set the customer, appointment and service request in four quick sections."}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setModalMode(null)}
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
                aria-label="Close booking dialog"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {modalMode === "view" && selectedBooking && (
              <>
                <div className="flex-1 overflow-y-auto p-6 space-y-4 text-sm">
                  <div className="grid grid-cols-2 gap-4 pb-2 border-b border-gray-100">
                    <div>
                      <p className="text-xs text-gray-500 font-medium">BOOKING ID</p>
                      <p className="text-sm font-semibold text-gray-900 mt-0.5">{selectedBooking.id}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 font-medium">STATUS</p>
                      <span className={`px-2.5 py-0.5 inline-flex text-xs font-semibold leading-5 rounded-full mt-1 ${statusColors[selectedBooking.status] || "bg-gray-100"}`}>
                        {selectedBooking.status}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 pb-2 border-b border-gray-100">
                    <div>
                      <p className="text-xs text-gray-500 font-medium">COMPANY USER</p>
                      <p className="text-sm text-gray-900 mt-0.5">{selectedBooking.customer}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 font-medium">COMPANY</p>
                      <p className="text-sm text-gray-900 mt-0.5">{selectedBooking.companyName || "-"}</p>
                    </div>
                  </div>

                  <div className="pb-2 border-b border-gray-100">
                    <p className="text-xs text-gray-500 font-medium">VEHICLE</p>
                    <p className="text-sm text-gray-900 mt-0.5 font-medium">{selectedBooking.vehicle}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4 pb-2 border-b border-gray-100">
                    <div>
                      <p className="text-xs text-gray-500 font-medium">SERVICE TYPE</p>
                      <p className="text-sm text-gray-900 mt-0.5">{selectedBooking.service}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 font-medium">SERVICE CENTRE</p>
                      <p className="text-sm text-gray-900 mt-0.5">{selectedBooking.location}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 pb-2 border-b border-gray-100">
                    <div>
                      <p className="text-xs text-gray-500 font-medium">DATE</p>
                      <p className="text-sm text-gray-900 mt-0.5">{selectedBooking.date}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 font-medium">TIME</p>
                      <p className="text-sm text-gray-900 mt-0.5">{formatBookingTime(selectedBooking.time)}</p>
                    </div>
                  </div>

                  <div className="pb-2 border-b border-gray-100">
                    <p className="text-xs text-gray-500 font-medium">ASSIGNED FOREMAN</p>
                    <p className="text-sm text-gray-900 mt-0.5">{selectedBooking.technician || "-"}</p>
                  </div>

                  <div>
                    <p className="text-xs text-gray-500 font-medium">REPORTED PROBLEM</p>
                    <p className="text-sm text-gray-700 mt-1 bg-gray-50 p-2.5 rounded-lg border border-gray-100">{selectedBooking.reportedProblem || "No reported problem."}</p>
                  </div>

                  <div>
                    <p className="text-xs text-gray-500 font-medium">DRIVER REMARKS & NOTES</p>
                    <p className="text-sm text-gray-700 mt-1 bg-gray-50 p-2.5 rounded-lg border border-gray-100">{selectedBooking.customerNotes || "No driver notes."}</p>
                  </div>

                  <div>
                    <p className="text-xs text-gray-500 font-medium">FOREMAN REMARKS & NOTES</p>
                    <p className="text-sm text-gray-700 mt-1 bg-gray-50 p-2.5 rounded-lg border border-gray-100">{selectedBooking.technicianNotes || "No foreman notes recorded."}</p>
                  </div>
                </div>

                <div className="flex items-center justify-end px-6 py-4 bg-gray-50 border-t border-gray-200 space-x-3">
                  <button
                    type="button"
                    onClick={() => setModalMode(null)}
                    className="px-4 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-100 bg-white transition-colors"
                  >
                    Close
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {checkInTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-3 backdrop-blur-sm sm:p-5">
          <div className="flex max-h-[94vh] w-full max-w-2xl flex-col overflow-hidden rounded-2xl border border-white/70 bg-white shadow-2xl">
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 bg-white px-5 py-4 sm:px-7 sm:py-5">
              <div className="flex items-start gap-3.5"><div className="mt-0.5 flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-[#1e3a8a] ring-1 ring-blue-100"><ClipboardPlus className="h-5 w-5" /></div><div>
                <h2 className="text-lg font-bold tracking-tight text-slate-900 sm:text-xl">Check In &amp; Create Work Order</h2>
                <p className="mt-1 text-xs leading-5 text-slate-500 sm:text-sm">{checkInTarget.id} · {checkInTarget.vehicle}</p>
              </div></div>
              <button
                type="button"
                disabled={isCheckingIn}
                onClick={() => setCheckInTarget(null)}
                className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700 disabled:opacity-50"
                aria-label="Close check-in dialog"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 space-y-4 overflow-y-auto bg-slate-50/80 p-4 sm:p-6">
              <div className="rounded-lg border border-blue-200 bg-blue-50 p-3 text-sm text-blue-900">
                This will record the vehicle check-in time, create a linked work order, and move the booking to In Progress.
              </div>

              <div className="rounded-lg border border-gray-200 bg-gray-50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wider text-gray-500">Booked Appointment</p>
                <div className="mt-2 grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-gray-500">Service Date</p>
                    <p className="mt-0.5 text-sm font-semibold text-gray-900">{checkInTarget.date || "-"}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Service Time</p>
                    <p className="mt-0.5 text-sm font-semibold text-gray-900">{formatBookingTime(checkInTarget.time)}</p>
                  </div>
                </div>
                <p className="mt-2 text-xs text-gray-500">Actual check-in time is recorded when you confirm.</p>
              </div>

              <section className="space-y-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">Priority</label>
                  <AdminSelect
                    value={checkInForm.priority}
                    onChange={(event) => setCheckInForm({ ...checkInForm, priority: event.target.value })}
                    className="w-full"
                  >
                    {["Low", "Normal", "High", "Urgent"].map((priority) => (
                      <option key={priority} value={priority}>{priority}</option>
                    ))}
                  </AdminSelect>
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">Workshop Bay</label>
                  <AdminSelect
                    value={checkInForm.bay}
                    onChange={(event) => setCheckInForm({ ...checkInForm, bay: event.target.value })}
                    className="w-full"
                  >
                    <option value="">Unassigned</option>
                    {["Bay 1", "Bay 2", "Bay 3", "Bay 4", "Engine Bay", "Trailer Bay"].map((bay) => (
                      <option key={bay} value={bay}>{bay}</option>
                    ))}
                  </AdminSelect>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">Check-in Mileage (km)</label>
                  <input
                    type="number"
                    min="0"
                    placeholder="e.g. 125000"
                    value={checkInForm.checkinMileage}
                    onChange={(event) => setCheckInForm({ ...checkInForm, checkinMileage: event.target.value })}
                    className="w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2 text-sm text-gray-900 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">Expected Completion Date</label>
                  <DesktopDatePicker
                    value={checkInForm.estimatedOut}
                    onChange={(estimatedOut) => setCheckInForm({ ...checkInForm, estimatedOut })}
                    ariaLabel="Choose expected completion date"
                    className="w-full"
                  />
                </div>
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">Foreman</label>
                <div className="max-h-40 space-y-1 overflow-y-auto rounded-lg border border-gray-200 bg-gray-50 p-2">
                  {workOrderStaff.length === 0 ? (
                    <p className="px-2 py-3 text-center text-xs text-gray-500">No active foreman. You can assign one later in Work Orders.</p>
                  ) : workOrderStaff.map((member) => (
                    <label key={member.id} className="flex cursor-pointer items-center justify-between rounded-md bg-white px-3 py-2 text-sm hover:bg-blue-50">
                      <span>
                        <span className="font-medium text-gray-900">{member.name}</span>
                        <span className="ml-2 text-xs text-gray-500">{member.role}</span>
                      </span>
                      <input
                        type="radio"
                        name="checkin_technician"
                        checked={checkInForm.technicianIds.includes(member.id)}
                        onChange={() => setCheckInForm({
                          ...checkInForm,
                          technicianIds: [member.id],
                        })}
                        className="h-4 w-4 border-gray-300 text-blue-700 focus:ring-blue-500"
                      />
                    </label>
                  ))}
                </div>
              </div>
              </section>
            </div>

            <div className="flex flex-col-reverse gap-3 border-t border-slate-200 bg-white px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between sm:px-7">
              <p className="text-xs text-slate-500">Actual check-in time is recorded on confirmation</p><div className="flex items-center justify-end gap-2.5">
              <button
                type="button"
                disabled={isCheckingIn}
                onClick={() => setCheckInTarget(null)}
                className="h-10 rounded-lg border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isCheckingIn}
                onClick={handleCheckIn}
                className="inline-flex h-10 items-center gap-2 rounded-lg bg-[#1e3a8a] px-5 text-sm font-semibold text-white shadow-sm hover:bg-blue-800 disabled:opacity-50"
              >
                <ClipboardPlus className="h-4 w-4" />{isCheckingIn ? "Checking In..." : "Confirm Check In"}
              </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
