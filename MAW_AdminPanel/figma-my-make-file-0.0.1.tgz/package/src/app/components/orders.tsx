import { useState, useMemo } from "react";
import { Search, Eye, X, PackageCheck, ShoppingBag, Clock3, Truck, CheckCircle2, Edit, Printer, FileText, CheckSquare, Square, RefreshCw, Check, Download } from "lucide-react";
import { useApiData } from "../lib/use-api-data";
import { useLanguage } from "../contexts/language-context";
import { toast } from "sonner";
import { AdminSelect } from "./ui/admin-select";
import { postApi } from "../lib/api";
import { hasAdminPermission } from "../lib/admin-permissions";
import { PartsOrderInvoiceDialog, type PartsOrderData } from "./parts-order-invoice-dialog";
import { exportTableToExcel, ExcelColumnDef } from "../lib/excel-export";

interface OrderItem {
  name: string;
  quantity: number;
  price: number;
}

interface Order {
  id: string;
  customer: string;
  items: OrderItem[];
  total: number;
  status: "Pending" | "Processing" | "Shipped" | "Delivered";
  orderDate: string;
  deliveryAddress: string;
  autocountDoNo?: string;
  autocountSyncStatus?: string;
  autocountSyncAt?: string | null;
}

const statusColors: Record<string, string> = {
  Pending: "border-amber-200 bg-amber-50 text-amber-700",
  Processing: "border-blue-200 bg-blue-50 text-blue-700",
  Shipped: "border-purple-200 bg-purple-50 text-purple-700",
  Delivered: "border-emerald-200 bg-emerald-50 text-emerald-700",
};

export function Orders() {
  const canUpdate = hasAdminPermission("order.update");
  const { t } = useLanguage();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("All");
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [printingOrder, setPrintingOrder] = useState<Order | null>(null);
  const [statusModalOrder, setStatusModalOrder] = useState<Order | null>(null);
  const [updatingOrderId, setUpdatingOrderId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [isBatchSyncing, setIsBatchSyncing] = useState(false);

  // API Integration
  const {
    data: orders,
    isLoading,
    error,
    reload,
  } = useApiData<Order[]>("admin-orders", []);

  const filteredOrders = useMemo(() => {
    return orders.filter((order) => {
      const matchesSearch =
        order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.customer.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus =
        selectedStatus === "All" || order.status === selectedStatus;
      return matchesSearch && matchesStatus;
    });
  }, [orders, searchTerm, selectedStatus]);

  const stats = [
    {
      label: "Total Orders",
      value: orders.length,
      icon: ShoppingBag,
      color: "text-gray-900",
      iconColor: "text-blue-600",
    },
    {
      label: "Pending",
      value: orders.filter((o) => o.status === "Pending").length,
      icon: Clock3,
      color: "text-amber-600",
      iconColor: "text-amber-600",
    },
    {
      label: "Processing / Shipped",
      value: orders.filter((o) => o.status === "Processing" || o.status === "Shipped").length,
      icon: Truck,
      color: "text-blue-600",
      iconColor: "text-blue-600",
    },
    {
      label: "Delivered",
      value: orders.filter((o) => o.status === "Delivered").length,
      icon: CheckCircle2,
      color: "text-emerald-600",
      iconColor: "text-emerald-600",
    },
  ];

  // Update order status
  const handleUpdateStatus = async (orderId: string, newStatus: string) => {
    setUpdatingOrderId(orderId);
    try {
      await postApi("admin-update-order-status", {
        id: orderId,
        status: newStatus,
      });
      await reload();
      if (selectedOrder && selectedOrder.id === orderId) {
        setSelectedOrder({
          ...selectedOrder,
          status: newStatus as Order["status"],
        });
      }
      toast.success(`Order ${orderId} updated to ${newStatus}`);
    } catch (err) {
      toast.error(
        err instanceof Error ? err.message : "Failed to update order status",
      );
    } finally {
      setUpdatingOrderId(null);
    }
  };

  const toggleSelect = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSelectedIds(next);
  };

  const syncableOrders = useMemo(() => {
    return filteredOrders.filter((o) => !o.autocountDoNo || o.autocountSyncStatus !== "synced");
  }, [filteredOrders]);

  const isAllSelected =
    syncableOrders.length > 0 &&
    syncableOrders.every((o) => selectedIds.has(o.id));

  const toggleSelectAll = () => {
    if (isAllSelected) {
      setSelectedIds(new Set());
    } else {
      const next = new Set(selectedIds);
      syncableOrders.forEach((o) => next.add(o.id));
      setSelectedIds(next);
    }
  };

  const handleBatchSync = async () => {
    if (selectedIds.size === 0) return;
    setIsBatchSyncing(true);
    try {
      const idsArray = Array.from(selectedIds);
      await postApi("admin-batch-sync-parts-orders", { orderIds: idsArray });
      toast.success(`${idsArray.length} parts order(s) queued for AutoCount DO sync.`);
      setSelectedIds(new Set());
      await reload();
    } catch (caught) {
      toast.error(caught instanceof Error ? caught.message : "Failed to batch queue parts orders.");
    } finally {
      setIsBatchSyncing(false);
    }
  };

  if (printingOrder) {
    return (
      <PartsOrderInvoiceDialog
        order={printingOrder}
        onClose={() => setPrintingOrder(null)}
        onChanged={reload}
      />
    );
  }

  const handleExportOrders = async () => {
    if (filteredOrders.length === 0) {
      toast.error("No parts orders available to export.");
      return;
    }

    const columnDefs: ExcelColumnDef[] = [
      { header: "Order ID", key: "id", align: "left", minWidth: 16, numFmt: "@" },
      { header: "Order Date", key: "orderDate", align: "center", minWidth: 14 },
      { header: "Customer", key: "customer", align: "left", minWidth: 24 },
      { header: "Items Detail", key: "itemsDetail", align: "left", minWidth: 36 },
      { header: "Total Qty", key: "totalQty", align: "right", minWidth: 12, numFmt: "#,##0" },
      { header: "Delivery Address", key: "deliveryAddress", align: "left", minWidth: 30 },
      { header: "AutoCount DO No", key: "autocountDoNo", align: "left", minWidth: 18, numFmt: "@" },
      { header: "Total Amount (RM)", key: "total", align: "right", minWidth: 18, numFmt: "#,##0.00" },
      { header: "Delivery Status", key: "status", align: "center", minWidth: 15 },
      { header: "AutoCount Sync", key: "syncStatus", align: "center", minWidth: 16 },
    ];

    const rows = filteredOrders.map((ord) => {
      const itemsDetail = (ord.items || []).map((i) => `${i.name} (x${i.quantity})`).join(", ");
      const totalQty = (ord.items || []).reduce((sum, i) => sum + Number(i.quantity || 0), 0);

      return {
        id: String(ord.id),
        orderDate: String(ord.orderDate || "-").slice(0, 10),
        customer: String(ord.customer || "-"),
        itemsDetail: itemsDetail || "-",
        totalQty,
        deliveryAddress: String(ord.deliveryAddress || "-"),
        autocountDoNo: String(ord.autocountDoNo || "-"),
        total: Number(ord.total || 0),
        status: String(ord.status || "-").toUpperCase(),
        syncStatus: String(ord.autocountSyncStatus || "-").toUpperCase(),
      };
    });

    const fileName = `maw-parts-orders-${new Date().toISOString().slice(0, 10)}.xlsx`;
    await exportTableToExcel({
      fileName,
      sheetName: "Parts Orders",
      columns: columnDefs,
      data: rows,
      successMessage: `Exported ${filteredOrders.length} orders to ${fileName}`,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            {t("order_management")}
          </h1>
          <p className="mt-1 text-xs text-gray-500">
            Manage customer spare parts orders and track delivery status
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportOrders}
            disabled={isLoading || filteredOrders.length === 0}
            className="inline-flex h-10 items-center justify-center rounded-xl border border-gray-300 bg-white px-4 text-sm font-semibold text-gray-700 shadow-sm transition-colors hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Download className="mr-2 h-4 w-4" />
            Export Excel
          </button>
        </div>
      </div>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          Parts orders are unavailable: {error}.
        </div>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div
              key={index}
              className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm"
            >
              <Icon className={`h-5 w-5 ${stat.iconColor}`} />
              <p className="mt-3 text-xs font-semibold uppercase tracking-wide text-gray-500">
                {stat.label}
              </p>
              <p className={`mt-1 text-2xl font-bold ${stat.color}`}>
                {stat.value.toLocaleString()}
              </p>
            </div>
          );
        })}
      </div>

      {/* Standard Filters */}
      <div className="maw-filter-bar">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
          <div className="md:col-span-2">
            <div className="maw-search-field">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search order ID, customer name or delivery address..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-sm"
              />
            </div>
          </div>
          <div>
            <AdminSelect
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full"
              aria-label="Filter parts order status"
            >
              <option value="All">{t("all_orders")}</option>
              <option value="Pending">{t("pending")}</option>
              <option value="Processing">{t("processing")}</option>
              <option value="Shipped">{t("shipped")}</option>
              <option value="Delivered">{t("delivered")}</option>
            </AdminSelect>
          </div>
        </div>
      </div>

      {/* Orders Table */}
      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="w-10 px-4 py-3 text-left">
                  <button
                    type="button"
                    onClick={toggleSelectAll}
                    className="text-slate-400 hover:text-slate-700 cursor-pointer"
                    title={isAllSelected ? "Deselect all" : "Select all syncable"}
                  >
                    {isAllSelected ? (
                      <CheckSquare className="h-4 w-4 text-blue-600" />
                    ) : (
                      <Square className="h-4 w-4" />
                    )}
                  </button>
                </th>
                <th scope="col" className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Order
                </th>
                <th scope="col" className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Customer & Delivery
                </th>
                <th scope="col" className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Items
                </th>
                <th scope="col" className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Order Date
                </th>
                <th scope="col" className="px-5 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Total
                </th>
                <th scope="col" className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Status
                </th>
                <th scope="col" className="px-5 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-500">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 bg-white">
              {isLoading ? (
                <tr>
                  <td
                    colSpan={8}
                    className="px-5 py-12 text-center text-sm text-gray-500"
                  >
                    Loading parts orders...
                  </td>
                </tr>
              ) : filteredOrders.length === 0 ? (
                <tr>
                  <td
                    colSpan={8}
                    className="px-5 py-12 text-center text-sm text-gray-500"
                  >
                    No orders match the current filters.
                  </td>
                </tr>
              ) : (
                filteredOrders.map((order) => {
                  const itemQuantity = order.items.reduce(
                    (total, item) => total + item.quantity,
                    0,
                  );
                  const isSelected = selectedIds.has(order.id);
                  const isSynced = Boolean(order.autocountDoNo && order.autocountSyncStatus === "synced");
                  return (
                    <tr key={order.id} className={`transition-colors hover:bg-gray-50 ${isSelected ? "bg-blue-50/40" : ""}`}>
                      <td className="px-4 py-4">
                        <button
                          type="button"
                          onClick={() => toggleSelect(order.id)}
                          className="text-slate-400 hover:text-slate-700 cursor-pointer"
                        >
                          {isSelected ? (
                            <CheckSquare className="h-4 w-4 text-blue-600" />
                          ) : (
                            <Square className="h-4 w-4" />
                          )}
                        </button>
                      </td>
                      <td className="px-5 py-4">
                        <p className="font-mono text-sm font-bold text-blue-700">
                          {order.id}
                        </p>
                        {order.autocountDoNo ? (
                          <span className="mt-1 inline-flex items-center rounded-md border border-emerald-200/60 bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-700">
                            AutoCount DO: {order.autocountDoNo}
                          </span>
                        ) : order.autocountSyncStatus === "pending" || order.autocountSyncStatus === "processing" ? (
                          <span className="mt-1 inline-flex items-center rounded-md border border-amber-200/60 bg-amber-50 px-2 py-0.5 text-[10px] font-bold text-amber-700">
                            AutoCount DO: Syncing...
                          </span>
                        ) : (
                          <p className="mt-1 text-xs text-gray-400">
                            Parts order
                          </p>
                        )}
                      </td>
                      <td className="px-5 py-4">
                        <p className="text-sm font-semibold text-gray-900">
                          {order.customer}
                        </p>
                        <p
                          className="mt-1 max-w-[280px] truncate text-xs text-gray-500"
                          title={order.deliveryAddress}
                        >
                          {order.deliveryAddress || "No delivery address"}
                        </p>
                      </td>
                      <td className="px-5 py-4">
                        <span className="rounded-full bg-indigo-50 px-2.5 py-1 text-xs font-bold text-indigo-700">
                          {itemQuantity} units
                        </span>
                        <p className="mt-1 text-xs text-gray-500">
                          {order.items.length} line items
                        </p>
                      </td>
                      <td className="whitespace-nowrap px-5 py-4 text-sm text-gray-600">
                        {order.orderDate || "-"}
                      </td>
                      <td className="whitespace-nowrap px-5 py-4 text-right text-sm font-bold text-gray-900">
                        RM {order.total.toFixed(2)}
                      </td>
                      <td className="whitespace-nowrap px-5 py-4">
                        {canUpdate ? (
                          <button
                            type="button"
                            onClick={() => setStatusModalOrder(order)}
                            className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-all hover:scale-105 hover:ring-2 hover:ring-blue-400/40 cursor-pointer ${
                              statusColors[order.status] || "border-slate-200 bg-slate-50 text-slate-600"
                            }`}
                            title="Click to update status"
                          >
                            <span className="h-1.5 w-1.5 rounded-full bg-current" />
                            {order.status}
                            <Edit className="h-3 w-3 opacity-60 ml-0.5" />
                          </button>
                        ) : (
                          <span
                            className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold ${
                              statusColors[order.status] || "border-slate-200 bg-slate-50 text-slate-600"
                            }`}
                          >
                            <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                            {order.status}
                          </span>
                        )}
                      </td>
                      <td className="whitespace-nowrap px-5 py-4 text-right">
                        <div className="flex items-center justify-end space-x-1.5">
                          <button
                            type="button"
                            onClick={() => setPrintingOrder(order)}
                            className="rounded-lg p-2 text-slate-500 transition-colors hover:bg-blue-50 hover:text-blue-700 cursor-pointer"
                            title="View & Print Tax Invoice / DO"
                            aria-label={`Print ${order.id}`}
                          >
                            <Printer className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setSelectedOrder(order)}
                            className="rounded-lg p-2 text-gray-500 transition-colors hover:bg-blue-50 hover:text-blue-700 cursor-pointer"
                            title="View Order Details"
                            aria-label={`View ${order.id}`}
                          >
                            <Eye className="h-4 w-4" />
                          </button>
                          {canUpdate ? (
                            <button
                              type="button"
                              onClick={() => setStatusModalOrder(order)}
                              className="rounded-lg p-2 text-gray-500 transition-colors hover:bg-blue-50 hover:text-blue-700"
                              title="Update Fulfilment Status"
                              aria-label={`Update status for ${order.id}`}
                            >
                              <Edit className="h-4 w-4" />
                            </button>
                          ) : null}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
        <div className="border-t border-gray-200 bg-gray-50/70 px-5 py-3 text-xs text-gray-500">
          {filteredOrders.length.toLocaleString()} matching orders
        </div>
      </div>

      {/* Floating Batch Actions Bar */}
      {selectedIds.size > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 flex items-center gap-4 rounded-2xl border border-slate-700 bg-slate-900 px-6 py-3.5 text-white shadow-2xl animate-in fade-in slide-in-from-bottom-4">
          <div className="flex items-center gap-2">
            <CheckSquare className="h-5 w-5 text-blue-400" />
            <span className="text-sm font-bold">
              {selectedIds.size} Order(s) Selected
            </span>
          </div>
          <div className="h-4 w-px bg-slate-700" />
          <button
            type="button"
            onClick={() => setSelectedIds(new Set())}
            className="text-xs font-semibold text-slate-300 hover:text-white cursor-pointer"
          >
            Clear Selection
          </button>
          <button
            type="button"
            disabled={isBatchSyncing}
            onClick={() => void handleBatchSync()}
            className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white shadow-md hover:bg-blue-500 disabled:opacity-50 cursor-pointer"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${isBatchSyncing ? "animate-spin" : ""}`} />
            <span>{isBatchSyncing ? "Queueing..." : "Batch Sync to AutoCount"}</span>
          </button>
        </div>
      )}

      {/* Order Detail Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-3 backdrop-blur-sm transition-opacity sm:p-5">
          <div className="flex max-h-[94vh] w-full max-w-2xl flex-col overflow-hidden rounded-2xl border border-white/70 bg-white shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 bg-white px-5 py-4 sm:px-7 sm:py-5">
              <div className="flex items-start gap-3.5">
                <div className="mt-0.5 flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-[#1e3a8a] ring-1 ring-blue-100">
                  <PackageCheck className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="text-lg font-bold tracking-tight text-slate-900 sm:text-xl">
                    Order Details
                  </h2>
                  <p className="mt-1 text-xs leading-5 text-slate-500 sm:text-sm">
                    {selectedOrder.id} · Review order items and update fulfilment status.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedOrder(null)}
                className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                aria-label="Close order dialog"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto bg-slate-50/80 p-4 sm:p-6 space-y-4">
              <div className="space-y-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
                      {t("order_id")}
                    </p>
                    <p className="font-mono font-bold text-gray-900 mt-1">
                      {selectedOrder.id}
                    </p>
                    {selectedOrder.autocountDoNo ? (
                      <p className="mt-1 text-xs font-bold text-emerald-700">
                        AutoCount DO: {selectedOrder.autocountDoNo}
                      </p>
                    ) : selectedOrder.autocountSyncStatus === "pending" || selectedOrder.autocountSyncStatus === "processing" ? (
                      <p className="mt-1 text-xs font-bold text-amber-700">
                        AutoCount DO: Syncing to ERP...
                      </p>
                    ) : null}
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
                      {t("status")}
                    </p>
                    <div className="mt-1">
                      <span
                        className={`inline-flex items-center px-2.5 py-0.5 text-xs font-semibold rounded-full border ${
                          statusColors[selectedOrder.status] || "border-slate-200 bg-slate-50 text-slate-700"
                        }`}
                      >
                        <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                        {selectedOrder.status}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="border-t border-gray-100 pt-4">
                  <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">
                    {t("customer")}
                  </h3>
                  <p className="text-sm font-semibold text-gray-900">
                    {selectedOrder.customer}
                  </p>
                </div>

                <div className="border-t border-gray-100 pt-4">
                  <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">
                    {t("items")}
                  </h3>
                  <div className="space-y-2 rounded-xl border border-gray-100 bg-gray-50/70 p-3">
                    {selectedOrder.items.map((item, index) => (
                      <div key={index} className="flex justify-between items-center text-sm">
                        <span className="text-gray-700">
                          {item.name}{" "}
                          <span className="font-bold text-gray-400">
                            x{item.quantity}
                          </span>
                        </span>
                        <span className="font-bold text-gray-900">
                          RM {(item.price * item.quantity).toFixed(2)}
                        </span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-3 pt-3 border-t border-gray-100 flex justify-between font-bold text-sm text-gray-900">
                    <span>{t("total_amount")}:</span>
                    <span className="text-base text-blue-900">RM {selectedOrder.total.toFixed(2)}</span>
                  </div>
                </div>

                <div className="border-t border-gray-100 pt-4 text-sm">
                  <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">
                    Delivery Address
                  </h3>
                  <p className="text-sm text-gray-700">
                    {selectedOrder.deliveryAddress || "No address specified"}
                  </p>
                </div>

                <div className="border-t border-gray-100 pt-4 text-sm">
                  <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">
                    {t("order_date")}
                  </h3>
                  <p className="text-sm text-gray-700">{selectedOrder.orderDate || "-"}</p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between border-t border-slate-200 bg-white px-4 py-3.5 sm:px-7">
              <button
                type="button"
                onClick={() => setPrintingOrder(selectedOrder)}
                className="inline-flex items-center gap-2 rounded-xl bg-blue-50 px-4 py-2.5 text-xs font-bold text-[#1e3a8a] hover:bg-blue-100 transition-colors cursor-pointer"
              >
                <Printer className="h-4 w-4" />
                View & Print Tax Invoice / DO
              </button>
              <button
                type="button"
                onClick={() => setSelectedOrder(null)}
                className="h-10 rounded-lg border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}



      {/* Quick Status Update Modal */}
      {statusModalOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-3 backdrop-blur-sm transition-opacity sm:p-5">
          <div className="flex w-full max-w-md flex-col overflow-hidden rounded-2xl border border-white/70 bg-white shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 bg-white px-5 py-4 sm:px-6 sm:py-5">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 text-blue-700 ring-1 ring-blue-100">
                  <PackageCheck className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-slate-900 sm:text-lg">
                    Update Fulfilment Status
                  </h2>
                  <p className="text-xs font-mono text-slate-500">
                    {statusModalOrder.id} · {statusModalOrder.customer}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setStatusModalOrder(null)}
                className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                aria-label="Close dialog"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2">
                  Order Fulfilment Workflow (Strict Sequential)
                </label>
                
                {/* Visual Step Timeline */}
                <div className="space-y-3">
                  {([
                    { key: "Pending", step: 1, label: "1. Order Placed", desc: "Customer submitted parts order from App.", color: "amber" },
                    { key: "Processing", step: 2, label: "2. Prepare & Generate DO", desc: "Picking parts & enqueuing AutoCount DO sync.", color: "blue" },
                    { key: "Shipped", step: 3, label: "3. Dispatched / Ready for Pickup", desc: "Parts ready at workshop counter or out for delivery.", color: "purple" },
                    { key: "Delivered", step: 4, label: "4. Delivered & Completed", desc: "Customer received parts. Order fulfilled and closed.", color: "emerald" },
                  ] as const).map((stepItem, idx) => {
                    const currentIdx = (["Pending", "Processing", "Shipped", "Delivered"] as const).indexOf(statusModalOrder.status);
                    const isPassed = idx < currentIdx;
                    const isCurrent = idx === currentIdx;
                    const isNext = idx === currentIdx + 1;
                    const isLocked = idx > currentIdx + 1;
                    const isUpdating = updatingOrderId === statusModalOrder.id;

                    return (
                      <div
                        key={stepItem.key}
                        className={`relative rounded-xl border p-3.5 transition-all ${
                          isCurrent
                            ? "border-blue-500 bg-blue-50/70 ring-2 ring-blue-500/20 shadow-sm"
                            : isPassed
                            ? "border-emerald-200 bg-emerald-50/40 text-emerald-950"
                            : isNext
                            ? "border-slate-300 bg-white hover:border-blue-400 hover:bg-blue-50/30"
                            : "border-slate-100 bg-slate-50 opacity-60"
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-start gap-3">
                            <div
                              className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
                                isPassed
                                  ? "bg-emerald-600 text-white"
                                  : isCurrent
                                  ? "bg-blue-600 text-white ring-4 ring-blue-100"
                                  : isNext
                                  ? "border-2 border-blue-600 bg-white text-blue-600"
                                  : "border-2 border-slate-300 bg-white text-slate-400"
                              }`}
                            >
                              {isPassed ? "✓" : stepItem.step}
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <h4 className={`text-xs font-bold ${isCurrent ? "text-blue-900" : isPassed ? "text-emerald-900" : isNext ? "text-slate-800" : "text-slate-500"}`}>
                                  {stepItem.label}
                                </h4>
                                {isCurrent && (
                                  <span className="rounded-full bg-blue-100 px-2 py-0.5 text-[9px] font-extrabold text-blue-700 uppercase">
                                    Current
                                  </span>
                                )}
                                {isPassed && (
                                  <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[9px] font-extrabold text-emerald-700">
                                    Done
                                  </span>
                                )}
                              </div>
                              <p className="mt-0.5 text-[11px] text-slate-500">
                                {stepItem.desc}
                              </p>
                            </div>
                          </div>

                          {/* Action Button */}
                          {isNext ? (
                            <button
                              type="button"
                              disabled={isUpdating}
                              onClick={async () => {
                                await handleUpdateStatus(statusModalOrder.id, stepItem.key);
                                setStatusModalOrder(null);
                              }}
                              className="inline-flex shrink-0 items-center gap-1 rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-bold text-white shadow-sm transition-all hover:bg-blue-700 hover:scale-105 active:scale-95 disabled:opacity-50 cursor-pointer"
                            >
                              Advance &rarr;
                            </button>
                          ) : isLocked ? (
                            <span className="shrink-0 text-[10px] font-semibold text-slate-400 flex items-center gap-1">
                              <span>🔒</span> Next step required
                            </span>
                          ) : null}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {statusModalOrder.autocountDoNo ? (
                <div className="rounded-xl border border-emerald-200/60 bg-emerald-50/80 p-3 text-xs text-emerald-800 flex items-center justify-between">
                  <div>
                    <span className="font-bold">AutoCount DO:</span> {statusModalOrder.autocountDoNo}
                  </div>
                  <span className="text-[10px] font-bold text-emerald-600">Synced</span>
                </div>
              ) : statusModalOrder.status === "Pending" ? (
                <div className="rounded-xl border border-blue-100 bg-blue-50/60 p-3 text-[11px] text-blue-800">
                  💡 Advancing to <strong>Processing</strong> will automatically enqueue and generate the <strong>AutoCount Delivery Order (DO)</strong>.
                </div>
              ) : null}
            </div>

            <div className="flex justify-end gap-2 border-t border-slate-100 bg-slate-50/60 px-5 py-3.5">
              <button
                type="button"
                onClick={() => setStatusModalOrder(null)}
                className="rounded-lg border border-gray-200 bg-white px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 shadow-sm cursor-pointer"
              >
                {t("close")}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
