import { useEffect, useRef, useState, useMemo } from "react";
import { useSearchParams } from "react-router";
import { Search, Plus, Eye, Edit, Trash2, Phone, Mail, X, UserRound, KeyRound, Save, Download } from "lucide-react";
import { useLanguage } from "../contexts/language-context";
import { postApi } from "../lib/api";
import { EMAIL_PLACEHOLDER, isValidEmail, normalizeEmail } from "../lib/email";
import {
  formatMalaysiaPhone,
  formatMalaysiaPhoneInput,
  isValidMalaysiaPhone,
  MALAYSIA_PHONE_PLACEHOLDER,
  normalizeMalaysiaPhone,
} from "../lib/malaysia-phone";
import {
  PASSWORD_MAX_LENGTH,
  PASSWORD_MIN_LENGTH,
  passwordValidationMessage,
} from "../lib/password";
import { useApiData } from "../lib/use-api-data";
import { toast } from "sonner";
import { useConfirmationDialog } from "../contexts/confirmation-dialog-context";
import { AdminSelect } from "./ui/admin-select";
import { hasAdminPermission } from "../lib/admin-permissions";
import { adminFieldClass, adminLabelClass } from "./ui/admin-form-dialog";
import { exportTableToExcel, ExcelColumnDef } from "../lib/excel-export";

type Customer = {
  id: number;
  name: string;
  email: string;
  phone: string;
  vehicles: number;
  totalBookings: number;
  lastVisit: string;
  status: string;
  companyId?: number;
  companyName?: string;
};

type CustomerForm = {
  name: string;
  email: string;
  phone: string;
  password: string;
  companyId: number;
};

const emptyCustomerForm: CustomerForm = {
  name: "",
  email: "",
  phone: "",
  password: "",
  companyId: 0,
};

const mockCustomers: Customer[] = [];

export function Customers() {
  const [searchParams, setSearchParams] = useSearchParams();
  const companyFilter = Number(searchParams.get("companyId") || 0);
  const userDetailId = Number(searchParams.get("userId") || 0);
  const editUserId = Number(searchParams.get("editUserId") || 0);
  const canCreate = hasAdminPermission("customer.create");
  const canUpdate = hasAdminPermission("customer.update");
  const canDelete = hasAdminPermission("customer.delete");
  const { t } = useLanguage();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("All");
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [modalMode, setModalMode] = useState<"view" | "create" | "edit" | null>(null);
  const [form, setForm] = useState<CustomerForm>(emptyCustomerForm);
  const [isSaving, setIsSaving] = useState(false);
  const [formError, setFormError] = useState("");
  const handledUserDetailId = useRef(0);
  const handledEditUserId = useRef(0);
  const { data: customersData, isLoading, error, reload, hasLoaded } = useApiData<Customer[]>("admin-customers", []);
  const { data: companiesData } = useApiData<{ id: number; name: string }[]>("admin-companies", []);
  const confirmAction = useConfirmationDialog();

  const customers = useMemo(() => {
    if (isLoading && !hasLoaded) {
      return [];
    }
    if (error && customersData.length === 0) {
      return mockCustomers;
    }
    return customersData;
  }, [customersData, isLoading, hasLoaded, error]);

  const openCreateModal = () => {
    setSelectedCustomer(null);
    setForm({
      ...emptyCustomerForm,
      companyId: companiesData[0]?.id ?? 0,
    });
    setFormError("");
    setModalMode("create");
  };

  const openEditModal = (customer: Customer) => {
    setSelectedCustomer(customer);
    setForm({
      name: customer.name,
      email: customer.email,
      phone: formatMalaysiaPhone(customer.phone),
      password: "",
      companyId: customer.companyId ?? 0,
    });
    setFormError("");
    setModalMode("edit");
  };

  const openViewModal = (customer: Customer) => {
    setSelectedCustomer(customer);
    setFormError("");
    setModalMode("view");
  };

  const closeModal = () => {
    if (searchParams.has("userId")) {
      const nextParams = new URLSearchParams(searchParams);
      nextParams.delete("userId");
      setSearchParams(nextParams, { replace: true });
    }
    setSelectedCustomer(null);
    setForm(emptyCustomerForm);
    setFormError("");
    setModalMode(null);
  };

  useEffect(() => {
    if (!userDetailId) {
      handledUserDetailId.current = 0;
      return;
    }
    if (isLoading || handledUserDetailId.current === userDetailId) return;
    const requestedUser = customers.find((customer) => customer.id === userDetailId);
    if (!requestedUser) return;
    handledUserDetailId.current = userDetailId;
    const nextParams = new URLSearchParams(searchParams);
    nextParams.delete("userId");
    setSearchParams(nextParams, { replace: true });
    setSelectedCustomer(requestedUser);
    setFormError("");
    setModalMode("view");
  }, [customers, userDetailId, isLoading, searchParams, setSearchParams]);

  useEffect(() => {
    if (!editUserId || !canUpdate) {
      handledEditUserId.current = 0;
      return;
    }
    if (isLoading || handledEditUserId.current === editUserId) return;
    const requestedUser = customers.find((customer) => customer.id === editUserId);
    if (!requestedUser) return;
    handledEditUserId.current = editUserId;
    const nextParams = new URLSearchParams(searchParams);
    nextParams.delete("editUserId");
    setSearchParams(nextParams, { replace: true });
    openEditModal(requestedUser);
  }, [canUpdate, customers, editUserId, isLoading, searchParams, setSearchParams]);

  const handleSubmitCustomer = async () => {
    setFormError("");

    if (!form.name.trim() || !form.email.trim() || !form.phone.trim()) {
      setFormError("Name, email, and phone are required.");
      return;
    }

    if (!form.companyId) {
      setFormError("Select a company.");
      return;
    }

    if (!isValidEmail(form.email)) {
      setFormError("Enter a valid email address, for example name@example.com.");
      return;
    }

    if (!isValidMalaysiaPhone(form.phone)) {
      setFormError("Enter a valid Malaysia mobile or landline number.");
      return;
    }

    if (modalMode === "create" && !form.password.trim()) {
      setFormError("Password is required for new company users.");
      return;
    }

    if (form.password) {
      const passwordError = passwordValidationMessage(
        form.password,
        modalMode === "edit" ? "New password" : "Password",
      );
      if (passwordError) {
        setFormError(passwordError);
        return;
      }
    }

    setIsSaving(true);
    try {
      await postApi(modalMode === "create" ? "admin-create-customer" : "admin-update-customer", {
        id: selectedCustomer?.id,
        name: form.name.trim(),
        email: normalizeEmail(form.email),
        phone: normalizeMalaysiaPhone(form.phone)!,
        password: form.password,
        companyId: form.companyId,
      });
      await reload();
      closeModal();
    } catch (apiError) {
      setFormError(apiError instanceof Error ? apiError.message : "Unable to save company user.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteCustomer = async (customer: Customer) => {
    const confirmed = await confirmAction({
      title: `Delete company user "${customer.name}"?`,
      description: "The company must retain at least one app user. This action cannot be undone.",
      confirmLabel: "Delete company user",
      tone: "danger",
    });
    if (!confirmed) {
      return;
    }

    try {
      await postApi("admin-delete-customer", { id: customer.id });
      await reload();
      toast.success(`Company user "${customer.name}" deleted.`);
    } catch (apiError) {
      toast.error(apiError instanceof Error ? apiError.message : "Unable to delete company user.");
    }
  };

  const filteredCustomers = customers.filter((customer) => {
    const matchesSearch =
      customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.phone.includes(searchTerm);
    const matchesStatus = selectedStatus === "All" || customer.status === selectedStatus;
    const matchesCompany = companyFilter === 0 || Number(customer.companyId) === companyFilter;
    return matchesSearch && matchesStatus && matchesCompany;
  });
  const filteredCompanyName = companiesData.find((company) => Number(company.id) === companyFilter)?.name;

  const clearCompanyFilter = () => {
    const nextParams = new URLSearchParams(searchParams);
    nextParams.delete("companyId");
    setSearchParams(nextParams);
  };

  const handleExportCustomers = async () => {
    if (filteredCustomers.length === 0) {
      toast.error("No company users available to export.");
      return;
    }

    const columnDefs: ExcelColumnDef[] = [
      { header: "User / Contact Name", key: "name", align: "left", minWidth: 24 },
      { header: "Company", key: "companyName", align: "left", minWidth: 26 },
      { header: "Phone Number", key: "phone", align: "left", minWidth: 18, numFmt: "@" },
      { header: "Email Address", key: "email", align: "left", minWidth: 26 },
      { header: "Fleet Vehicles Count", key: "vehicles", align: "right", minWidth: 16, numFmt: "#,##0" },
      { header: "Total Bookings", key: "totalBookings", align: "right", minWidth: 14, numFmt: "#,##0" },
      { header: "Last Visit", key: "lastVisit", align: "center", minWidth: 14 },
      { header: "Status", key: "status", align: "center", minWidth: 14 },
    ];

    const rows = filteredCustomers.map((cust) => ({
      name: String(cust.name || "-"),
      companyName: String(cust.companyName || "-"),
      phone: String(cust.phone || "-"),
      email: String(cust.email || "-"),
      vehicles: Number(cust.vehicles || 0),
      totalBookings: Number(cust.totalBookings || 0),
      lastVisit: cust.lastVisit ? String(cust.lastVisit).slice(0, 10) : "-",
      status: String(cust.status || "Active").toUpperCase(),
    }));

    const fileName = `maw-customers-${new Date().toISOString().slice(0, 10)}.xlsx`;
    await exportTableToExcel({
      fileName,
      sheetName: "Company Users",
      columns: columnDefs,
      data: rows,
      successMessage: `Exported ${filteredCustomers.length} users to ${fileName}`,
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl text-gray-900">{t('customer_management')}</h1>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCustomers}
            disabled={isLoading || filteredCustomers.length === 0}
            className="inline-flex h-10 items-center justify-center rounded-xl border border-gray-300 bg-white px-4 text-sm font-semibold text-gray-700 shadow-sm transition-colors hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Download className="mr-2 h-4 w-4" />
            Export Excel
          </button>
          {canCreate ? <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex h-10 items-center justify-center rounded-xl bg-[#1e3a8a] px-4 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-blue-800"
          >
            <Plus className="h-4 w-4 mr-2" />
            {t('add_customer')}
          </button> : null}
        </div>
      </div>

      {error && (
        <div className="rounded-lg border border-yellow-200 bg-yellow-50 px-4 py-3 text-sm text-yellow-800">
          Database data unavailable: {error}. Showing fallback data.
        </div>
      )}

      {companyFilter ? (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-900">
          <span>
            Showing users for <strong>{filteredCompanyName || `Company #${companyFilter}`}</strong>
          </span>
          <button type="button" onClick={clearCompanyFilter} className="font-semibold text-[#1e3a8a] hover:text-blue-700">
            Clear company filter
          </button>
        </div>
      ) : null}



      {/* Summary */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
          <div className="text-xs font-semibold uppercase tracking-wide text-gray-500">{t('total_customers')}</div>
          <div className="mt-3 text-2xl font-bold text-gray-900">{filteredCustomers.length}</div>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
          <div className="text-xs font-semibold uppercase tracking-wide text-gray-500">{t('active_customers')}</div>
          <div className="mt-3 text-2xl font-bold text-gray-900">{filteredCustomers.filter((c) => c.status === "Active").length}</div>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
          <div className="text-xs font-semibold uppercase tracking-wide text-gray-500">{t('avg_bookings')}</div>
          <div className="mt-3 text-2xl font-bold text-gray-900">{(filteredCustomers.reduce((sum, c) => sum + c.totalBookings, 0) / Math.max(filteredCustomers.length, 1)).toFixed(1)}</div>
        </div>
      </div>

      {/* Filters */}
      <div className="maw-filter-bar">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
          <div className="md:col-span-2">
            <div className="maw-search-field">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder={t('search_customers')}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
              />
            </div>
          </div>
          <div>
            <AdminSelect
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full"
              aria-label="Filter company user status"
            >
              <option value="All">{t('all')}</option>
              <option value="Active">{t('active')}</option>
              <option value="Inactive">{t('inactive')}</option>
            </AdminSelect>
          </div>
        </div>
      </div>

      {/* Customers Table */}
      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">
                  {t('customer')}
                </th>
                <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">
                  {t('contact')}
                </th>
                <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">
                  {t('company')}
                </th>
                <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">
                  {t('vehicles')}
                </th>
                <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">
                  {t('bookings')}
                </th>
                <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">
                  {t('last_visit')}
                </th>
                <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">
                  {t('status')}
                </th>
                <th className="px-6 py-3 text-right text-xs text-gray-500 uppercase tracking-wider">
                  {t('actions')}
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {!isLoading && filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-center text-sm text-gray-500">
                    No company users found matching these criteria.
                  </td>
                </tr>
              ) : null}
              {filteredCustomers.map((customer) => (
                <tr key={customer.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-10 w-10 rounded-full bg-[#1e3a8a] flex items-center justify-center text-white">
                        {customer.name.charAt(0)}
                      </div>
                      <div className="ml-4">
                        <div className="text-sm text-gray-900">{customer.name}</div>
                        <div className="text-sm text-gray-500">ID: {customer.id}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex flex-col space-y-1">
                      <div className="flex items-center text-sm text-gray-900">
                        <Mail className="h-4 w-4 mr-1 text-gray-400" />
                        {customer.email}
                      </div>
                      <div className="flex items-center text-sm text-gray-500">
                        <Phone className="h-4 w-4 mr-1 text-gray-400" />
                        {formatMalaysiaPhone(customer.phone)}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {customer.companyName || "-"}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {customer.vehicles}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {customer.totalBookings}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {customer.lastVisit}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold ${
                        customer.status === "Active"
                          ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                          : "border-slate-200 bg-slate-50 text-slate-600"
                      }`}
                    >
                      <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                      {t(customer.status.toLowerCase())}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm">
                    <div className="flex items-center justify-end space-x-2">
                      <button
                        type="button"
                        onClick={() => openViewModal(customer)}
                        className="rounded-lg p-2 text-gray-500 transition-colors hover:bg-blue-50 hover:text-blue-700"
                        aria-label="View company user"
                        title="View company user"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      {canUpdate ? <button
                        type="button"
                        onClick={() => openEditModal(customer)}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-gray-200 px-2.5 py-2 text-xs font-semibold text-gray-700 transition-colors hover:border-blue-200 hover:bg-blue-50 hover:text-blue-700"
                        aria-label="Edit company user"
                        title="Edit company user"
                      >
                        <Edit className="h-4 w-4" />
                        Edit
                      </button> : null}
                      {canDelete ? <button
                        type="button"
                        onClick={() => handleDeleteCustomer(customer)}
                        className="rounded-lg p-2 text-gray-500 transition-colors hover:bg-red-50 hover:text-red-700"
                        aria-label="Delete company user"
                        title="Delete company user"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button> : null}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {modalMode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-3 backdrop-blur-sm transition-opacity sm:p-5">
          <div className={`flex max-h-[94vh] w-full flex-col overflow-hidden rounded-2xl border border-white/70 bg-white shadow-2xl animate-in fade-in zoom-in-95 duration-150 ${modalMode === "view" ? "max-w-lg" : "max-w-2xl"}`}>
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 bg-white px-5 py-4 sm:px-7 sm:py-5">
              <div className="flex min-w-0 items-start gap-3.5">
                {modalMode !== "view" ? <div className="mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-[#1e3a8a] ring-1 ring-blue-100"><UserRound className="h-5 w-5" /></div> : null}
                <div>
                <h2 className="text-lg font-bold tracking-tight text-slate-900 sm:text-xl">
                  {modalMode === "create"
                    ? "New Company User"
                    : modalMode === "edit"
                    ? "Edit Company User"
                    : "Company User Details"}
                </h2>
                <p className="mt-1 text-xs leading-5 text-slate-500 sm:text-sm">
                  {modalMode === "view"
                    ? "View company user contact and activity summary."
                    : "Manage Customer App login and contact details."}
                </p>
                </div>
              </div>
              <button
                type="button"
                onClick={closeModal}
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700"
                aria-label="Close"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {modalMode === "view" && selectedCustomer ? (
              <div className="flex-1 space-y-4 overflow-y-auto p-6">
                <div className="flex items-center">
                  <div className="h-12 w-12 rounded-full bg-[#1e3a8a] flex items-center justify-center text-white font-semibold">
                    {selectedCustomer.name.charAt(0)}
                  </div>
                  <div className="ml-4">
                    <div className="text-base font-semibold text-gray-900">{selectedCustomer.name}</div>
                    <div className="text-sm text-gray-500">ID: {selectedCustomer.id}</div>
                  </div>
                </div>
                <div className="grid grid-cols-1 gap-3 text-sm">
                  <div className="flex justify-between border-t border-gray-100 pt-3">
                    <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Email</span>
                    <span className="text-sm text-gray-900 font-medium">{selectedCustomer.email}</span>
                  </div>
                  <div className="flex justify-between border-t border-gray-100 pt-3">
                    <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Phone</span>
                    <span className="text-sm text-gray-900 font-medium">{formatMalaysiaPhone(selectedCustomer.phone)}</span>
                  </div>
                  <div className="flex justify-between border-t border-gray-100 pt-3">
                    <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Company</span>
                    <span className="text-sm text-gray-900 font-medium">{selectedCustomer.companyName || "-"}</span>
                  </div>
                  <div className="flex justify-between border-t border-gray-100 pt-3">
                    <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Vehicles</span>
                    <span className="text-sm text-gray-900 font-medium">{selectedCustomer.vehicles}</span>
                  </div>
                  <div className="flex justify-between border-t border-gray-100 pt-3">
                    <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Bookings</span>
                    <span className="text-sm text-gray-900 font-medium">{selectedCustomer.totalBookings}</span>
                  </div>
                  <div className="flex justify-between border-t border-gray-100 pt-3">
                    <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Last Visit</span>
                    <span className="text-sm text-gray-900 font-medium">{selectedCustomer.lastVisit}</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex-1 space-y-4 overflow-y-auto bg-slate-50/80 p-4 sm:p-6">
                {formError && <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm font-medium text-red-600">{formError}</div>}
                <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
                  <div className="flex items-start gap-3 rounded-t-xl border-b border-slate-100 bg-white px-4 py-3.5 sm:px-5"><div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-blue-50 text-blue-700"><UserRound className="h-4 w-4" /></div><div><h3 className="text-sm font-bold text-slate-900">1. Profile &amp; company</h3><p className="mt-0.5 text-xs text-slate-500">Enter the Customer App user's identity and company relationship.</p></div></div>
                  <div className="grid gap-4 p-4 sm:p-5 md:grid-cols-2">
                <div>
                  <label className={adminLabelClass}>Name <span className="text-red-500">*</span></label>
                  <input
                    value={form.name}
                    onChange={(event) => setForm({ ...form, name: event.target.value })}
                    className={adminFieldClass}
                    placeholder="e.g. John Doe"
                  />
                </div>
                <div>
                  <label className={adminLabelClass}>Email <span className="text-red-500">*</span></label>
                  <input
                    type="email"
                    inputMode="email"
                    autoComplete="email"
                    autoCapitalize="none"
                    spellCheck={false}
                    value={form.email}
                    onChange={(event) => {
                      setForm({ ...form, email: event.target.value });
                      setFormError("");
                    }}
                    onBlur={() => setForm({ ...form, email: normalizeEmail(form.email) })}
                    className={adminFieldClass}
                    placeholder={EMAIL_PLACEHOLDER}
                    maxLength={254}
                  />
                </div>
                <div>
                  <label className={adminLabelClass}>Phone <span className="text-red-500">*</span></label>
                  <input
                    type="tel"
                    inputMode="tel"
                    autoComplete="tel"
                    value={form.phone}
                    onChange={(event) => setForm({ ...form, phone: formatMalaysiaPhoneInput(event.target.value) })}
                    placeholder={MALAYSIA_PHONE_PLACEHOLDER}
                    maxLength={18}
                    className={adminFieldClass}
                  />
                  <p className="mt-1 text-xs text-gray-500">Mobile: +60 12-345 6789 · Landline: +60 3-1234 5678</p>
                </div>
                <div>
                  <label className={adminLabelClass}>Company</label>
                  <AdminSelect
                    value={form.companyId}
                    onChange={(event) => setForm({ ...form, companyId: Number(event.target.value) })}
                    className="w-full"
                  >
                    <option value="">{t('select_company')}</option>
                    {companiesData.map((comp) => (
                      <option key={comp.id} value={comp.id}>
                        {comp.name}
                      </option>
                    ))}
                  </AdminSelect>
                </div>
                  </div>
                </section>
                <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
                  <div className="flex items-start gap-3 rounded-t-xl border-b border-slate-100 bg-white px-4 py-3.5 sm:px-5"><div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-indigo-50 text-indigo-700"><KeyRound className="h-4 w-4" /></div><div><h3 className="text-sm font-bold text-slate-900">2. App credentials</h3><p className="mt-0.5 text-xs text-slate-500">Set the password used to sign in to the Customer App.</p></div></div>
                  <div className="p-4 sm:p-5"><label className={adminLabelClass}>{modalMode === "create" ? <>Password <span className="text-red-500">*</span></> : "New password"}</label><input type="password" autoComplete="new-password" value={form.password} onChange={(event) => { setForm({ ...form, password: event.target.value }); setFormError(""); }} placeholder={modalMode === "edit" ? "Leave blank to keep current password" : "At least 8 characters"} minLength={PASSWORD_MIN_LENGTH} maxLength={PASSWORD_MAX_LENGTH} pattern="[!-~]{8,128}" className={adminFieldClass} /><p className="mt-1.5 text-xs text-slate-500">8–128 characters without spaces.{modalMode === "edit" ? " Leave blank to keep the current password." : ""}</p></div>
                </section>
              </div>
            )}

            <div className="flex flex-col-reverse gap-3 border-t border-slate-200 bg-white px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between sm:px-7">
              <p className="text-xs text-slate-500">{modalMode !== "view" ? <><span className="font-bold text-red-500">*</span> Required fields must be completed</> : null}</p>
              <div className="flex items-center justify-end gap-2.5">
              {modalMode === "view" && selectedCustomer && canUpdate ? (
                <button
                  type="button"
                  onClick={() => openEditModal(selectedCustomer)}
                  className="inline-flex items-center rounded-lg bg-[#1e3a8a] px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-blue-800"
                >
                  <Edit className="mr-2 h-4 w-4" />
                  Edit User
                </button>
              ) : null}
              <button
                type="button"
                onClick={closeModal}
                className="h-10 rounded-lg border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-700 transition-colors hover:bg-slate-50"
              >
                {modalMode === "view" ? t('close') : t('cancel')}
              </button>
              {modalMode !== "view" && (
                <button
                  type="button"
                  onClick={handleSubmitCustomer}
                  disabled={isSaving}
                  className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-[#1e3a8a] px-5 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-blue-800 disabled:opacity-50"
                >
                  <Save className="h-4 w-4" />{isSaving ? "Saving..." : modalMode === "create" ? "Create User" : "Save Changes"}
                </button>
              )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
