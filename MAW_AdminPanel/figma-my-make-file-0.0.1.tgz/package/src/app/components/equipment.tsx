import { useEffect, useRef, useState, useMemo } from "react";
import { useSearchParams } from "react-router";
import { Search, Plus, Eye, Edit, Trash2, Truck, X, Save, Database, Lock, Download } from "lucide-react";
import { useLanguage } from "../contexts/language-context";
import { useApiData } from "../lib/use-api-data";
import { postApi } from "../lib/api";
import { toast } from "sonner";
import { useConfirmationDialog } from "../contexts/confirmation-dialog-context";
import { DesktopDatePicker } from "./ui/desktop-date-picker";
import { AdminCombobox } from "./ui/admin-combobox";
import { AdminSelect } from "./ui/admin-select";
import { hasAdminPermission } from "../lib/admin-permissions";
import { AutoCountSyncBadge } from "./autocount-sync-badge";
import { exportTableToExcel, ExcelColumnDef } from "../lib/excel-export";

interface Vehicle {
  id: number;
  vecNo: string;
  regNo: string;
  equipment: string;
  brand: string;
  model: string;
  year: number;
  mileage: string;
  owner: string;
  ownerId?: number;
  companyId?: number;
  companyName?: string;
  driverId?: number;
  driverName?: string;
  chassisNo?: string;
  engineNo?: string;
  containerLength?: string;
  axleConfiguration?: string;
  insurance: string;
  roadTax: string;
  puspakom: string;
  lastServiceDate?: string;
  lastServiceMileage?: number;
  nextServiceDate?: string;
  nextServiceMileage?: number;
  status: string;
  vehicleStatus?: VehicleStatus;
  verificationStatus?: "pending" | "approved" | "rejected";
  rejectionReason?: string;
  reviewedBy?: number;
  reviewedAt?: string;
  createdSource?: string;
  autocountProjectNo?: string;
  autocountSyncAt?: string;
}

type VehicleStatus = "Active" | "Inactive" | "Under Maintenance" | "Out of Service" | "Disposed";

interface VehicleForm {
  vecNo: string;
  regNo: string;
  equipment: string;
  brand: string;
  model: string;
  year: string;
  mileage: string;
  companyId: number;
  driverId: number;
  chassisNo: string;
  engineNo: string;
  containerLength: string;
  axleConfiguration: string;
  insurance: string;
  roadTax: string;
  puspakom: string;
  lastServiceDate: string;
  lastServiceMileage: string;
  nextServiceDate: string;
  nextServiceMileage: string;
  vehicleStatus: VehicleStatus;
  autocountProjectNo: string;
}

const mockEquipment: Vehicle[] = [];

const emptyVehicleForm: VehicleForm = {
  vecNo: "",
  regNo: "",
  equipment: "Prime Mover",
  brand: "",
  model: "",
  year: "",
  mileage: "",
  companyId: 0,
  driverId: 0,
  chassisNo: "",
  engineNo: "",
  containerLength: "",
  axleConfiguration: "",
  insurance: "",
  roadTax: "",
  puspakom: "",
  lastServiceDate: "",
  lastServiceMileage: "",
  nextServiceDate: "",
  nextServiceMileage: "",
  vehicleStatus: "Active",
  autocountProjectNo: "",
};

const vehicleStatuses: VehicleStatus[] = [
  "Active",
  "Inactive",
  "Under Maintenance",
  "Out of Service",
  "Disposed",
];

const fleetEquipmentTypes = [
  "Prime Mover",
  "Container Chassis / Skeletal Trailer",
  "Side Loader / Sidelifter",
  "Other",
];

const containerLengths = ["20 ft", "40 ft", "45 ft", "20/40 ft Extendable", "Other"];
const axleConfigurations = ["2 Axle", "3 Axle", "Other"];

const primeMoverBrandModels: Record<string, string[]> = {
  "Volvo Trucks": ["FH", "FH16", "FM", "FMX"],
  Scania: ["P-series", "G-series", "G450", "R-series", "R450", "S-series"],
  MAN: ["TGM", "TGS", "TGX"],
  "Mercedes-Benz Trucks": ["Atego", "Actros", "Arocs"],
  "UD Trucks": ["Kuzer", "Croner", "Quester"],
  Hino: ["300 Series", "500 Series", "700 Series"],
  Isuzu: ["N-Series", "F-Series", "GIGA"],
  FUSO: ["Canter", "Fighter", "Super Great"],
  "Sinotruk / HOWO": [],
  Shacman: [],
  "Foton / Auman": [],
  Dongfeng: [],
  JAC: [],
  Other: [],
};

const sideLoaderBrands = ["Hammar", "Steelbro", "Swinglift", "Combilift", "Other"];
const commonBrands = [...Object.keys(primeMoverBrandModels), ...sideLoaderBrands];

const normalizeText = (value: string) => value.trim().replace(/\s+/g, " ");
const normalizedBrandAliases: Record<string, string> = {
  "nissan ud": "UD Trucks",
  "ud truck": "UD Trucks",
  "mitsubishi fuso": "FUSO",
  fuso: "FUSO",
  "volvo": "Volvo Trucks",
  "mercedes-benz": "Mercedes-Benz Trucks",
  "mercedes benz": "Mercedes-Benz Trucks",
  "sinotruk/howo": "Sinotruk / HOWO",
  "sinotruk / howo": "Sinotruk / HOWO",
  howo: "Sinotruk / HOWO",
  foton: "Foton / Auman",
  auman: "Foton / Auman",
  "foton auman": "Foton / Auman",
};

const normalizeBrandName = (value: string) => {
  const normalizedValue = normalizeText(value);
  const key = normalizedValue.toLocaleLowerCase();
  const alias = normalizedBrandAliases[key];
  if (alias) {
    return alias;
  }

  return commonBrands.find((brand) => brand.toLocaleLowerCase() === key) || normalizedValue;
};

const uniqueCaseInsensitive = (values: string[]) => {
  const uniqueValues = new Map<string, string>();

  values.forEach((value) => {
    const normalizedValue = normalizeText(value);
    if (normalizedValue) {
      const key = normalizedValue.toLocaleLowerCase();
      if (!uniqueValues.has(key)) {
        uniqueValues.set(key, normalizedValue);
      }
    }
  });

  return [...uniqueValues.values()];
};

const canonicalizeSuggestion = (value: string, suggestions: string[]) => {
  const normalizedValue = normalizeText(value);
  return suggestions.find(
    (suggestion) => suggestion.toLocaleLowerCase() === normalizedValue.toLocaleLowerCase()
  ) || normalizedValue;
};

const canonicalizeBrand = (value: string, suggestions: string[]) => {
  const normalizedValue = normalizeBrandName(value);
  return suggestions.find(
    (suggestion) => suggestion.toLocaleLowerCase() === normalizedValue.toLocaleLowerCase()
  ) || normalizedValue;
};

const missingEquipmentValues = new Set(["", "-", "n/a", "na", "unknown", "not specified"]);

const isMissingEquipmentValue = (equipment?: string) =>
  missingEquipmentValues.has(normalizeText(equipment || "").toLocaleLowerCase());

const normalizeEquipmentProfile = (equipment: string, existingContainerLength = "") => {
  const normalizedEquipment = normalizeText(equipment);
  const key = normalizedEquipment.toLocaleLowerCase();
  const chassisMappings: Record<string, string> = {
    "20 ft trailer": "20 ft",
    "20 ft container chassis": "20 ft",
    "40 ft trailer": "40 ft",
    "40's trailer": "40 ft",
    "40 ft container chassis": "40 ft",
    "45 ft container chassis": "45 ft",
    "20/40 ft extendable container chassis": "20/40 ft Extendable",
  };

  if (chassisMappings[key]) {
    return {
      equipment: "Container Chassis / Skeletal Trailer",
      containerLength: existingContainerLength || chassisMappings[key],
    };
  }
  if (key === "sidelifter" || key === "side loader" || key === "side loader / sidelifter") {
    return { equipment: "Side Loader / Sidelifter", containerLength: existingContainerLength };
  }

  return {
    equipment: isMissingEquipmentValue(normalizedEquipment) ? "" : normalizedEquipment,
    containerLength: existingContainerLength,
  };
};

export function Equipment() {
  const [searchParams, setSearchParams] = useSearchParams();
  const companyFilter = Number(searchParams.get("companyId") || 0);
  const vehicleDetailId = Number(searchParams.get("vehicleId") || 0);
  const canUpdate = hasAdminPermission("vehicle.update");
  const canReview = hasAdminPermission("vehicle.review");
  const canManageVehicles = canUpdate;
  const { t } = useLanguage();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBrand, setSelectedBrand] = useState("All");
  const [verificationFilter, setVerificationFilter] = useState("All");

  // Modals state
  const [selectedEquipment, setSelectedEquipment] = useState<Vehicle | null>(null);
  const [modalMode, setModalMode] = useState<"view" | "create" | "edit" | null>(null);
  const [form, setForm] = useState<VehicleForm>(emptyVehicleForm);
  const [isSaving, setIsSaving] = useState(false);
  const [formError, setFormError] = useState("");
  const [reviewReason, setReviewReason] = useState("");
  const [isReviewing, setIsReviewing] = useState(false);
  const handledVehicleDetailId = useRef(0);
  const isPrimeMover = form.equipment === "Prime Mover";
  const isContainerChassis = form.equipment === "Container Chassis / Skeletal Trailer";
  const isSideLoader = form.equipment === "Side Loader / Sidelifter";
  const showMileage = !isContainerChassis;
  const showEngineNumber = isPrimeMover;
  const showAssignedDriver = !isContainerChassis;

  const { data: equipmentData, isLoading, error, reload, hasLoaded } = useApiData<Vehicle[]>("admin-vehicles", []);
  const { data: driversData } = useApiData<any[]>("admin-drivers", [], canManageVehicles);
  const { data: companiesData } = useApiData<any[]>("admin-companies", [], canManageVehicles);
  const confirmAction = useConfirmationDialog();

  const equipment = useMemo(() => {
    if (isLoading && !hasLoaded) {
      return [];
    }
    if (error && equipmentData.length === 0) {
      return mockEquipment;
    }
    return equipmentData;
  }, [equipmentData, isLoading, hasLoaded, error]);

  const filteredEquipment = equipment.filter((item) => {
    const matchesSearch =
      item.vecNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.regNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.owner.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesBrand =
      selectedBrand === "All" ||
      normalizeBrandName(item.brand).toLocaleLowerCase() === selectedBrand.toLocaleLowerCase();
    const matchesVerification =
      verificationFilter === "All" ||
      (item.verificationStatus || "approved") === verificationFilter.toLowerCase();
    const matchesCompany = companyFilter === 0 || Number(item.companyId) === companyFilter;
    return matchesSearch && matchesBrand && matchesVerification && matchesCompany;
  });
  const filteredCompanyName = companiesData.find((company) => Number(company.id) === companyFilter)?.name;

  const clearCompanyFilter = () => {
    const nextParams = new URLSearchParams(searchParams);
    nextParams.delete("companyId");
    setSearchParams(nextParams);
  };

  const equipmentBrands = useMemo(
    () => uniqueCaseInsensitive(equipment.map((item) => normalizeBrandName(item.brand))),
    [equipment]
  );
  const brandSuggestions = useMemo(() => {
    const savedBrandsForType = equipment
      .filter((item) => normalizeEquipmentProfile(item.equipment).equipment === form.equipment)
      .map((item) => normalizeBrandName(item.brand));

    if (isPrimeMover) {
      return uniqueCaseInsensitive([...Object.keys(primeMoverBrandModels), ...savedBrandsForType]);
    }
    if (isContainerChassis) {
      return uniqueCaseInsensitive([...savedBrandsForType, "Other"]);
    }
    if (isSideLoader) {
      return uniqueCaseInsensitive([...sideLoaderBrands, ...savedBrandsForType]);
    }
    return uniqueCaseInsensitive([...commonBrands, ...equipmentBrands]);
  }, [equipment, equipmentBrands, form.equipment, isContainerChassis, isPrimeMover, isSideLoader]);
  const brands = ["All", ...equipmentBrands];
  const modelSuggestions = useMemo(() => {
    const selectedBrand = canonicalizeBrand(form.brand, brandSuggestions);
    const standardBrand = Object.keys(primeMoverBrandModels).find(
      (brand) => brand.toLocaleLowerCase() === selectedBrand.toLocaleLowerCase()
    );
    const savedModels = equipment
      .filter((item) => {
        const sameEquipment = normalizeEquipmentProfile(item.equipment).equipment === form.equipment;
        const sameBrand = !selectedBrand
          || normalizeBrandName(item.brand).toLocaleLowerCase() === selectedBrand.toLocaleLowerCase();
        return sameEquipment && sameBrand;
      })
      .map((item) => item.model);

    if (isContainerChassis) {
      return uniqueCaseInsensitive(["3-Axle Skeletal Chassis", "Extendable Chassis", ...savedModels]);
    }

    return uniqueCaseInsensitive([
      ...(isPrimeMover && standardBrand ? primeMoverBrandModels[standardBrand] : []),
      ...savedModels,
    ]);
  }, [brandSuggestions, equipment, form.brand, form.equipment, isContainerChassis, isPrimeMover]);

  const openCreateModal = () => {
    setSelectedEquipment(null);
    setForm(emptyVehicleForm);
    setFormError("");
    setReviewReason("");
    setModalMode("create");
  };

  const openEditModal = (vehicle: Vehicle) => {
    setSelectedEquipment(vehicle);
    const cleanDate = (d?: string) => {
      if (!d || d === "-" || d === "0000-00-00") return "";
      return d;
    };
    const equipmentProfile = normalizeEquipmentProfile(vehicle.equipment, vehicle.containerLength);
    setForm({
      vecNo: vehicle.vecNo || "",
      regNo: vehicle.regNo || "",
      equipment: equipmentProfile.equipment,
      brand: vehicle.brand || "",
      model: vehicle.model || "",
      year: vehicle.year ? String(vehicle.year) : "",
      mileage: String(vehicle.mileage || "").replace(/\D/g, ""),
      companyId: vehicle.companyId || vehicle.ownerId || 0,
      driverId: vehicle.driverId || 0,
      chassisNo: (vehicle.chassisNo || "").toUpperCase(),
      engineNo: (vehicle.engineNo || "").toUpperCase(),
      containerLength: equipmentProfile.containerLength,
      axleConfiguration: vehicle.axleConfiguration || "",
      insurance: cleanDate(vehicle.insurance),
      roadTax: cleanDate(vehicle.roadTax),
      puspakom: cleanDate(vehicle.puspakom),
      lastServiceDate: cleanDate(vehicle.lastServiceDate),
      lastServiceMileage: vehicle.lastServiceMileage ? String(vehicle.lastServiceMileage) : "",
      nextServiceDate: cleanDate(vehicle.nextServiceDate),
      nextServiceMileage: vehicle.nextServiceMileage ? String(vehicle.nextServiceMileage) : "",
      vehicleStatus: vehicleStatuses.includes(vehicle.vehicleStatus as VehicleStatus)
        ? (vehicle.vehicleStatus as VehicleStatus)
        : "Active",
      autocountProjectNo: vehicle.autocountProjectNo || "",
    });
    setFormError("");
    setReviewReason(vehicle.rejectionReason || "");
    setModalMode("edit");
  };

  const openViewModal = (vehicle: Vehicle) => {
    setSelectedEquipment(vehicle);
    setReviewReason(vehicle.rejectionReason || "");
    setModalMode("view");
  };

  const closeModal = () => {
    if (searchParams.has("vehicleId")) {
      const nextParams = new URLSearchParams(searchParams);
      nextParams.delete("vehicleId");
      setSearchParams(nextParams, { replace: true });
    }
    setModalMode(null);
    setSelectedEquipment(null);
  };

  useEffect(() => {
    if (!vehicleDetailId) {
      handledVehicleDetailId.current = 0;
      return;
    }
    if (isLoading || handledVehicleDetailId.current === vehicleDetailId) return;
    const requestedVehicle = equipment.find((vehicle) => vehicle.id === vehicleDetailId);
    if (!requestedVehicle) return;
    handledVehicleDetailId.current = vehicleDetailId;
    const nextParams = new URLSearchParams(searchParams);
    nextParams.delete("vehicleId");
    setSearchParams(nextParams, { replace: true });
    setSelectedEquipment(requestedVehicle);
    setReviewReason(requestedVehicle.rejectionReason || "");
    setModalMode("view");
  }, [equipment, isLoading, searchParams, setSearchParams, vehicleDetailId]);

  const handleSubmitEquipment = async (approveAfterSave = false) => {
    setFormError("");
    const normalizedBrand = canonicalizeBrand(form.brand, brandSuggestions);
    const normalizedModel = canonicalizeSuggestion(form.model, modelSuggestions);

    if (!form.regNo.trim()) {
      setFormError("Registration number is required.");
      return;
    }
    if (!form.equipment.trim()) {
      setFormError("Equipment type is required.");
      return;
    }
    if (!fleetEquipmentTypes.includes(form.equipment)) {
      setFormError("Please select a supported equipment type.");
      return;
    }
    if (isPrimeMover && !normalizedBrand) {
      setFormError("Prime Mover brand is required.");
      return;
    }
    if (isPrimeMover && !normalizedModel) {
      setFormError("Prime Mover model is required.");
      return;
    }
    if (isContainerChassis && !form.containerLength) {
      setFormError("Container length is required for a container chassis.");
      return;
    }
    if (isContainerChassis && !form.axleConfiguration) {
      setFormError("Axle configuration is required for a container chassis.");
      return;
    }
    if (form.companyId === 0) {
      setFormError("Please select a company.");
      return;
    }
    if (!vehicleStatuses.includes(form.vehicleStatus)) {
      setFormError("Please select a valid vehicle status.");
      return;
    }
    const currentYear = new Date().getFullYear();
    if (form.year && (!/^\d{4}$/.test(form.year) || Number(form.year) < 1900 || Number(form.year) > currentYear + 1)) {
      setFormError(`Manufacture year must be between 1900 and ${currentYear + 1}.`);
      return;
    }
    if (form.mileage && !/^\d+$/.test(form.mileage)) {
      setFormError("Current mileage must be a non-negative whole number.");
      return;
    }
    if (form.lastServiceMileage && !/^\d+$/.test(form.lastServiceMileage)) {
      setFormError("Last service mileage must be a non-negative whole number.");
      return;
    }
    if (form.nextServiceMileage && !/^\d+$/.test(form.nextServiceMileage)) {
      setFormError("Next service mileage must be a non-negative whole number.");
      return;
    }
    if (form.mileage && form.lastServiceMileage && Number(form.lastServiceMileage) > Number(form.mileage)) {
      setFormError("Last service mileage cannot exceed current mileage.");
      return;
    }
    if (
      form.lastServiceMileage &&
      form.nextServiceMileage &&
      Number(form.nextServiceMileage) < Number(form.lastServiceMileage)
    ) {
      setFormError("Next service mileage cannot be lower than last service mileage.");
      return;
    }
    if (form.lastServiceDate && form.nextServiceDate && form.nextServiceDate < form.lastServiceDate) {
      setFormError("Next service date cannot be before last service date.");
      return;
    }

    setIsSaving(true);
    try {
      const selectedCompany = companiesData.find((c) => c.id === form.companyId);
      const companyName = selectedCompany ? selectedCompany.name : "";

      const savedVehicle = await postApi<{ id: number }>(
        modalMode === "create" ? "admin-create-vehicle" : "admin-update-vehicle",
        {
          id: selectedEquipment?.id,
          vecNo: form.vecNo.trim().toUpperCase(),
          regNo: form.regNo.trim().toUpperCase(),
          equipment: form.equipment,
          brand: normalizedBrand,
          model: normalizedModel,
          containerLength: form.containerLength,
          axleConfiguration: form.axleConfiguration,
          year: form.year === "" ? null : Number(form.year),
          mileage: form.mileage === "" ? null : Number(form.mileage),
          companyId: form.companyId,
          driverId: form.driverId,
          chassisNo: form.chassisNo.trim().toUpperCase(),
          engineNo: form.engineNo.trim().toUpperCase(),
          ownerName: companyName,
          insurance: form.insurance,
          roadTax: form.roadTax,
          puspakom: form.puspakom,
          lastServiceDate: form.lastServiceDate,
          lastServiceMileage: form.lastServiceMileage === "" ? null : Number(form.lastServiceMileage),
          nextServiceDate: form.nextServiceDate,
          nextServiceMileage: form.nextServiceMileage === "" ? null : Number(form.nextServiceMileage),
          vehicleStatus: form.vehicleStatus,
          autocountProjectNo: form.autocountProjectNo.trim(),
        }
      );
      const shouldApproveAfterSave =
        approveAfterSave &&
        modalMode === "edit" &&
        selectedEquipment?.verificationStatus === "pending" &&
        canReview;

      if (shouldApproveAfterSave) {
        await postApi("admin-review-vehicle", {
          id: savedVehicle.id,
          decision: "approved",
          reason: "",
        });
      }

      await reload();
      closeModal();
      toast.success(
        shouldApproveAfterSave
          ? `Vehicle "${form.regNo.trim().toUpperCase()}" saved and approved.`
          : modalMode === "create"
          ? `Vehicle "${form.regNo.trim().toUpperCase()}" added successfully.`
          : `Vehicle "${form.regNo.trim().toUpperCase()}" updated successfully.`,
        { id: `vehicle-saved-${savedVehicle.id}` },
      );
    } catch (apiError) {
      setFormError(apiError instanceof Error ? apiError.message : "Unable to save vehicle.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteEquipment = async (item: Vehicle) => {
    const confirmed = await confirmAction({
      title: `Delete vehicle "${item.regNo}"?`,
      description: "This vehicle and its stored details will be permanently removed. This action cannot be undone.",
      confirmLabel: "Delete vehicle",
      tone: "danger",
    });
    if (!confirmed) {
      return;
    }

    try {
      await postApi("admin-delete-vehicle", { id: item.id });
      await reload();
      toast.success(`Vehicle "${item.regNo}" deleted.`);
    } catch (apiError) {
      toast.error(apiError instanceof Error ? apiError.message : "Unable to delete vehicle.");
    }
  };

  const handleReviewVehicle = async (decision: "approved" | "rejected") => {
    if (!selectedEquipment) return;
    if (decision === "rejected" && !reviewReason.trim()) {
      setFormError("Please enter a rejection reason.");
      return;
    }
    setFormError("");
    setIsReviewing(true);
    try {
      await postApi("admin-review-vehicle", {
        id: selectedEquipment.id,
        decision,
        reason: decision === "rejected" ? reviewReason.trim() : "",
      });
      await reload();
      closeModal();
    } catch (apiError) {
      setFormError(apiError instanceof Error ? apiError.message : "Unable to review vehicle.");
    } finally {
      setIsReviewing(false);
    }
  };

  const handleExportEquipment = async () => {
    if (filteredEquipment.length === 0) {
      toast.error("No vehicles available to export.");
      return;
    }

    const columnDefs: ExcelColumnDef[] = [
      { header: "Plate / Reg No", key: "regNo", align: "left", minWidth: 16, numFmt: "@" },
      { header: "Equipment Type", key: "equipment", align: "left", minWidth: 20 },
      { header: "Brand", key: "brand", align: "left", minWidth: 16 },
      { header: "Model", key: "model", align: "left", minWidth: 18 },
      { header: "Year", key: "year", align: "center", minWidth: 10 },
      { header: "Company / Owner", key: "companyName", align: "left", minWidth: 26 },
      { header: "Assigned Driver", key: "driverName", align: "left", minWidth: 20 },
      { header: "Current Mileage", key: "mileage", align: "right", minWidth: 16 },
      { header: "Chassis No", key: "chassisNo", align: "left", minWidth: 20, numFmt: "@" },
      { header: "Engine No", key: "engineNo", align: "left", minWidth: 18, numFmt: "@" },
      { header: "Puspakom Due", key: "puspakom", align: "center", minWidth: 14 },
      { header: "Road Tax Due", key: "roadTax", align: "center", minWidth: 14 },
      { header: "Last Service Date", key: "lastServiceDate", align: "center", minWidth: 16 },
      { header: "Next Service Date", key: "nextServiceDate", align: "center", minWidth: 16 },
      { header: "AutoCount Project No", key: "autocountProjectNo", align: "left", minWidth: 20, numFmt: "@" },
      { header: "Status", key: "status", align: "center", minWidth: 14 },
    ];

    const rows = filteredEquipment.map((v) => ({
      regNo: String(v.regNo || v.vecNo || "-"),
      equipment: String(v.equipment || "-"),
      brand: String(v.brand || "-"),
      model: String(v.model || "-"),
      year: v.year ? String(v.year) : "-",
      companyName: String(v.companyName || v.owner || "-"),
      driverName: String(v.driverName || "-"),
      mileage: String(v.mileage || "-"),
      chassisNo: String(v.chassisNo || "-"),
      engineNo: String(v.engineNo || "-"),
      puspakom: v.puspakom ? String(v.puspakom).slice(0, 10) : "-",
      roadTax: v.roadTax ? String(v.roadTax).slice(0, 10) : "-",
      lastServiceDate: v.lastServiceDate ? String(v.lastServiceDate).slice(0, 10) : "-",
      nextServiceDate: v.nextServiceDate ? String(v.nextServiceDate).slice(0, 10) : "-",
      autocountProjectNo: String(v.autocountProjectNo || "-"),
      status: String(v.status || v.vehicleStatus || "-").toUpperCase(),
    }));

    const fileName = `maw-vehicles-${new Date().toISOString().slice(0, 10)}.xlsx`;
    await exportTableToExcel({
      fileName,
      sheetName: "Vehicles Fleet",
      columns: columnDefs,
      data: rows,
      successMessage: `Exported ${filteredEquipment.length} vehicles to ${fileName}`,
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-2xl font-extrabold text-slate-900">Vehicle Management</h1>
            <AutoCountSyncBadge
              label="AutoCount Vehicle Master"
              onRefresh={() => void reload()}
              isRefreshing={isLoading}
            />
          </div>
          <p className="mt-0.5 text-xs text-slate-500">
            Fleet master records are managed in AutoCount. Maintenance schedule and driver assignments are tracked here.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportEquipment}
            disabled={isLoading || filteredEquipment.length === 0}
            className="inline-flex h-10 items-center justify-center rounded-xl border border-gray-300 bg-white px-4 text-sm font-semibold text-gray-700 shadow-sm transition-colors hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Download className="mr-2 h-4 w-4" />
            Export Excel
          </button>
        </div>
      </div>

      {error && (
        <div className="rounded-lg border border-yellow-200 bg-yellow-50 px-4 py-3 text-sm text-yellow-800">
          Database data unavailable: {error}. Showing fallback data.
        </div>
      )}

      {companyFilter ? (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-900">
          <span>
            Showing vehicles for <strong>{filteredCompanyName || `Company #${companyFilter}`}</strong>
          </span>
          <button type="button" onClick={clearCompanyFilter} className="font-semibold text-[#1e3a8a] hover:text-blue-700">
            Clear company filter
          </button>
        </div>
      ) : null}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
          <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">Total Vehicles</p>
          <p className="mt-3 text-2xl font-bold text-gray-900">{filteredEquipment.length}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
          <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">Prime Mover</p>
          <p className="mt-3 text-2xl font-bold text-gray-900">
            {filteredEquipment.filter((e) => e.equipment === "Prime Mover").length}
          </p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
          <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">Container Chassis</p>
          <p className="mt-3 text-2xl font-bold text-gray-900">
            {filteredEquipment.filter((e) => normalizeEquipmentProfile(e.equipment).equipment === "Container Chassis / Skeletal Trailer").length}
          </p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
          <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">Pending Verification</p>
          <p className="mt-3 text-2xl font-bold text-amber-600">
            {filteredEquipment.filter((e) => (e.verificationStatus || "approved") === "pending").length}
          </p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
          <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">Need Repair</p>
          <p className="mt-3 text-2xl font-bold text-red-600">
            {filteredEquipment.filter((e) => e.status === "Need Repair").length}
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="maw-filter-bar">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-4">
          <div className="md:col-span-2">
            <div className="maw-search-field">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search vehicle no., reg no. or owner..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
              />
            </div>
          </div>
          <div>
            <AdminSelect
              value={selectedBrand}
              onChange={(e) => setSelectedBrand(e.target.value)}
              className="w-full"
              aria-label="Filter vehicle brand"
            >
              {brands.map((brand) => (
                <option key={brand}>{brand}</option>
              ))}
            </AdminSelect>
          </div>
          <div>
            <AdminSelect
              value={verificationFilter}
              onChange={(e) => setVerificationFilter(e.target.value)}
              className="w-full"
              aria-label="Filter vehicle verification status"
            >
              <option>All</option>
              <option>Pending</option>
              <option>Approved</option>
              <option>Rejected</option>
            </AdminSelect>
          </div>
        </div>
      </div>

      {/* Equipment / Vehicles Table */}
      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Vehicle / Unit
                </th>
                <th scope="col" className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Type &amp; Specs
                </th>
                <th scope="col" className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Make / Model / Year
                </th>
                <th scope="col" className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Company / Driver
                </th>
                <th scope="col" className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Mileage &amp; Condition
                </th>
                <th scope="col" className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Compliance Expiry
                </th>
                <th scope="col" className="px-5 py-3 text-right text-xs font-semibold uppercase tracking-wider text-gray-500">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 bg-white">
              {isLoading && filteredEquipment.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-12 text-center text-sm text-gray-500">
                    Loading vehicles…
                  </td>
                </tr>
              ) : null}
              {!isLoading && filteredEquipment.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-12 text-center text-sm text-gray-500">
                    No vehicles found matching these criteria.
                  </td>
                </tr>
              ) : null}
              {filteredEquipment.map((item) => (
                <tr key={item.id} className="align-top transition-colors hover:bg-gray-50/80">
                  {/* Vehicle / Unit */}
                  <td className="px-5 py-4 whitespace-nowrap">
                    <div className="flex items-start gap-3">
                      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-blue-50 text-[#1e3a8a]">
                        <Truck className="h-5 w-5" />
                      </div>
                      <div>
                        {item.vecNo ? (
                          <>
                            <p className="font-extrabold text-slate-900 text-sm tracking-tight">{item.vecNo}</p>
                            <p className="mt-0.5 text-xs text-slate-500 font-medium">Plate: <span className="font-semibold text-slate-700">{item.regNo}</span></p>
                          </>
                        ) : (
                          <p className="font-extrabold text-slate-900 text-sm">{item.regNo}</p>
                        )}
                        {item.autocountProjectNo ? (
                          <p className="mt-0.5 font-mono text-[10px] text-sky-700 font-semibold" title="AutoCount Project / Ref">
                            AC: {item.autocountProjectNo}
                          </p>
                        ) : null}
                        <span className={`mt-1.5 inline-block px-2 py-0.5 text-[10px] rounded-full font-bold uppercase ${
                          (item.verificationStatus || "approved") === "pending"
                            ? "bg-amber-50 text-amber-700 border border-amber-200"
                            : item.verificationStatus === "rejected"
                            ? "bg-red-50 text-red-700 border border-red-200"
                            : "bg-emerald-50 text-emerald-700 border border-emerald-200"
                        }`}>
                          {item.verificationStatus || "approved"}
                        </span>
                      </div>
                    </div>
                  </td>

                  {/* Type & Specs */}
                  <td className="px-5 py-4">
                    <p className="font-semibold text-gray-900 text-xs">
                      {isMissingEquipmentValue(item.equipment) ? "Not specified" : item.equipment}
                    </p>
                    {item.containerLength || item.axleConfiguration ? (
                      <div className="mt-1 flex flex-wrap gap-1 text-[11px] text-gray-500">
                        {item.containerLength ? <span className="rounded bg-slate-100 px-1.5 py-0.5 font-medium">{item.containerLength}</span> : null}
                        {item.axleConfiguration ? <span className="rounded bg-slate-100 px-1.5 py-0.5 font-medium">{item.axleConfiguration}</span> : null}
                      </div>
                    ) : null}
                  </td>

                  {/* Make / Model / Year */}
                  <td className="px-5 py-4">
                    <p className="font-semibold text-gray-900 text-sm">
                      {[item.brand, item.model].filter(Boolean).join(" ") || "-"}
                    </p>
                    <p className="mt-0.5 text-xs text-gray-500">
                      {item.year ? `Year ${item.year}` : "Year —"}
                    </p>
                  </td>

                  {/* Company / Driver */}
                  <td className="px-5 py-4">
                    <p className="font-semibold text-gray-900 text-xs">
                      {item.companyName || item.owner || "-"}
                    </p>
                    <p className="mt-0.5 text-xs text-gray-500 flex items-center gap-1">
                      <span>Driver:</span>
                      <span className="font-medium text-gray-700">{item.driverName || "Unassigned"}</span>
                    </p>
                  </td>

                  {/* Mileage & Condition */}
                  <td className="px-5 py-4 whitespace-nowrap">
                    <p className="font-mono text-xs font-semibold text-gray-900">
                      {item.mileage !== null && item.mileage !== undefined ? `${item.mileage.toLocaleString()} km` : "-"}
                    </p>
                    <span
                      className={`mt-1 inline-block px-2 py-0.5 text-[10px] rounded-full font-bold ${
                        item.status === "Excellent"
                          ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                          : item.status === "Good"
                          ? "bg-blue-50 text-blue-700 border border-blue-200"
                          : "bg-red-50 text-red-700 border border-red-200"
                      }`}
                    >
                      {item.status || "Good"}
                    </span>
                  </td>

                  {/* Compliance Expiry */}
                  <td className="px-5 py-4 text-xs text-gray-600 whitespace-nowrap">
                    <div className="space-y-0.5 text-[11px]">
                      <div className="flex gap-1.5"><span className="text-gray-400">Road Tax:</span><span className="font-medium text-gray-800">{item.roadTax || "-"}</span></div>
                      <div className="flex gap-1.5"><span className="text-gray-400">Insurance:</span><span className="font-medium text-gray-800">{item.insurance || "-"}</span></div>
                      <div className="flex gap-1.5"><span className="text-gray-400">Puspakom:</span><span className="font-medium text-gray-800">{item.puspakom || "-"}</span></div>
                    </div>
                  </td>

                  {/* Actions */}
                  <td className="px-5 py-4 whitespace-nowrap text-right text-sm">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        type="button"
                        onClick={() => openViewModal(item)}
                        className="rounded-lg p-2 text-gray-500 transition-colors hover:bg-blue-50 hover:text-blue-700"
                        aria-label={`View ${item.regNo}`}
                        title="View details"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      {canUpdate ? (
                        <button
                          type="button"
                          onClick={() => openEditModal(item)}
                          className="inline-flex items-center gap-1 rounded-lg border border-gray-200 px-2.5 py-1.5 text-xs font-semibold text-gray-700 transition-colors hover:border-blue-200 hover:bg-blue-50 hover:text-blue-700"
                          aria-label={`Edit ${item.regNo}`}
                          title="Edit vehicle"
                        >
                          <Edit className="h-3.5 w-3.5" />
                          Edit
                        </button>
                      ) : null}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {modalMode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-3 backdrop-blur-sm transition-opacity sm:p-5">
          <div className={`flex max-h-[94vh] w-full flex-col overflow-hidden rounded-2xl border border-white/70 bg-white shadow-2xl animate-in fade-in zoom-in-95 duration-150 ${modalMode === "view" ? "max-w-lg" : "max-w-4xl"}`}>
            {/* Modal Header */}
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 bg-white px-5 py-4 sm:px-7 sm:py-5">
              <div className="flex min-w-0 items-start gap-3.5">
                {modalMode !== "view" ? <div className="mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-[#1e3a8a] ring-1 ring-blue-100"><Truck className="h-5 w-5" /></div> : null}
                <div>
                <h2 className="text-lg font-bold tracking-tight text-slate-900 sm:text-xl">
                  {modalMode === "create"
                    ? "New Vehicle"
                    : modalMode === "edit"
                    ? "Edit Vehicle"
                    : "Vehicle Details"}
                </h2>
                <p className="mt-1 text-xs leading-5 text-slate-500 sm:text-sm">
                  {modalMode === "view"
                    ? "View detailed vehicle information."
                    : "Fill in vehicle details below."}
                </p>
                </div>
              </div>
              <button
                type="button"
                onClick={closeModal}
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700"
                aria-label="Close"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className={`flex-1 overflow-y-auto p-4 sm:p-6 ${modalMode === "view" ? "bg-white" : "bg-slate-50/80"}`}>
              {modalMode === "view" && selectedEquipment ? (
                <div className="space-y-4">
                  <div className="flex items-center space-x-3 pb-4 border-b border-gray-100">
                    <div className="h-12 w-12 rounded-lg bg-blue-100 flex items-center justify-center">
                      <Truck className="h-6 w-6 text-[#1e3a8a]" />
                    </div>
                    <div>
                      <h4 className="text-base font-semibold text-gray-900">{selectedEquipment.vecNo || "-"}</h4>
                      <p className="text-sm text-gray-500">{selectedEquipment.regNo}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-3 text-sm">
                    <div className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="text-gray-500">Type:</span>
                      <span className="text-gray-900 font-medium">
                        {isMissingEquipmentValue(selectedEquipment.equipment) ? "Not specified" : selectedEquipment.equipment}
                      </span>
                    </div>
                    <div className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="text-gray-500">Brand:</span>
                      <span className="text-gray-900 font-medium">{selectedEquipment.brand}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="text-gray-500">Model:</span>
                      <span className="text-gray-900 font-medium">{selectedEquipment.model}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="text-gray-500">Year:</span>
                      <span className="text-gray-900 font-medium">{selectedEquipment.year || "-"}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="text-gray-500">Mileage:</span>
                      <span className="text-gray-900 font-medium">{selectedEquipment.mileage}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="text-gray-500">Company:</span>
                      <span className="text-gray-900 font-medium">{selectedEquipment.companyName || selectedEquipment.owner}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="text-gray-500">Driver:</span>
                      <span className="text-gray-900 font-medium">{selectedEquipment.driverName || "-"}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="text-gray-500">Chassis No.:</span>
                      <span className="text-gray-900 font-medium">{selectedEquipment.chassisNo || "-"}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="text-gray-500">Engine No.:</span>
                      <span className="text-gray-900 font-medium">{selectedEquipment.engineNo || "-"}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="text-gray-500">Insurance Expiry:</span>
                      <span className="text-gray-900 font-medium">{selectedEquipment.insurance || "-"}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="text-gray-500">Road Tax Expiry:</span>
                      <span className="text-gray-900 font-medium">{selectedEquipment.roadTax || "-"}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="text-gray-500">Puspakom Expiry:</span>
                      <span className="text-gray-900 font-medium">{selectedEquipment.puspakom || "-"}</span>
                    </div>
                    {selectedEquipment.autocountProjectNo ? (
                      <div className="flex justify-between border-b border-gray-100 pb-2">
                        <span className="text-gray-500">AutoCount Project / Ref:</span>
                        <span className="font-mono text-xs font-bold text-sky-800">{selectedEquipment.autocountProjectNo}</span>
                      </div>
                    ) : null}
                    <div className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="text-gray-500">Last Service:</span>
                      <span className="text-gray-900 font-medium">
                        {selectedEquipment.lastServiceDate || "-"}
                        {selectedEquipment.lastServiceMileage ? ` · ${selectedEquipment.lastServiceMileage.toLocaleString()} km` : ""}
                      </span>
                    </div>
                    <div className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="text-gray-500">Next Service:</span>
                      <span className="text-gray-900 font-medium">
                        {selectedEquipment.nextServiceDate || "-"}
                        {selectedEquipment.nextServiceMileage ? ` · ${selectedEquipment.nextServiceMileage.toLocaleString()} km` : ""}
                      </span>
                    </div>
                    <div className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="text-gray-500">Verification:</span>
                      <span className={`px-2.5 py-0.5 text-xs rounded-full font-semibold ${
                        (selectedEquipment.verificationStatus || "approved") === "pending"
                          ? "bg-amber-100 text-amber-800"
                          : selectedEquipment.verificationStatus === "rejected"
                          ? "bg-red-100 text-red-800"
                          : "bg-green-100 text-green-800"
                      }`}>
                        {(selectedEquipment.verificationStatus || "approved").toUpperCase()}
                      </span>
                    </div>
                    {selectedEquipment.rejectionReason && (
                      <div className="flex justify-between gap-4 border-b border-gray-100 pb-2">
                        <span className="text-gray-500">Rejection Reason:</span>
                        <span className="text-right text-red-700 font-medium">{selectedEquipment.rejectionReason}</span>
                      </div>
                    )}
                    {selectedEquipment.reviewedAt && (
                      <div className="flex justify-between border-b border-gray-100 pb-2">
                        <span className="text-gray-500">Reviewed At:</span>
                        <span className="text-gray-900 font-medium">{selectedEquipment.reviewedAt}</span>
                      </div>
                    )}
                    <div className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="text-gray-500">Vehicle Status:</span>
                      <span className="text-gray-900 font-medium">{selectedEquipment.vehicleStatus || "Active"}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-100 pb-2">
                      <span className="text-gray-500">Vehicle Condition:</span>
                      <span className={`px-2.5 py-0.5 text-xs rounded-full font-semibold ${
                        selectedEquipment.status === "Pending Verification"
                          ? "bg-amber-100 text-amber-800"
                          : selectedEquipment.status === "Excellent"
                          ? "bg-green-100 text-green-800"
                          : selectedEquipment.status === "Good"
                          ? "bg-blue-100 text-blue-800"
                          : "bg-red-100 text-red-800"
                      }`}>
                        {selectedEquipment.status}
                      </span>
                    </div>
                  </div>

                  {canReview ? <div className="rounded-lg border border-gray-200 bg-gray-50 p-3 space-y-3">
                    <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider">
                      Rejection reason
                    </label>
                    <textarea
                      value={reviewReason}
                      onChange={(e) => setReviewReason(e.target.value)}
                      placeholder="Required when rejecting a vehicle"
                      rows={3}
                      className="w-full resize-none rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                    />
                    <div className="grid grid-cols-2 gap-3">
                      <button
                        type="button"
                        onClick={() => void handleReviewVehicle("approved")}
                        disabled={isReviewing || selectedEquipment.verificationStatus === "approved"}
                        className="rounded-lg bg-green-600 px-3 py-2 text-sm font-medium text-white hover:bg-green-700 disabled:opacity-40"
                      >
                        {isReviewing ? "Saving..." : "Approve"}
                      </button>
                      <button
                        type="button"
                        onClick={() => void handleReviewVehicle("rejected")}
                        disabled={isReviewing}
                        className="rounded-lg bg-red-600 px-3 py-2 text-sm font-medium text-white hover:bg-red-700 disabled:opacity-40"
                      >
                        Reject
                      </button>
                    </div>
                  </div> : null}
                  {formError && (
                    <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
                      {formError}
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="rounded-xl border border-blue-200 bg-blue-50/70 p-3.5 flex items-start gap-2.5 text-xs text-slate-700">
                    <Database className="h-4 w-4 text-[#1e3a8a] shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-slate-900">AutoCount Master Entity:</strong> Vehicle registration, make, model, chassis, and ownership company are maintained in AutoCount. Operational workshop tracking (assigned driver, vehicle status, mileage, service dates and compliance expiries) can be updated here.
                    </div>
                  </div>
                  <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
                    <div className="flex items-start gap-3 rounded-t-xl border-b border-slate-100 bg-white px-4 py-3.5 sm:px-5"><div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-blue-50 text-blue-700"><Truck className="h-4 w-4" /></div><div><h3 className="text-sm font-bold text-slate-900">1. Vehicle profile</h3><p className="mt-0.5 text-xs text-slate-500">Fleet identity and operational workshop details.</p></div></div>
                  <div className="space-y-4 p-4 sm:p-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">Equipment Type *</label>
                      <AdminSelect
                        value={form.equipment}
                        onChange={(e) => {
                          const equipment = e.target.value;
                          setForm((current) => ({
                            ...current,
                            equipment,
                            ...(equipment === "Container Chassis / Skeletal Trailer"
                              ? { mileage: "", engineNo: "", driverId: 0 }
                              : { containerLength: "", axleConfiguration: "" }),
                            ...(equipment !== "Prime Mover" ? { engineNo: "" } : {}),
                          }));
                        }}
                        className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      >
                        <option value="" disabled>Select Equipment Type</option>
                        {form.equipment && !fleetEquipmentTypes.includes(form.equipment) ? (
                          <option value={form.equipment}>{form.equipment} (Legacy type — please update)</option>
                        ) : null}
                        {fleetEquipmentTypes.map((equipmentType) => (
                          <option key={equipmentType} value={equipmentType}>{equipmentType}</option>
                        ))}
                      </AdminSelect>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">Vehicle Status *</label>
                      <AdminSelect
                        value={form.vehicleStatus}
                        onChange={(e) => setForm({ ...form, vehicleStatus: e.target.value as VehicleStatus })}
                        className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      >
                        {vehicleStatuses.map((status) => (
                          <option key={status} value={status}>{status}</option>
                        ))}
                      </AdminSelect>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">Unit / Fleet Number</label>
                      <input
                        type="text"
                        maxLength={50}
                        placeholder="e.g. MTL 001"
                        value={form.vecNo}
                        onChange={(e) => setForm({ ...form, vecNo: e.target.value.toUpperCase() })}
                        onBlur={() => setForm((current) => ({ ...current, vecNo: current.vecNo.trim().toUpperCase() }))}
                        className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      <p className="mt-1 text-xs text-gray-500">Optional internal unit number, for example MTL 001.</p>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">Registration / Plate No. *</label>
                      <input
                        type="text"
                        placeholder="e.g. WKL 1234"
                        value={form.regNo}
                        onChange={(e) => setForm({ ...form, regNo: e.target.value.toUpperCase() })}
                        onBlur={() => setForm((current) => ({ ...current, regNo: current.regNo.trim().toUpperCase() }))}
                        className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">Manufacture Year</label>
                      <input
                        type="number"
                        min={1900}
                        max={new Date().getFullYear() + 1}
                        step={1}
                        placeholder="e.g. 2020"
                        value={form.year}
                        onChange={(e) => setForm({ ...form, year: e.target.value })}
                        className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                        Brand / Manufacturer
                        <span className={`inline-block w-2 ${isPrimeMover ? "" : "invisible"}`} aria-hidden="true"> *</span>
                      </label>
                      <AdminCombobox
                        ariaLabel="Choose or enter a vehicle brand"
                        placeholder={isContainerChassis ? "Optional local or custom manufacturer" : "e.g. Volvo Trucks"}
                        value={form.brand}
                        onChange={(value) => setForm({
                          ...form,
                          brand: canonicalizeBrand(value, brandSuggestions),
                        })}
                        options={brandSuggestions}
                        className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                        Model / Series
                        <span className={`inline-block w-2 ${isPrimeMover ? "" : "invisible"}`} aria-hidden="true"> *</span>
                      </label>
                      <AdminCombobox
                        ariaLabel="Choose or enter a vehicle model"
                        placeholder={
                          isPrimeMover
                            ? "e.g. FH16, FMX, G450, Quester, GIGA"
                            : isContainerChassis
                              ? "e.g. 3-Axle Skeletal Chassis"
                              : "Optional model or series"
                        }
                        value={form.model}
                        onChange={(value) => setForm({
                          ...form,
                          model: canonicalizeSuggestion(value, modelSuggestions),
                        })}
                        options={modelSuggestions}
                        className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  {isContainerChassis ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">Container Length *</label>
                        <AdminSelect
                          value={form.containerLength}
                          onChange={(e) => setForm({ ...form, containerLength: e.target.value })}
                          className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                        >
                          <option value="">-- Select Container Length --</option>
                          {containerLengths.map((length) => (
                            <option key={length} value={length}>{length}</option>
                          ))}
                        </AdminSelect>
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">Axle Configuration *</label>
                        <AdminSelect
                          value={form.axleConfiguration}
                          onChange={(e) => setForm({ ...form, axleConfiguration: e.target.value })}
                          className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                        >
                          <option value="">-- Select Axle Configuration --</option>
                          {axleConfigurations.map((configuration) => (
                            <option key={configuration} value={configuration}>{configuration}</option>
                          ))}
                        </AdminSelect>
                      </div>
                    </div>
                  ) : null}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {showMileage ? (
                      <div>
                        <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">Current Mileage</label>
                        <input
                          type="number"
                          inputMode="numeric"
                          min={0}
                          step={1}
                          placeholder="e.g. 125000"
                          value={form.mileage}
                          onChange={(e) => {
                            if (/^\d*$/.test(e.target.value)) setForm({ ...form, mileage: e.target.value });
                          }}
                          className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                    ) : null}
                    <div className={showMileage ? "" : "sm:col-span-2"}>
                      <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">Chassis / VIN No.</label>
                      <input
                        type="text"
                        placeholder="Optional"
                        value={form.chassisNo}
                        onChange={(e) => setForm({ ...form, chassisNo: e.target.value.toUpperCase() })}
                        className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {showEngineNumber ? (
                      <div>
                        <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">Engine No.</label>
                        <input
                          type="text"
                          placeholder="Optional"
                          value={form.engineNo}
                          onChange={(e) => setForm({ ...form, engineNo: e.target.value.toUpperCase() })}
                          className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                    ) : null}
                    <div className={showEngineNumber ? "" : "sm:col-span-2"}>
                      <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">Company *</label>
                      <AdminSelect
                        value={form.companyId}
                        onChange={(e) => {
                          const companyId = Number(e.target.value);
                          const selectedDriver = driversData.find((driver) => Number(driver.id) === form.driverId);
                          const driverId = selectedDriver && Number(selectedDriver.companyId) === companyId ? form.driverId : 0;
                          setForm({ ...form, companyId, driverId });
                        }}
                        className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      >
                        <option value={0}>-- Select Company --</option>
                        {companiesData.map((comp) => (
                          <option key={comp.id} value={comp.id}>
                            {comp.name}
                          </option>
                        ))}
                      </AdminSelect>
                    </div>
                  </div>

                  {showAssignedDriver ? (
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">Assigned Driver (Optional)</label>
                      <AdminSelect
                        value={form.driverId}
                        onChange={(e) => setForm({ ...form, driverId: Number(e.target.value) })}
                        disabled={!form.companyId}
                        className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      >
                        <option value={0}>-- Select Driver (Optional) --</option>
                        {driversData.filter((driver) => form.companyId > 0 && Number(driver.companyId) === form.companyId && driver.status === "Active").map((driver) => (
                          <option key={driver.id} value={driver.id}>
                            {driver.name}{driver.phone ? ` (${driver.phone})` : ""}
                          </option>
                        ))}
                      </AdminSelect>
                    </div>
                  ) : null}

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-700 uppercase tracking-wider mb-1">Insurance Expiry</label>
                      <DesktopDatePicker
                        value={form.insurance || ""}
                        onChange={(value) => setForm({ ...form, insurance: value })}
                        ariaLabel="Choose insurance expiry date"
                        className="w-full rounded-lg border border-gray-300 px-2 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-700 uppercase tracking-wider mb-1">Road Tax Expiry</label>
                      <DesktopDatePicker
                        value={form.roadTax || ""}
                        onChange={(value) => setForm({ ...form, roadTax: value })}
                        ariaLabel="Choose road tax expiry date"
                        className="w-full rounded-lg border border-gray-300 px-2 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-700 uppercase tracking-wider mb-1">Puspakom Expiry</label>
                      <DesktopDatePicker
                        value={form.puspakom || ""}
                        onChange={(value) => setForm({ ...form, puspakom: value })}
                        ariaLabel="Choose PUSPAKOM expiry date"
                        className="w-full rounded-lg border border-gray-300 px-2 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      />
                    </div>
                  </div>

                  <div className="rounded-xl border border-gray-200 bg-gray-50 p-4">
                    <div className="mb-3">
                      <h3 className="text-sm font-semibold text-gray-900">Service Information</h3>
                      <p className="mt-0.5 text-xs text-gray-500">
                        Optional history and the next recommended service interval.
                      </p>
                    </div>
                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                      <div className="space-y-3">
                        <div>
                          <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">Last Service Date</label>
                          <DesktopDatePicker
                            value={form.lastServiceDate}
                            onChange={(value) => setForm({ ...form, lastServiceDate: value })}
                            ariaLabel="Choose last service date"
                            className="w-full"
                          />
                        </div>
                        <div>
                          <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">Last Service Mileage</label>
                          <input
                            type="number"
                            inputMode="numeric"
                            min={0}
                            step={1}
                            placeholder="e.g. 100000"
                            value={form.lastServiceMileage}
                            onChange={(event) => {
                              if (/^\d*$/.test(event.target.value)) {
                                setForm({ ...form, lastServiceMileage: event.target.value });
                              }
                            }}
                            className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div>
                          <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">Next Service Date</label>
                          <DesktopDatePicker
                            value={form.nextServiceDate}
                            onChange={(value) => setForm({ ...form, nextServiceDate: value })}
                            ariaLabel="Choose next service date"
                            className="w-full"
                          />
                        </div>
                        <div>
                          <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">Next Service Mileage</label>
                          <input
                            type="number"
                            inputMode="numeric"
                            min={0}
                            step={1}
                            placeholder="e.g. 120000"
                            value={form.nextServiceMileage}
                            onChange={(event) => {
                              if (/^\d*$/.test(event.target.value)) {
                                setForm({ ...form, nextServiceMileage: event.target.value });
                              }
                            }}
                            className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {formError && (
                    <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
                      {formError}
                    </div>
                  )}
                  </div>
                </section>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="flex flex-col-reverse gap-3 border-t border-slate-200 bg-white px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between sm:px-7">
              <p className="text-xs text-slate-500">{modalMode !== "view" ? <><span className="font-bold text-red-500">*</span> Required fields must be completed</> : null}</p>
              <div className="flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={closeModal}
                className="h-10 rounded-lg border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-700 transition-colors hover:bg-slate-50"
              >
                Close
              </button>
              {modalMode === "edit" &&
                selectedEquipment?.verificationStatus === "pending" &&
                canReview && (
                <button
                  type="button"
                  onClick={() => void handleSubmitEquipment(true)}
                  disabled={isSaving}
                  className="rounded-lg bg-green-600 px-4 py-2 text-sm text-white hover:bg-green-700 disabled:opacity-50 transition-colors"
                >
                  {isSaving ? "Saving..." : "Save & Approve"}
                </button>
              )}
              {modalMode !== "view" && (
                <button
                  type="button"
                  onClick={() => void handleSubmitEquipment(false)}
                  disabled={isSaving}
                  className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-[#1e3a8a] px-5 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-blue-800 disabled:opacity-50"
                >
                  <Save className="h-4 w-4" />{isSaving ? "Saving..." : modalMode === "create" ? "Create Vehicle" : "Save Changes"}
                </button>
              )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
