import { useDeferredValue, useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  Calendar,
  CalendarClock,
  CheckCircle2,
  Clock,
  Eye,
  FileText,
  Layers,
  Package,
  PackageCheck,
  Plus,
  RefreshCw,
  Search,
  ShoppingCart,
  Trash2,
  Truck,
  Download,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { apiRequest, postApi } from "../lib/api";
import { useApiData } from "../lib/use-api-data";
import { hasAdminPermission } from "../lib/admin-permissions";
import { AdminSelect } from "./ui/admin-select";
import { DesktopDatePicker } from "./ui/desktop-date-picker";
import { AutoCountSyncBadge } from "./autocount-sync-badge";
import { DocumentItemCatalogSelect, type DocumentCatalogPart } from "./ui/document-item-catalog-select";
import { exportTableToExcel, ExcelColumnDef } from "../lib/excel-export";

type PurchaseOrderItem = {
  id?: number;
  partId: number | null;
  itemCode: string;
  description: string;
  uom: string;
  quantity: number;
  receivedQuantity: number;
  unitCost: number;
  taxCode: string;
  taxRate: number;
  taxAmount?: number;
  amount?: number;
};

type PurchaseOrder = {
  id: number;
  internalRef: string;
  autocountPoNo: string;
  workOrderId: number | null;
  workOrderNo: string;
  supplierCode: string;
  supplierName: string;
  orderDate: string;
  estimatedArrivalDate: string;
  reminderDays: number;
  status: "draft" | "pending_sync" | "ordered" | "partially_received" | "received" | "cancelled";
  currency: string;
  subtotal: number;
  taxAmount: number;
  total: number;
  notes: string;
  syncStatus: "not_queued" | "queued" | "processing" | "synced" | "failed";
  syncError: string;
  items: PurchaseOrderItem[];
};

type PartOption = { id: number; name: string; sku: string; cost: number; uom: string; supplier: string; supplierCode: string; supplierName: string };
type WorkOrderOption = { id: number; workOrderNo: string; companyName: string };
type SupplierOption = {
  code: string;
  name: string;
  registrationNo: string;
  contact: string;
  phone: string;
  email: string;
  address: string;
  paymentTerm: string;
  creditLimit: number;
  currency: string;
  taxCode: string;
};
type PurchaseOrderOptions = { suppliers: SupplierOption[]; parts: PartOption[]; workOrders: WorkOrderOption[] };
type PurchaseOrderForm = Omit<PurchaseOrder, "id" | "internalRef" | "autocountPoNo" | "status" | "currency" | "subtotal" | "taxAmount" | "total" | "syncStatus" | "syncError" | "workOrderNo"> & { id?: number };

const today = () => new Date().toISOString().slice(0, 10);
const futureDate = (days: number) => { const value = new Date(); value.setDate(value.getDate() + days); return value.toISOString().slice(0, 10); };
const blankItem = (): PurchaseOrderItem => ({ partId: null, itemCode: "", description: "", uom: "UNIT", quantity: 1, receivedQuantity: 0, unitCost: 0, taxCode: "", taxRate: 0 });
const blankForm = (): PurchaseOrderForm => ({ supplierCode: "", supplierName: "", workOrderId: null, orderDate: today(), estimatedArrivalDate: futureDate(7), reminderDays: 1, notes: "", items: [blankItem()] });
const money = (value: number) => Number(value || 0).toLocaleString("en-MY", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

function statusClass(status: string) {
  if (status === "received") return "bg-emerald-100 text-emerald-700";
  if (status === "cancelled") return "bg-rose-100 text-rose-700";
  if (status === "pending_sync" || status === "partially_received") return "bg-amber-100 text-amber-700";
  if (status === "ordered") return "bg-blue-100 text-blue-700";
  return "bg-slate-100 text-slate-600";
}

function daysUntilArrival(order: PurchaseOrder) {
  return Math.floor((new Date(`${order.estimatedArrivalDate}T00:00:00`).getTime() - new Date(`${today()}T00:00:00`).getTime()) / 86400000);
}

function arrivalLabel(order: PurchaseOrder) {
  if (["received", "cancelled"].includes(order.status)) return order.status === "received" ? "Received" : "Cancelled";
  const difference = daysUntilArrival(order);
  if (difference < 0) return `${Math.abs(difference)} day(s) overdue`;
  if (difference === 0) return "Arriving today";
  return `In ${difference} day(s)`;
}

export function PurchaseOrders() {
  const canManage = hasAdminPermission("order.update");
  const { data: orders, isLoading, error, reload } = useApiData<PurchaseOrder[]>("admin-purchase-orders", []);
  const [options, setOptions] = useState<PurchaseOrderOptions>({ suppliers: [], parts: [], workOrders: [] });
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("all");
  const [form, setForm] = useState<PurchaseOrderForm | null>(null);
  const [viewOrder, setViewOrder] = useState<PurchaseOrder | null>(null);
  const [receiving, setReceiving] = useState<Record<number, number> | null>(null);
  const [saving, setSaving] = useState(false);

  const deferredSearch = useDeferredValue(search);

  const filtered = useMemo(() => {
    const query = deferredSearch.trim().toLowerCase();
    if (!query && status === "all") return orders;
    return orders.filter((order) => {
      if (status !== "all" && order.status !== status) return false;
      if (!query) return true;
      return (
        (order.internalRef && order.internalRef.toLowerCase().includes(query)) ||
        (order.autocountPoNo && order.autocountPoNo.toLowerCase().includes(query)) ||
        (order.supplierCode && order.supplierCode.toLowerCase().includes(query)) ||
        (order.supplierName && order.supplierName.toLowerCase().includes(query)) ||
        (order.workOrderNo && order.workOrderNo.toLowerCase().includes(query)) ||
        order.items.some(
          (item) =>
            (item.itemCode && item.itemCode.toLowerCase().includes(query)) ||
            (item.description && item.description.toLowerCase().includes(query))
        )
      );
    });
  }, [orders, deferredSearch, status]);

  const totals = useMemo(() => {
    const items = form?.items || [];
    const subtotal = items.reduce((sum, item) => sum + Number(item.quantity || 0) * Number(item.unitCost || 0), 0);
    const tax = items.reduce((sum, item) => sum + Number(item.quantity || 0) * Number(item.unitCost || 0) * Number(item.taxRate || 0) / 100, 0);
    return { subtotal, tax, total: subtotal + tax };
  }, [form?.items]);
  const selectedSupplier = useMemo(
    () => options.suppliers.find((supplier) => supplier.code === form?.supplierCode) || null,
    [options.suppliers, form?.supplierCode],
  );

  const linkedParts = useMemo(() => {
    if (!form?.supplierCode) return [];
    const targetCode = form.supplierCode.trim().toUpperCase();
    const targetName = (form.supplierName || "").trim().toLowerCase();
    return options.parts.filter((part) => {
      const partCode = (part.supplierCode || part.supplier || "").trim().toUpperCase();
      const partName = (part.supplierName || "").trim().toLowerCase();
      return (partCode && partCode === targetCode) || (targetName && partName && partName === targetName);
    });
  }, [options.parts, form?.supplierCode, form?.supplierName]);

  const catalogParts: DocumentCatalogPart[] = useMemo(() => {
    return options.parts.map((p) => ({
      id: p.id,
      sku: p.sku || "",
      name: p.name || "",
      price: p.cost || 0,
      uom: p.uom || "UNIT",
      itemType: "part",
      taxCode: "",
      isActive: true,
      stock: 0,
    }));
  }, [options.parts]);

  const loadOptions = async () => {
    try {
      const [poOptions, loadedParts] = await Promise.all([
        apiRequest<PurchaseOrderOptions>("admin-purchase-order-options"),
        apiRequest<any[]>("admin-parts").catch(() => []),
      ]);
      const mappedParts: PartOption[] = (loadedParts && Array.isArray(loadedParts) && loadedParts.length > 0)
        ? loadedParts.map((p) => ({
            id: p.id,
            name: p.name || "",
            sku: p.sku || "",
            cost: Number(p.cost || p.price || 0),
            uom: p.uom || "UNIT",
            supplier: p.supplier || "",
            supplierCode: "",
            supplierName: p.supplier || "",
          }))
        : (poOptions.parts || []);

      const combinedOptions: PurchaseOrderOptions = {
        ...poOptions,
        parts: mappedParts.length > 0 ? mappedParts : (poOptions.parts || []),
      };
      setOptions(combinedOptions);
      return combinedOptions;
    } catch {
      return options;
    }
  };

  useEffect(() => {
    void loadOptions();
  }, []);

  const openCreate = () => {
    setForm(blankForm());
    void loadOptions();
  };

  const openDraft = (order: PurchaseOrder) => {
    setForm({
      id: order.id,
      supplierCode: order.supplierCode,
      supplierName: order.supplierName,
      workOrderId: order.workOrderId,
      orderDate: order.orderDate,
      estimatedArrivalDate: order.estimatedArrivalDate,
      reminderDays: order.reminderDays,
      notes: order.notes,
      items: order.items.map((item) => ({ ...item })),
    });
    void loadOptions();
  };

  const updateItem = (index: number, patch: Partial<PurchaseOrderItem>) => setForm((current) => current ? ({ ...current, items: current.items.map((item, itemIndex) => itemIndex === index ? { ...item, ...patch } : item) }) : current);

  const selectPart = (index: number, partId: string) => {
    const part = options.parts.find((item) => item.id === Number(partId));
    if (!part) return updateItem(index, { partId: null });
    setForm((current) => current ? {
      ...current,
      supplierCode: current.supplierCode || part.supplierCode || part.supplier,
      supplierName: current.supplierName || part.supplierName,
      items: current.items.map((item, itemIndex) => itemIndex === index ? {
        ...item,
        partId: part.id,
        itemCode: part.sku,
        description: part.name,
        uom: part.uom || "UNIT",
        unitCost: part.cost,
      } : item),
    } : current);
  };

  const selectSupplier = (supplierCode: string) => {
    if (!form) return;
    if (!supplierCode) {
      setForm({ ...form, supplierCode: "", supplierName: "" });
      return;
    }
    const supplier = options.suppliers.find((item) => item.code === supplierCode);
    if (supplier) setForm({ ...form, supplierCode: supplier.code, supplierName: supplier.name });
  };

  const save = async (submitMode?: "local" | "autocount") => {
    if (!form) return;
    setSaving(true);
    try {
      const saved = await postApi<PurchaseOrder>("admin-save-purchase-order", form);
      const result = submitMode ? await postApi<PurchaseOrder>("admin-submit-purchase-order", { id: saved.id, syncToAutoCount: submitMode === "autocount" }) : saved;
      toast.success(submitMode === "autocount" ? `${result.internalRef} queued for AutoCount.` : submitMode === "local" ? `${result.internalRef} confirmed.` : "Purchase Order draft saved.");
      setForm(null); await reload();
    } catch (caught) { toast.error(caught instanceof Error ? caught.message : "Unable to save Purchase Order."); }
    finally { setSaving(false); }
  };

  const retrySync = async (order: PurchaseOrder) => {
    setSaving(true);
    try { await postApi("admin-retry-purchase-order-sync", { id: order.id }); toast.success("Purchase Order re-queued."); await reload(); }
    catch (caught) { toast.error(caught instanceof Error ? caught.message : "Unable to retry sync."); }
    finally { setSaving(false); }
  };

  const openReceiving = (order: PurchaseOrder) => {
    setViewOrder(order);
    setReceiving(Object.fromEntries(order.items.filter((item) => item.id).map((item) => [item.id!, item.receivedQuantity])));
  };

  const saveReceiving = async () => {
    if (!viewOrder || !receiving) return;
    setSaving(true);
    try {
      await postApi("admin-receive-purchase-order", { id: viewOrder.id, items: viewOrder.items.map((item) => ({ id: item.id, receivedQuantity: item.id ? Number(receiving[item.id] ?? item.receivedQuantity) : 0 })) });
      toast.success("Receiving saved and inventory updated."); setViewOrder(null); setReceiving(null); await reload();
    } catch (caught) { toast.error(caught instanceof Error ? caught.message : "Unable to receive parts."); }
    finally { setSaving(false); }
  };

  if (form) {
    const isEditing = Boolean(form.id);
    return (
      <div className="space-y-4">
        {/* Unified Card Frame */}
        <div className="flex w-full flex-col overflow-hidden rounded-2xl border border-slate-200 bg-slate-100 shadow-sm">
          {/* Header Bar */}
          <header className="no-print flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 bg-white px-5 py-4 sm:px-7 sm:py-5">
            <div className="flex flex-wrap items-center gap-3.5">
              <button
                type="button"
                onClick={() => setForm(null)}
                className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50 cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to Purchase Orders
              </button>
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-[#1e3a8a] ring-1 ring-blue-100">
                <ShoppingCart className="h-5 w-5" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-lg font-extrabold text-slate-900">
                    {isEditing ? `Edit Purchase Order` : "New Purchase Order"}
                  </h2>
                  <span className="rounded-full bg-blue-50 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-[#1e3a8a] border border-blue-100">
                    {form.supplierCode ? `Supplier: ${form.supplierCode}` : "Draft PO"}
                  </span>
                </div>
                <p className="mt-0.5 text-xs text-slate-500">
                  Set supplier, schedule arrival, manage line items and queue AutoCount ERP sync options.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-500 hidden sm:inline">
                {form.items.length} item line(s)
              </span>
            </div>
          </header>

          <div className="p-4 sm:p-6 space-y-6">
            {/* Section 1: Supplier & Schedule */}
            <section className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-blue-50 text-[#1e3a8a]">
                    <Truck className="h-4 w-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">1. Supplier &amp; Procurement Schedule</h3>
                    <p className="text-[11px] text-slate-500">Select AutoCount Creditor, order timing and related work order.</p>
                  </div>
                </div>
                {form.supplierCode ? (
                  <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    AutoCount Creditor Linked
                  </span>
                ) : null}
              </div>

              <div className="grid gap-4 md:grid-cols-3">
                {/* AutoCount Supplier Dropdown */}
                <div className="md:col-span-3">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    AutoCount Supplier
                  </label>
                  <AdminSelect
                    value={options.suppliers.some((supplier) => supplier.code === form.supplierCode) ? form.supplierCode : ""}
                    onChange={(event) => selectSupplier(event.target.value)}
                    className="w-full text-xs font-medium"
                  >
                    <option value="">-- Select AutoCount Supplier / Creditor --</option>
                    {options.suppliers.map((supplier) => (
                      <option key={supplier.code} value={supplier.code}>
                        {supplier.code} · {supplier.name}
                      </option>
                    ))}
                  </AdminSelect>
                </div>

                {/* Supplier Code */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Supplier Code
                  </label>
                  <input
                    value={form.supplierCode}
                    onChange={(event) => setForm({ ...form, supplierCode: event.target.value.toUpperCase() })}
                    placeholder="Required for AutoCount"
                    className="w-full rounded-xl border border-slate-200 bg-slate-50/70 px-3.5 py-2.5 text-xs font-bold text-slate-800 uppercase focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {/* Supplier Name */}
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Supplier Name
                  </label>
                  <input
                    value={form.supplierName}
                    onChange={(event) => setForm({ ...form, supplierName: event.target.value })}
                    placeholder="Enter supplier company name"
                    className="w-full rounded-xl border border-slate-200 bg-slate-50/70 px-3.5 py-2.5 text-xs font-medium text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {/* Selected Supplier Details Info Banner */}
                {selectedSupplier ? (
                  <div className="md:col-span-3 grid gap-3 rounded-xl border border-blue-100 bg-blue-50/50 p-3.5 text-xs text-slate-700 sm:grid-cols-4">
                    <div>
                      <span className="text-[10px] font-bold uppercase text-slate-400">Contact Person</span>
                      <p className="font-semibold text-slate-800 truncate">{selectedSupplier.contact || "—"}</p>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold uppercase text-slate-400">Phone</span>
                      <p className="font-semibold text-slate-800 truncate">{selectedSupplier.phone || "—"}</p>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold uppercase text-slate-400">Payment Term</span>
                      <p className="font-semibold text-slate-800 truncate">{selectedSupplier.paymentTerm || "30 Days"}</p>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold uppercase text-slate-400">Credit Limit</span>
                      <p className="font-semibold text-slate-800 truncate">{selectedSupplier.currency || "MYR"} {money(selectedSupplier.creditLimit)}</p>
                    </div>
                    {selectedSupplier.address ? (
                      <p className="text-[11px] text-slate-500 sm:col-span-4 border-t border-blue-100/60 pt-2 mt-1">
                        📍 {selectedSupplier.address}
                      </p>
                    ) : null}
                  </div>
                ) : null}

                {/* Order Date */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Order Date
                  </label>
                  <DesktopDatePicker
                    value={form.orderDate}
                    onChange={(value) => setForm({ ...form, orderDate: value })}
                    ariaLabel="Choose purchase order date"
                    className="h-10 text-xs bg-slate-50"
                  />
                </div>

                {/* Estimated Arrival Date */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Estimated Arrival (ETA)
                  </label>
                  <DesktopDatePicker
                    value={form.estimatedArrivalDate}
                    onChange={(value) => setForm({ ...form, estimatedArrivalDate: value })}
                    ariaLabel="Choose estimated arrival date"
                    className="h-10 text-xs border-amber-200 bg-amber-50/50"
                  />
                </div>

                {/* Remind Before */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Arrival Reminder
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min="0"
                      max="30"
                      value={form.reminderDays}
                      onChange={(event) => setForm({ ...form, reminderDays: Number(event.target.value) })}
                      className="w-full rounded-xl border border-slate-200 bg-slate-50/70 px-3.5 py-2.5 pr-28 text-xs font-semibold text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[11px] text-slate-400">
                      days before ETA
                    </span>
                  </div>
                </div>

                {/* Related Work Order */}
                <div className="md:col-span-3">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Related Work Order (Optional)
                  </label>
                  <AdminSelect
                    value={form.workOrderId || ""}
                    onChange={(event) => setForm({ ...form, workOrderId: event.target.value ? Number(event.target.value) : null })}
                    className="w-full text-xs"
                  >
                    <option value="">General inventory purchase (Not tied to specific work order)</option>
                    {options.workOrders.map((job) => (
                      <option key={job.id} value={job.id}>
                        {job.workOrderNo} · {job.companyName}
                      </option>
                    ))}
                  </AdminSelect>
                </div>
              </div>
            </section>

            {/* Section 2: Parts & Item Lines */}
            <section className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-sm space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-blue-50 text-[#1e3a8a]">
                    <Layers className="h-4 w-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-slate-900">2. Order Item Lines</h3>
                      <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-600">
                        {form.items.length} Line(s)
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500">
                      {form.supplierCode
                        ? linkedParts.length > 0
                          ? `Showing ${linkedParts.length} linked item(s) for ${form.supplierName || form.supplierCode}`
                          : "Full parts catalogue and custom item lines available."
                        : "Select parts from catalogue or add custom item lines."}
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                {form.items.map((item, index) => {
                  const lineTotal = Number(item.quantity || 0) * Number(item.unitCost || 0);
                  const lineTax = lineTotal * (Number(item.taxRate || 0) / 100);
                  const lineGrandTotal = lineTotal + lineTax;

                  return (
                    <div
                      key={item.id || index}
                      className="rounded-2xl border border-slate-200 bg-slate-50/60 p-4 sm:p-5 transition-all hover:border-slate-300 hover:bg-slate-50/90 shadow-sm space-y-3.5"
                    >
                      {/* Item Line Header */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-100 text-[11px] font-bold text-[#1e3a8a]">
                            #{index + 1}
                          </span>
                          <span className="text-xs font-bold text-slate-700">
                            {item.description || item.itemCode || "New Item"}
                          </span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="text-right">
                            <span className="text-[10px] uppercase font-bold text-slate-400 mr-1.5">Line Total</span>
                            <span className="text-xs font-extrabold text-[#1e3a8a]">
                              RM {money(lineGrandTotal)}
                            </span>
                          </div>
                          {form.items.length > 1 ? (
                            <button
                              type="button"
                              onClick={() => setForm({ ...form, items: form.items.filter((_, itemIndex) => itemIndex !== index) })}
                              className="rounded-lg p-1.5 text-rose-500 hover:bg-rose-50 hover:text-rose-700 transition-colors cursor-pointer"
                              aria-label="Remove line"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          ) : null}
                        </div>
                      </div>

                      {/* Item Selector & SKU Row */}
                      <div className="grid gap-2.5 sm:grid-cols-[1fr_220px]">
                        <div>
                          <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">
                            Search / Select from Stock Catalogue
                          </label>
                          <DocumentItemCatalogSelect
                            itemType="part"
                            code={item.itemCode}
                            parts={catalogParts}
                            services={[]}
                            onSelect={(selection) => {
                              const matchedPart = options.parts.find(
                                (p) =>
                                  (p.sku && p.sku.toUpperCase() === selection.code.toUpperCase()) ||
                                  (p.name && p.name.trim().toUpperCase() === selection.description.trim().toUpperCase())
                              );
                              const resolvedCost = Number(
                                (matchedPart?.cost !== undefined && matchedPart.cost > 0)
                                  ? matchedPart.cost
                                  : ((matchedPart as any)?.price !== undefined && (matchedPart as any).price > 0)
                                  ? (matchedPart as any).price
                                  : (selection.unitPrice || 0)
                              );
                              updateItem(index, {
                                partId: matchedPart?.id || null,
                                itemCode: selection.code,
                                description: selection.description,
                                uom: matchedPart?.uom || item.uom || "PCS",
                                unitCost: resolvedCost,
                              });
                              if (matchedPart?.supplierCode && !form.supplierCode) {
                                setForm((current) =>
                                  current
                                    ? {
                                        ...current,
                                        supplierCode: matchedPart.supplierCode,
                                        supplierName: matchedPart.supplierName || matchedPart.supplier,
                                      }
                                    : current
                                );
                              }
                            }}
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">
                            Item Code (AutoCount SKU)
                          </label>
                          <input
                            value={item.itemCode}
                            onChange={(event) => {
                              const code = event.target.value.toUpperCase();
                              const matched = options.parts.find((p) => p.sku && p.sku.toUpperCase() === code.trim());
                              if (matched) {
                                const resolvedCost = Number(
                                  (matched.cost !== undefined && matched.cost > 0)
                                    ? matched.cost
                                    : ((matched as any).price !== undefined && (matched as any).price > 0)
                                    ? (matched as any).price
                                    : 0
                                );
                                updateItem(index, {
                                  itemCode: code,
                                  partId: matched.id,
                                  description: matched.name,
                                  uom: matched.uom || "PCS",
                                  unitCost: resolvedCost,
                                });
                                if (matched.supplierCode && !form.supplierCode) {
                                  setForm((current) =>
                                    current
                                      ? {
                                          ...current,
                                          supplierCode: matched.supplierCode,
                                          supplierName: matched.supplierName || matched.supplier,
                                        }
                                      : current
                                  );
                                }
                              } else {
                                updateItem(index, { itemCode: code });
                              }
                            }}
                            placeholder="e.g. 079567600114"
                            className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-800 uppercase focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                      </div>

                      {/* Description */}
                      <div>
                        <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">
                          Item Description
                        </label>
                        <input
                          value={item.description}
                          onChange={(event) => updateItem(index, { description: event.target.value })}
                          placeholder="Detailed part description or specification"
                          className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>

                      {/* 5-Column Numeric Grid */}
                      <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
                        <div>
                          <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">
                            UOM
                          </label>
                          <input
                            value={item.uom}
                            onChange={(event) => updateItem(index, { uom: event.target.value.toUpperCase() })}
                            placeholder="UNIT"
                            className="w-full rounded-lg border border-slate-200 bg-white px-2.5 py-2 text-center text-xs font-bold uppercase focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">
                            QTY (Ordered)
                          </label>
                          <input
                            type="number"
                            min="1"
                            step="1"
                            value={item.quantity}
                            onChange={(event) => updateItem(index, { quantity: Math.max(1, Number(event.target.value)) })}
                            className="w-full rounded-lg border border-slate-200 bg-white px-2.5 py-2 text-center text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">
                            Unit Cost (RM)
                          </label>
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            value={item.unitCost}
                            onChange={(event) => updateItem(index, { unitCost: Number(event.target.value) })}
                            className="w-full rounded-lg border border-slate-200 bg-white px-2.5 py-2 text-right text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">
                            Tax Rate
                          </label>
                          <AdminSelect
                            value={item.taxRate}
                            onChange={(event) => updateItem(index, { taxRate: Number(event.target.value) })}
                            className="w-full text-xs"
                          >
                            <option value={0}>0%</option>
                            <option value={8}>8% (SV-8)</option>
                          </AdminSelect>
                        </div>
                        <div className="col-span-2 sm:col-span-1">
                          <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">
                            Tax Code
                          </label>
                          <input
                            value={item.taxCode}
                            onChange={(event) => updateItem(index, { taxCode: event.target.value.toUpperCase() })}
                            placeholder="AutoCount"
                            className="w-full rounded-lg border border-slate-200 bg-white px-2.5 py-2 text-center text-xs font-medium uppercase focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}

                <button
                  type="button"
                  onClick={() => setForm({ ...form, items: [...form.items, blankItem()] })}
                  className="flex w-full items-center justify-center gap-2 rounded-xl border-2 border-dashed border-slate-200 py-3 text-xs font-bold text-[#1e3a8a] transition-colors hover:border-blue-300 hover:bg-blue-50/50 cursor-pointer"
                >
                  <Plus className="h-4 w-4" />
                  Add Another Item Line
                </button>
              </div>
            </section>

            {/* Section 3: Notes & Financial Grand Totals */}
            <section className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-sm">
              <div className="grid gap-6 md:grid-cols-[1fr_320px] items-start">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Internal Notes / Remarks
                  </label>
                  <textarea
                    rows={4}
                    value={form.notes}
                    onChange={(event) => setForm({ ...form, notes: event.target.value })}
                    placeholder="Enter any instructions, supplier references or internal notes..."
                    className="w-full rounded-xl border border-slate-200 bg-slate-50/70 p-3.5 text-xs text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                  />
                </div>

                <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-3">
                  <h4 className="text-xs font-extrabold uppercase tracking-wide text-slate-500 border-b border-slate-200/80 pb-2">
                    PO Financial Summary
                  </h4>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between text-slate-600">
                      <span>Subtotal</span>
                      <span className="font-bold text-slate-800">RM {money(totals.subtotal)}</span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>SST Tax</span>
                      <span className="font-bold text-slate-800">RM {money(totals.tax)}</span>
                    </div>
                    <div className="border-t border-slate-200 pt-2.5 flex justify-between items-baseline">
                      <span className="text-xs font-bold text-slate-900">Total Order</span>
                      <span className="text-xl font-extrabold text-[#1e3a8a]">
                        RM {money(totals.total)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Sticky Action Footer */}
            <div className="sticky bottom-4 z-10 flex flex-col-reverse gap-3 rounded-2xl border border-slate-200 bg-white/95 p-4 shadow-lg backdrop-blur-md sm:flex-row sm:items-center sm:justify-between sm:px-6">
              <button
                type="button"
                onClick={() => setForm(null)}
                className="h-11 rounded-xl border border-slate-200 bg-white px-5 text-xs font-bold text-slate-700 shadow-sm hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <div className="flex flex-wrap items-center justify-end gap-2.5">
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => void save()}
                  className="h-11 rounded-xl border border-blue-200 bg-white px-5 text-xs font-bold text-[#1e3a8a] shadow-sm hover:bg-blue-50 disabled:opacity-50 cursor-pointer"
                >
                  Save Draft
                </button>
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => void save("local")}
                  className="h-11 rounded-xl bg-slate-700 px-5 text-xs font-bold text-white shadow-sm hover:bg-slate-800 disabled:opacity-50 cursor-pointer"
                >
                  Confirm without Sync
                </button>
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => void save("autocount")}
                  className="h-11 rounded-xl bg-[#1e3a8a] px-6 text-xs font-bold text-white shadow-sm hover:bg-blue-800 disabled:opacity-50 cursor-pointer flex items-center gap-2"
                >
                  <RefreshCw className={`h-4 w-4 ${saving ? "animate-spin" : ""}`} />
                  Confirm &amp; Sync AutoCount
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (viewOrder) {
    return (
      <div className="space-y-4">
        {/* Unified Card Frame */}
        <div className="flex w-full flex-col overflow-hidden rounded-2xl border border-slate-200 bg-slate-100 shadow-sm">
          {/* Header with Back Button */}
          <header className="no-print flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 bg-white px-5 py-4 sm:px-7 sm:py-5">
            <div className="flex flex-wrap items-center gap-3.5">
              <button
                type="button"
                onClick={() => {
                  if (receiving) {
                    setReceiving(null);
                  } else {
                    setViewOrder(null);
                    setReceiving(null);
                  }
                }}
                className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50 cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" />
                {receiving ? "Back to Purchase Order" : "Back to Purchase Orders"}
              </button>
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
                <PackageCheck className="h-5 w-5" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-lg font-extrabold text-slate-900">
                    {viewOrder.autocountPoNo || viewOrder.internalRef}
                  </h2>
                  <span className={`rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase ${statusClass(viewOrder.status)}`}>
                    {viewOrder.status.replaceAll("_", " ")}
                  </span>
                  <span className={`rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase ${viewOrder.syncStatus === "failed" ? "bg-rose-100 text-rose-700" : "bg-slate-100 text-slate-600"}`}>
                    AutoCount: {viewOrder.syncStatus.replaceAll("_", " ")}
                  </span>
                </div>
                <p className="mt-0.5 text-xs text-slate-500">
                  {receiving ? "Record received quantities and update real-time workshop inventory." : `${viewOrder.supplierName} · ETA ${viewOrder.estimatedArrivalDate}`}
                </p>
              </div>
            </div>
            <div>
              {canManage && ["ordered", "partially_received"].includes(viewOrder.status) && !receiving ? (
                <button
                  type="button"
                  onClick={() => openReceiving(viewOrder)}
                  className="inline-flex h-10 items-center gap-2 rounded-xl bg-emerald-600 px-4 text-xs font-bold text-white shadow-sm hover:bg-emerald-700 transition-colors cursor-pointer"
                >
                  <PackageCheck className="h-4 w-4" />
                  Receive Parts
                </button>
              ) : null}
            </div>
          </header>

          <div className="p-4 sm:p-6 space-y-6">
            {viewOrder.syncError ? (
              <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-xs text-rose-700">
                <strong>AutoCount sync failed:</strong> {viewOrder.syncError}
              </div>
            ) : null}

            {/* Supplier & Work Order Meta Grid */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <div>
                <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider">Supplier</span>
                <p className="mt-1 text-sm font-bold text-slate-900">{viewOrder.supplierName}</p>
                <p className="text-xs text-slate-500">{viewOrder.supplierCode || "No code"}</p>
              </div>
              <div>
                <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider">Work Order</span>
                <p className="mt-1 text-sm font-bold text-blue-700">{viewOrder.workOrderNo || "General stock purchase"}</p>
              </div>
              <div>
                <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider">Arrival Schedule</span>
                <p className="mt-1 text-sm font-bold text-slate-900">{viewOrder.estimatedArrivalDate}</p>
                <p className={`text-xs ${arrivalLabel(viewOrder).includes("overdue") ? "font-bold text-rose-600" : "text-slate-500"}`}>
                  {arrivalLabel(viewOrder)}
                </p>
              </div>
            </div>

            {/* Items List */}
            <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="text-sm font-bold text-slate-900">Order Items &amp; Receiving Progress</h3>
                <span className="text-xs font-bold text-slate-500">{viewOrder.items.length} item(s)</span>
              </div>

              <div className="space-y-3">
                {viewOrder.items.map((item, index) => (
                  <div
                    key={item.id || index}
                    className="grid grid-cols-1 gap-3 rounded-xl border border-slate-100 bg-slate-50/80 p-4 sm:grid-cols-[1fr_130px_160px] items-center"
                  >
                    <div>
                      <p className="text-sm font-bold text-slate-900">
                        {item.itemCode ? <span className="font-mono text-blue-700 mr-1.5">{item.itemCode}</span> : null}
                        {item.description}
                      </p>
                      <div className="mt-1 flex items-center gap-3 text-xs text-slate-500">
                        <span>Ordered: <strong className="text-slate-700">{item.quantity} {item.uom}</strong></span>
                        <span>·</span>
                        <span>Received: <strong className={item.receivedQuantity >= item.quantity ? "text-emerald-700 font-bold" : "text-amber-700 font-bold"}>{item.receivedQuantity} {item.uom}</strong></span>
                      </div>
                    </div>
                    <div className="sm:text-right">
                      <span className="text-[10px] uppercase font-bold text-slate-400 block sm:hidden">Amount</span>
                      <p className="text-sm font-bold text-slate-900">
                        RM {money(item.amount || item.quantity * item.unitCost)}
                      </p>
                    </div>
                    {receiving && item.id ? (
                      <div>
                        <label className="block text-[10px] font-bold uppercase text-emerald-700 mb-1">
                          Receive Quantity Now
                        </label>
                        <input
                          type="number"
                          min={item.receivedQuantity}
                          max={item.quantity}
                          step="1"
                          value={receiving[item.id] ?? item.receivedQuantity}
                          onChange={(event) => setReceiving({ ...receiving, [item.id!]: Number(event.target.value) })}
                          className="w-full rounded-lg border border-emerald-300 bg-white px-3 py-2 text-xs font-bold text-emerald-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        />
                      </div>
                    ) : (
                      <div className="text-right">
                        {item.receivedQuantity >= item.quantity ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                            <CheckCircle2 className="h-3.5 w-3.5" /> Fully Received
                          </span>
                        ) : item.receivedQuantity > 0 ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200">
                            <Clock className="h-3.5 w-3.5" /> Partially Arrived
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-full">
                            Pending Arrival
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Financial Totals */}
              <div className="flex justify-end gap-6 border-t border-slate-100 pt-4 text-xs font-medium">
                <span>Subtotal: <strong className="text-slate-800">RM {money(viewOrder.subtotal)}</strong></span>
                <span>Tax: <strong className="text-slate-800">RM {money(viewOrder.taxAmount)}</strong></span>
                <span className="text-sm font-extrabold text-[#1e3a8a]">Total: <strong>RM {money(viewOrder.total)}</strong></span>
              </div>
            </div>

            {/* Action Bar */}
            {receiving ? (
              <div className="sticky bottom-4 z-10 flex flex-col-reverse gap-3 rounded-2xl border border-slate-200 bg-white/95 p-4 shadow-lg backdrop-blur-md sm:flex-row sm:items-center sm:justify-between sm:px-6">
                <button
                  type="button"
                  onClick={() => setReceiving(null)}
                  className="h-11 rounded-xl border border-slate-200 bg-white px-5 text-xs font-bold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel Receiving
                </button>
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => void saveReceiving()}
                  className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-emerald-600 px-6 text-xs font-bold text-white shadow-sm hover:bg-emerald-700 disabled:opacity-50 cursor-pointer"
                >
                  <PackageCheck className="h-4 w-4" />
                  {saving ? "Saving..." : "Save Receiving & Update Inventory"}
                </button>
              </div>
            ) : (
              <div className="flex justify-end rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                <button
                  type="button"
                  onClick={() => { setViewOrder(null); setReceiving(null); }}
                  className="h-10 rounded-xl border border-slate-200 bg-white px-6 text-xs font-bold text-slate-700 shadow-sm hover:bg-slate-50 cursor-pointer"
                >
                  Back to List
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  const handleExportPurchaseOrders = async () => {
    if (filtered.length === 0) {
      toast.error("No purchase orders available to export.");
      return;
    }

    const columnDefs: ExcelColumnDef[] = [
      { header: "PO Number", key: "poNumber", align: "left", minWidth: 18, numFmt: "@" },
      { header: "AutoCount Doc No", key: "autocountDocNo", align: "left", minWidth: 18, numFmt: "@" },
      { header: "Order Date", key: "orderDate", align: "center", minWidth: 14 },
      { header: "Estimated Arrival", key: "estimatedArrivalDate", align: "center", minWidth: 16 },
      { header: "Supplier Code", key: "supplierCode", align: "left", minWidth: 16, numFmt: "@" },
      { header: "Supplier Name", key: "supplierName", align: "left", minWidth: 26 },
      { header: "Linked WO No", key: "workOrderNo", align: "left", minWidth: 16, numFmt: "@" },
      { header: "Items Count", key: "itemsCount", align: "right", minWidth: 13, numFmt: "#,##0" },
      { header: "Subtotal (RM)", key: "subtotal", align: "right", minWidth: 16, numFmt: "#,##0.00" },
      { header: "Tax (RM)", key: "taxAmount", align: "right", minWidth: 14, numFmt: "#,##0.00" },
      { header: "Total Cost (RM)", key: "totalAmount", align: "right", minWidth: 18, numFmt: "#,##0.00" },
      { header: "Status", key: "status", align: "center", minWidth: 14 },
      { header: "AutoCount Sync", key: "syncStatus", align: "center", minWidth: 16 },
    ];

    const rows = filtered.map((po) => ({
      poNumber: String(po.poNumber || `PO-${po.id}`),
      autocountDocNo: String(po.autocountDocNo || "-"),
      orderDate: String(po.orderDate || po.createdAt || "-").slice(0, 10),
      estimatedArrivalDate: po.estimatedArrivalDate ? String(po.estimatedArrivalDate).slice(0, 10) : "-",
      supplierCode: String(po.supplierCode || "-"),
      supplierName: String(po.supplierName || "-"),
      workOrderNo: String(po.workOrderNo || "-"),
      itemsCount: Number(po.items?.length || 0),
      subtotal: Number(po.subtotal ?? 0),
      taxAmount: Number(po.taxAmount ?? 0),
      totalAmount: Number(po.totalAmount ?? 0),
      status: String(po.status || "-").toUpperCase(),
      syncStatus: String(po.syncStatus || "-").toUpperCase(),
    }));

    const fileName = `maw-purchase-orders-${new Date().toISOString().slice(0, 10)}.xlsx`;
    await exportTableToExcel({
      fileName,
      sheetName: "Purchase Orders",
      columns: columnDefs,
      data: rows,
      successMessage: `Exported ${filtered.length} purchase orders to ${fileName}`,
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-2xl font-extrabold text-slate-900">Purchase Orders</h1>
            <AutoCountSyncBadge
              label="AutoCount Supplier POs"
              onRefresh={() => void reload()}
              isRefreshing={isLoading}
            />
          </div>
          <p className="mt-0.5 text-xs text-slate-500">
            Supplier procurement, ETA tracking, and AutoCount PO synchronization
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportPurchaseOrders}
            disabled={isLoading || filtered.length === 0}
            className="inline-flex h-10 items-center justify-center rounded-xl border border-gray-300 bg-white px-4 text-sm font-semibold text-gray-700 shadow-sm transition-colors hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Download className="mr-2 h-4 w-4" />
            Export Excel
          </button>
          {canManage ? (
            <button
              type="button"
              onClick={() => void openCreate()}
              className="inline-flex h-10 items-center justify-center rounded-xl bg-[#1e3a8a] px-4 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-blue-800"
            >
              <Plus className="mr-2 h-4 w-4" />
              New Purchase Order
            </button>
          ) : null}
        </div>
      </div>
      {error ? (
        <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">
          Purchase Orders are unavailable: {error}
        </div>
      ) : null}
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "Open POs", value: orders.filter((item) => !["received", "cancelled"].includes(item.status)).length },
          { label: "Arriving soon", value: orders.filter((item) => !["received", "cancelled", "draft"].includes(item.status) && daysUntilArrival(item) >= 0 && daysUntilArrival(item) <= item.reminderDays).length },
          { label: "Overdue", value: orders.filter((item) => !["received", "cancelled", "draft"].includes(item.status) && daysUntilArrival(item) < 0).length },
          { label: "Pending Sync", value: orders.filter((item) => ["queued", "processing", "failed"].includes(item.syncStatus)).length }
        ].map((item) => (
          <div key={item.label} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <p className="text-xs font-bold uppercase text-slate-500">{item.label}</p>
            <p className="mt-3 text-2xl font-extrabold text-slate-900">{item.value}</p>
          </div>
        ))}
      </div>
      <div className="maw-filter-bar">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
          <div className="md:col-span-2">
            <div className="maw-search-field">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search PO, supplier, job or part..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
              />
            </div>
          </div>
          <div>
            <AdminSelect
              value={status}
              onChange={(event) => setStatus(event.target.value)}
              className="w-full"
              aria-label="Filter PO status"
            >
              <option value="all">All statuses</option>
              <option value="draft">Draft</option>
              <option value="pending_sync">Pending Sync</option>
              <option value="ordered">Ordered</option>
              <option value="partially_received">Partially Received</option>
              <option value="received">Received</option>
              <option value="cancelled">Cancelled</option>
            </AdminSelect>
          </div>
        </div>
      </div>
      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200">
            <thead className="bg-slate-50">
              <tr>
                {["PO No.", "Supplier", "Work Order", "Order Date", "Estimated Arrival", "Total", "Status / Sync", ""].map((heading) => (
                  <th key={heading} className="px-4 py-3 text-left text-[11px] font-extrabold uppercase text-slate-500">
                    {heading}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {isLoading ? (
                <tr>
                  <td colSpan={8} className="p-12 text-center text-sm text-slate-500">
                    Loading Purchase Orders...
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-12 text-center text-sm text-slate-500">
                    No Purchase Orders found.
                  </td>
                </tr>
              ) : (
                filtered.map((order) => (
                  <tr key={order.id} className="hover:bg-slate-50">
                    <td className="px-4 py-4">
                      <p className="text-sm font-extrabold text-slate-900">{order.autocountPoNo || order.internalRef}</p>
                      {order.autocountPoNo ? <p className="text-[10px] text-slate-400">{order.internalRef}</p> : null}
                    </td>
                    <td className="px-4 py-4">
                      <p className="text-sm font-semibold text-slate-800">{order.supplierName}</p>
                      <p className="text-xs text-slate-500">{order.supplierCode || "No supplier code"}</p>
                    </td>
                    <td className="px-4 py-4 text-sm font-bold text-blue-700">{order.workOrderNo || "—"}</td>
                    <td className="px-4 py-4 text-sm text-slate-600">{order.orderDate}</td>
                    <td className="px-4 py-4">
                      <p className="text-sm font-bold text-slate-800">{order.estimatedArrivalDate}</p>
                      <p className={`text-xs ${arrivalLabel(order).includes("overdue") ? "font-bold text-rose-600" : "text-slate-500"}`}>
                        {arrivalLabel(order)}
                      </p>
                    </td>
                    <td className="px-4 py-4 text-sm font-bold">RM {money(order.total)}</td>
                    <td className="px-4 py-4">
                      <span className={`rounded-full px-2 py-1 text-[10px] font-bold uppercase ${statusClass(order.status)}`}>
                        {order.status.replaceAll("_", " ")}
                      </span>
                      <p className={`mt-1 text-[10px] font-bold uppercase ${order.syncStatus === "failed" ? "text-rose-600" : "text-slate-500"}`}>
                        AutoCount: {order.syncStatus.replaceAll("_", " ")}
                      </p>
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex justify-end gap-1">
                        {order.status === "draft" && canManage ? (
                          <button
                            type="button"
                            onClick={() => void openDraft(order)}
                            className="rounded-lg p-2 text-blue-700 hover:bg-blue-50"
                            aria-label={`Edit ${order.internalRef}`}
                          >
                            <Eye className="h-4 w-4" />
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => { setViewOrder(order); setReceiving(null); }}
                            className="rounded-lg p-2 text-blue-700 hover:bg-blue-50"
                            aria-label={`View ${order.internalRef}`}
                          >
                            <Eye className="h-4 w-4" />
                          </button>
                        )}
                        {canManage && ["ordered", "partially_received"].includes(order.status) ? (
                          <button
                            type="button"
                            onClick={() => openReceiving(order)}
                            className="rounded-lg p-2 text-emerald-700 hover:bg-emerald-50"
                            aria-label={`Receive ${order.internalRef}`}
                          >
                            <PackageCheck className="h-4 w-4" />
                          </button>
                        ) : null}
                        {canManage && order.syncStatus === "failed" ? (
                          <button
                            type="button"
                            disabled={saving}
                            onClick={() => void retrySync(order)}
                            className="rounded-lg p-2 text-amber-700 hover:bg-amber-50"
                            aria-label={`Retry sync ${order.internalRef}`}
                          >
                            <RefreshCw className="h-4 w-4" />
                          </button>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
