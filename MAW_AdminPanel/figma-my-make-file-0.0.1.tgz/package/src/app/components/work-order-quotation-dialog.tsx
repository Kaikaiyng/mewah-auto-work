import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, CheckCircle2, FileDown, FileText, Plus, Printer, Send, Trash2 } from "lucide-react";
import { toast } from "sonner";
import logo from "../../MAW_logo.png";
import { apiRequest, postApi } from "../lib/api";
import {
  DocumentItemCatalogSelect,
  type DocumentCatalogPart,
} from "./ui/document-item-catalog-select";
import { AdminSelect } from "./ui/admin-select";
import { DesktopDatePicker } from "./ui/desktop-date-picker";

export type QuotationItem = {
  id?: number;
  type: "part" | "labour" | "other";
  serviceTypeId?: number | null;
  code: string;
  description: string;
  quantity: number;
  unitPrice: number;
  amount?: number;
};

export type WorkOrderQuotation = {
  id: number;
  workOrderId: number;
  quotationNo: string;
  debtorCode?: string;
  revision: number;
  status: "draft" | "issued" | "approved" | "rejected";
  validUntil: string | null;
  subtotal: number;
  discount: number;
  taxRate: number;
  taxAmount: number;
  total: number;
  notes: string;
  terms: string;
  customerResponseNote: string;
  createdAt: string;
  updatedAt: string;
  issuedAt: string | null;
  approvedAt: string | null;
  rejectedAt: string | null;
  items: QuotationItem[];
};

export type QuotationWorkOrder = {
  id: number;
  workOrderNo: string;
  canonicalStatus: string;
  companyName: string;
  contactName: string;
  customerPhone: string;
  vehicleNo: string;
  brand: string;
  model: string;
  equipmentType: string;
  serviceType: string;
};

type EditableQuote = {
  date: string;
  validUntil: string;
  debtorCode: string;
  vehicleType: string;
  vehicleNo: string;
  discount: number;
  taxRate: number;
  notes: string;
  terms: string;
  items: QuotationItem[];
};

type InspectionPartRequirement = {
  id?: number;
  partId: number | null;
  code: string;
  description: string;
  uom: string;
  quantity: number;
  unitPrice: number;
};

type DocumentSettings = {
  company: {
    legalName: string;
    registrationNo: string;
    groupName: string;
    address: string;
    phone: string;
    email: string;
    operatingHours: string;
  };
  pricing: { taxRate: number };
  serviceTypes: ServiceTypeOption[];
};

type ServiceTypeOption = {
  id: number;
  name: string;
  description: string;
  basePrice: number;
  enabled: boolean;
  sortOrder: number;
};

type AutoCountDebtor = {
  code: string;
  name: string;
  term?: string;
};

const defaultDocumentSettings: DocumentSettings = {
  company: {
    legalName: "MEWAH AUTOWORKS SDN BHD",
    registrationNo: "202101006611 (1406910-T)",
    groupName: "A MEMBER OF SHIN YANG GROUP BERHAD",
    address: "NO. 31, JALAN MOLEK 1/42, TAMAN MOLEK, 81100 JOHOR BAHRU, JOHOR",
    phone: "+60 7-352 6677",
    email: "info@mewahautoworks.com",
    operatingHours: "Monday - Saturday, 8:00 AM - 6:00 PM",
  },
  pricing: { taxRate: 0 },
  serviceTypes: [],
};

const DEFAULT_TERMS = "Quotation is valid until the date stated above. Additional work requires customer approval. Prices may change if inspection reveals additional parts or labour.";

function today() {
  return new Date().toISOString().slice(0, 10);
}

function futureDate(days: number) {
  const value = new Date();
  value.setDate(value.getDate() + days);
  return value.toISOString().slice(0, 10);
}

function blankQuote(taxRate = 0): EditableQuote {
  return {
    date: today(),
    validUntil: futureDate(14),
    debtorCode: "",
    vehicleType: "",
    vehicleNo: "",
    discount: 0,
    taxRate,
    notes: "",
    terms: DEFAULT_TERMS,
    items: [{ type: "part", code: "", description: "", quantity: 1, unitPrice: 0 }],
  };
}

function money(value: number) {
  return Number(value || 0).toLocaleString("en-MY", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function displayDate(value?: string | null) {
  if (!value) return "—";
  const normalized = value.includes("T") ? value : value.includes(" ") ? value.replace(" ", "T") : `${value}T00:00:00`;
  const date = new Date(normalized);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString("en-GB");
}

function statusClass(status: string) {
  const classes: Record<string, string> = {
    draft: "bg-slate-100 text-slate-700",
    issued: "bg-blue-100 text-blue-700",
    approved: "bg-emerald-100 text-emerald-700",
    rejected: "bg-rose-100 text-rose-700",
  };
  return classes[status] || classes.draft;
}

export function WorkOrderQuotationDialog({
  workOrder,
  canManage,
  onClose,
  onChanged,
  backLabel = "Back to Work Orders",
}: {
  workOrder: QuotationWorkOrder;
  canManage: boolean;
  onClose: () => void;
  onChanged: () => void | Promise<void>;
  backLabel?: string;
}) {
  const [quotation, setQuotation] = useState<WorkOrderQuotation | null>(null);
  const [form, setForm] = useState<EditableQuote>(() => ({
    ...blankQuote(),
    vehicleType: workOrder.equipmentType || [workOrder.brand, workOrder.model].filter(Boolean).join(" "),
    vehicleNo: workOrder.vehicleNo || "",
  }));
  const [documentSettings, setDocumentSettings] = useState<DocumentSettings>(defaultDocumentSettings);
  const [catalogParts, setCatalogParts] = useState<DocumentCatalogPart[]>([]);
  const [debtors, setDebtors] = useState<AutoCountDebtor[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    setLoading(true);
    Promise.all([
      apiRequest<WorkOrderQuotation | null>(`admin-get-work-order-quotation&id=${workOrder.id}`),
      apiRequest<DocumentSettings>("admin-system-settings").catch(() => null),
      apiRequest<DocumentCatalogPart[]>("admin-parts").catch(() => []),
      apiRequest<InspectionPartRequirement[]>(`admin-get-work-order-part-requirements&id=${workOrder.id}`).catch(() => []),
      apiRequest<AutoCountDebtor[]>("admin-autocount-debtors").catch(() => []),
    ])
      .then(([data, loadedSettings, loadedParts, inspectionParts, loadedDebtors]) => {
        if (!active) return;
        if (loadedSettings) setDocumentSettings(loadedSettings);
        setCatalogParts(loadedParts);
        setDebtors(loadedDebtors);
        setQuotation(data);

        // Try auto-matching debtor code from server or AutoCount debtors
        const serverDebtorCode = (data as any)?.debtorCode || "";
        const matchedDebtor = loadedDebtors.find(
          (d) =>
            (serverDebtorCode && d.code.toUpperCase() === serverDebtorCode.toUpperCase()) ||
            d.name.trim().toLowerCase() === (workOrder.companyName || "").trim().toLowerCase() ||
            (workOrder.companyName || "").trim().toLowerCase().includes(d.name.trim().toLowerCase())
        );
        const resolvedDebtorCode = serverDebtorCode || matchedDebtor?.code || "";

        if (data && data.id > 0) {
          const createdAtDate = data.createdAt ? data.createdAt.slice(0, 10) : today();
          setForm({
            date: createdAtDate,
            validUntil: data.validUntil || futureDate(14),
            debtorCode: resolvedDebtorCode,
            vehicleType: workOrder.equipmentType || [workOrder.brand, workOrder.model].filter(Boolean).join(" "),
            vehicleNo: workOrder.vehicleNo || "",
            discount: data.discount,
            taxRate: data.taxRate,
            notes: data.notes,
            terms: data.terms || DEFAULT_TERMS,
            items: data.items.map((item) => ({ ...item })),
          });
        } else if (inspectionParts.length > 0) {
          const nextForm: EditableQuote = {
            ...blankQuote(loadedSettings?.pricing?.taxRate || 0),
            debtorCode: resolvedDebtorCode,
            vehicleType: workOrder.equipmentType || [workOrder.brand, workOrder.model].filter(Boolean).join(" "),
            vehicleNo: workOrder.vehicleNo || "",
            items: inspectionParts.map((item) => ({
              type: "part",
              code: item.code,
              description: item.description,
              quantity: item.quantity,
              unitPrice: item.unitPrice,
            })),
          };
          setForm(nextForm);
        } else {
          setForm({
            ...blankQuote(loadedSettings?.pricing?.taxRate || 0),
            debtorCode: resolvedDebtorCode,
            vehicleType: workOrder.equipmentType || [workOrder.brand, workOrder.model].filter(Boolean).join(" "),
            vehicleNo: workOrder.vehicleNo || "",
          });
        }
      })
      .catch((caught) => {
        if (!active) return;
        setError(caught instanceof Error ? caught.message : "Unable to load quotation.");
      })
      .finally(() => {
        if (!active) return;
        setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [workOrder]);

  const catalogBySku = useMemo(() => {
    const map = new Map<string, DocumentCatalogPart>();
    catalogParts.forEach((part) => map.set(part.sku, part));
    return map;
  }, [catalogParts]);

  const totals = useMemo(() => {
    const subtotal = form.items.reduce((sum, item) => sum + Number(item.quantity || 0) * Number(item.unitPrice || 0), 0);
    const discount = Math.min(Math.max(Number(form.discount || 0), 0), subtotal);
    const taxable = Math.max(0, subtotal - discount);
    const taxAmount = Number(form.taxRate || 0) > 0 ? Number(((taxable * Number(form.taxRate || 0)) / 100).toFixed(2)) : 0;
    return {
      subtotal,
      discount,
      taxAmount,
      total: Number((taxable + taxAmount).toFixed(2)),
    };
  }, [form.discount, form.items, form.taxRate]);

  const isEditable = canManage;
  const isDraft = !quotation || quotation.status === "draft";
  const isIssued = quotation?.status === "issued";
  const isApproved = quotation?.status === "approved";
  const isRejected = quotation?.status === "rejected";
  const canIssue = Boolean(canManage && form.items.length > 0);

  const updateItem = (index: number, patch: Partial<QuotationItem>) => {
    setForm((current) => ({
      ...current,
      items: current.items.map((item, itemIndex) => (itemIndex === index ? { ...item, ...patch } : item)),
    }));
  };

  const payload = () => ({
    workOrderId: workOrder.id,
    debtorCode: form.debtorCode,
    validUntil: form.validUntil,
    discount: Number(form.discount || 0),
    taxRate: Number(form.taxRate || 0),
    notes: form.notes,
    terms: form.terms,
    items: form.items.map((item) => ({
      type: item.type || "part",
      serviceTypeId: item.serviceTypeId || null,
      code: (item.code || "").trim(),
      description: (item.description || item.code || "Item").trim(),
      quantity: Number(item.quantity || 1),
      unitPrice: Number(item.unitPrice || 0),
    })),
  });

  const save = async (issue: boolean) => {
    setSaving(true);
    setError("");
    try {
      const saved = await postApi<WorkOrderQuotation>("admin-save-work-order-quotation", payload());
      let nextQuote = saved;
      if (issue) {
        nextQuote = await postApi<WorkOrderQuotation>("admin-issue-work-order-quotation", { workOrderId: workOrder.id });
        toast.success(`Quotation ${nextQuote.quotationNo} issued to customer.`);
      } else {
        toast.success("Quotation updated and saved.");
      }
      setQuotation(nextQuote);
      await onChanged();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Unable to save quotation.");
    } finally {
      setSaving(false);
    }
  };

  const approveInternally = async () => {
    setSaving(true);
    setError("");
    try {
      if (isEditable) {
        await postApi<WorkOrderQuotation>("admin-save-work-order-quotation", payload());
      }
      await postApi("admin-approve-work-order-quotation", { workOrderId: workOrder.id });
      toast.success("Quotation approved. Work order is ready to proceed with repair.");
      await onChanged();
      onClose();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Unable to approve quotation.");
    } finally {
      setSaving(false);
    }
  };

  const shownStatus = quotation?.status || "draft";
  const shownNo = quotation?.quotationNo || "Generated when saved";

  return (
    <div className="quotation-print-shell space-y-4">
      <style>{`@media print {
        @page { size: A4 portrait; margin: 10mm; }
        html, body { height: auto !important; overflow: visible !important; background: #fff !important; }
        #root { display: none !important; }
        body * { visibility: hidden !important; }
        .no-print { display: none !important; }
        .quotation-print-shell, .quotation-print-frame, .quotation-layout, .quotation-stage,
        #quotation-document, #quotation-document * { visibility: visible !important; }
        .quotation-print-shell, .quotation-print-frame, .quotation-layout, .quotation-stage {
          display: block !important; position: static !important; inset: auto !important;
          width: auto !important; height: auto !important; min-height: 0 !important;
          max-width: none !important; max-height: none !important; overflow: visible !important;
          margin: 0 !important; padding: 0 !important; background: #fff !important;
          border: 0 !important; border-radius: 0 !important; box-shadow: none !important;
          transform: none !important; backdrop-filter: none !important;
        }
        #quotation-document {
          position: static !important; width: 100% !important; min-height: 0 !important;
          max-width: none !important; margin: 0 !important; padding: 0 !important;
          border: 0 !important; box-shadow: none !important;
        }
        #quotation-document header, #quotation-document > div { break-inside: avoid-page; }
        #quotation-document table { break-inside: auto; }
        #quotation-document thead { display: table-header-group; }
        #quotation-document tr { break-inside: avoid-page; }
      }`}</style>

      {/* Frame Container */}
      <div className="quotation-print-frame flex w-full flex-col overflow-hidden rounded-2xl border border-slate-200 bg-slate-100 shadow-sm">
        <header className="no-print flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 bg-white px-5 py-4 sm:px-7 sm:py-5">
          <div className="flex flex-wrap items-center gap-3.5">
            <button
              type="button"
              onClick={onClose}
              className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50 cursor-pointer"
            >
              <ArrowLeft className="h-4 w-4" />
              {backLabel}
            </button>
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-[#1e3a8a] ring-1 ring-blue-100">
              <FileText className="h-5 w-5" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg font-extrabold text-slate-900">Quotation · {workOrder.workOrderNo}</h2>
                <span className={`rounded-full px-2.5 py-1 text-[10px] font-bold uppercase ${statusClass(shownStatus)}`}>
                  {shownStatus}
                </span>
              </div>
              <p className="mt-0.5 text-xs text-slate-500">Create, review and issue the repair estimate to the customer.</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {canManage ? (
              <>
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => void save(false)}
                  className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-4 text-xs font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50 disabled:opacity-50 cursor-pointer"
                >
                  <FileDown className="h-4 w-4" />
                  {quotation ? "Update Quotation" : "Save Draft"}
                </button>
                {(!isApproved || isDraft || isIssued || isRejected) && (
                  <button
                    type="button"
                    disabled={saving || !canIssue}
                    onClick={() => void save(true)}
                    className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-[#1e3a8a] px-4 text-xs font-bold text-white shadow-sm transition-colors hover:bg-blue-800 disabled:opacity-50 cursor-pointer"
                  >
                    <Send className="h-4 w-4" />
                    {isIssued ? "Re-issue to Customer" : "Issue to Customer"}
                  </button>
                )}
                {!isApproved && (
                  <button
                    type="button"
                    disabled={saving}
                    onClick={() => void approveInternally()}
                    className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-emerald-600 px-4 text-xs font-bold text-white shadow-sm transition-colors hover:bg-emerald-700 disabled:opacity-50 cursor-pointer"
                  >
                    <CheckCircle2 className="h-4 w-4" />
                    Approve & Proceed to Repair
                  </button>
                )}
                {isApproved && (
                  <button
                    type="button"
                    onClick={onClose}
                    className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-emerald-600 px-4 text-xs font-bold text-white shadow-sm transition-colors hover:bg-emerald-700 cursor-pointer"
                  >
                    <CheckCircle2 className="h-4 w-4" />
                    Quotation Approved (Proceed)
                  </button>
                )}
              </>
            ) : null}
            {quotation ? (
              <button
                type="button"
                onClick={() => window.print()}
                className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 shadow-sm hover:bg-slate-50 cursor-pointer"
                aria-label="Print quotation"
              >
                <Printer className="h-4 w-4" />
                Print Quotation
              </button>
            ) : null}
          </div>
        </header>

        {loading ? (
          <div className="p-16 text-center text-sm text-slate-500">Loading quotation...</div>
        ) : (
          <div className="quotation-layout grid min-h-[780px] flex-1 lg:grid-cols-[470px_minmax(0,1fr)]">
            <aside className="no-print overflow-y-auto border-r border-slate-200 bg-slate-100/80 p-4 sm:p-5">
              {error ? <div className="mb-4 rounded-xl border border-rose-200 bg-rose-50 p-3 text-xs text-rose-700">{error}</div> : null}
              {!canManage ? <div className="mb-4 rounded-xl border border-blue-100 bg-blue-50 p-3 text-xs text-blue-800">View only. Only Admin can create, edit or issue quotations.</div> : null}

              <div className="space-y-5 [&>div:nth-child(n+2):nth-child(-n+4)]:rounded-xl [&>div:nth-child(n+2):nth-child(-n+4)]:border [&>div:nth-child(n+2):nth-child(-n+4)]:border-slate-200 [&>div:nth-child(n+2):nth-child(-n+4)]:bg-white [&>div:nth-child(n+2):nth-child(-n+4)]:p-3 [&>div:nth-child(n+2):nth-child(-n+4)]:shadow-sm [&>div:nth-child(5)]:rounded-2xl [&>div:nth-child(5)]:border [&>div:nth-child(5)]:border-slate-200 [&>div:nth-child(5)]:border-l-4 [&>div:nth-child(5)]:border-l-blue-500 [&>div:nth-child(5)]:bg-white [&>div:nth-child(5)]:p-4 [&>div:nth-child(5)]:shadow-sm [&>div:nth-child(5)>div:first-child]:border-b [&>div:nth-child(5)>div:first-child]:border-slate-100 [&>div:nth-child(5)>div:first-child]:pb-3 [&>label]:rounded-xl [&>label]:border [&>label]:border-slate-200 [&>label]:border-l-4 [&>label]:border-l-slate-300 [&>label]:bg-white [&>label]:p-4 [&>label]:shadow-sm">
                
                {/* Quotation Setup Card */}
                <div className="flex items-start gap-3 rounded-2xl border border-blue-100 bg-blue-50/80 p-4">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#1e3a8a] text-white">
                    <FileText className="h-4 w-4" />
                  </span>
                  <div>
                    <h3 className="text-sm font-extrabold text-slate-900">Quotation setup</h3>
                    <p className="mt-0.5 text-xs leading-5 text-slate-600">Confirm quotation dates, customer details and repair items.</p>
                  </div>
                </div>

                {/* Dates */}
                <div className="grid grid-cols-2 gap-3">
                  <label className="text-xs font-bold text-slate-700">
                    Quotation date
                    <DesktopDatePicker
                      disabled={!isEditable}
                      value={form.date}
                      onChange={(value) => setForm((current) => ({ ...current, date: value }))}
                      ariaLabel="Choose quotation date"
                      className="mt-1 h-10 bg-slate-50"
                    />
                  </label>
                  <label className="text-xs font-bold text-slate-700">
                    Valid until
                    <DesktopDatePicker
                      disabled={!isEditable}
                      value={form.validUntil}
                      onChange={(value) => setForm((current) => ({ ...current, validUntil: value }))}
                      ariaLabel="Choose quotation validity date"
                      className="mt-1 h-10 bg-slate-50"
                    />
                  </label>
                </div>

                {/* Debtor Code & AutoCount Link */}
                <div>
                  <label className="text-xs font-bold text-slate-700">
                    <span className="flex items-center justify-between">
                      <span>Debtor Code</span>
                      {form.debtorCode ? (
                        <span className="text-[10px] text-emerald-600 font-bold">✓ Auto-linked</span>
                      ) : (
                        <span className="text-[10px] text-amber-600 font-bold">Optional reference</span>
                      )}
                    </span>
                    <input
                      list="autocount-quotation-debtors-list"
                      disabled={!isEditable}
                      value={form.debtorCode}
                      onChange={(event) => {
                        const val = event.target.value.toUpperCase();
                        const matched = debtors.find((d) => d.code.toUpperCase() === val || d.name.toUpperCase() === val);
                        setForm((current) => ({
                          ...current,
                          debtorCode: matched ? matched.code : val,
                        }));
                      }}
                      placeholder="Enter or select AutoCount Debtor Code"
                      className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 uppercase font-medium text-xs"
                    />
                    <datalist id="autocount-quotation-debtors-list">
                      {(debtors || []).map((d) => (
                        <option key={d.code} value={d.code}>
                          {d.name} {d.term ? `(${d.term})` : ""}
                        </option>
                      ))}
                    </datalist>
                  </label>
                </div>

                {/* Vehicle Details */}
                <div className="grid grid-cols-2 gap-3">
                  <label className="text-xs font-bold text-slate-700">
                    Vehicle Type
                    <input
                      disabled={!isEditable}
                      value={form.vehicleType}
                      onChange={(event) => setForm((current) => ({ ...current, vehicleType: event.target.value }))}
                      className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs"
                    />
                  </label>
                  <label className="text-xs font-bold text-slate-700">
                    Vehicle No.
                    <input
                      disabled={!isEditable}
                      value={form.vehicleNo}
                      onChange={(event) => setForm((current) => ({ ...current, vehicleNo: event.target.value.toUpperCase() }))}
                      className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 uppercase text-xs"
                    />
                  </label>
                </div>

                {/* Tax Rate & Discount */}
                <div className="grid grid-cols-2 gap-3">
                  <label className="text-xs font-bold text-slate-700">
                    Tax Rate (%)
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="0.01"
                      disabled={!isEditable}
                      value={form.taxRate}
                      onChange={(event) => setForm((current) => ({ ...current, taxRate: Number(event.target.value) }))}
                      className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs"
                    />
                  </label>
                  <label className="text-xs font-bold text-slate-700">
                    Discount (RM)
                    <input
                      type="number"
                      min="0"
                      disabled={!isEditable}
                      value={form.discount}
                      onChange={(event) => setForm((current) => ({ ...current, discount: Number(event.target.value) }))}
                      className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs"
                    />
                  </label>
                </div>

                {/* Items Section */}
                <div>
                  <div className="mb-2 flex items-center justify-between">
                    <h3 className="text-xs font-extrabold uppercase tracking-wide text-slate-500">Quotation items</h3>
                    {isEditable ? (
                      <button
                        type="button"
                        onClick={() =>
                          setForm((current) => ({
                            ...current,
                            items: [...current.items, { type: "part", code: "", description: "", quantity: 1, unitPrice: 0 }],
                          }))
                        }
                        className="inline-flex items-center text-xs font-bold text-blue-700 cursor-pointer"
                      >
                        <Plus className="mr-1 h-3.5 w-3.5" />
                        Add item
                      </button>
                    ) : null}
                  </div>

                  <div className="space-y-3">
                    {form.items.map((item, index) => {
                      const selectedPart = item.type === "part" ? catalogBySku.get(item.code) : undefined;
                      const stockOnHand = Number(selectedPart?.stock || 0);
                      const requiredQuantity = Number(item.quantity || 0);
                      const shortage = Math.max(0, requiredQuantity - stockOnHand);

                      return (
                        <div key={item.id || index} className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                          <div className="mb-2 flex gap-2">
                            <AdminSelect
                              disabled={!isEditable}
                              value={item.type}
                              onChange={(event) => {
                                const newType = event.target.value as QuotationItem["type"];
                                updateItem(index, {
                                  type: newType,
                                  serviceTypeId: null,
                                  code: "",
                                  description: "",
                                  quantity: 1,
                                  unitPrice: 0,
                                });
                              }}
                              className="min-w-0 flex-1 text-xs"
                            >
                              <option value="part">Part</option>
                              <option value="labour">Service / Labour</option>
                              <option value="other">Other</option>
                            </AdminSelect>
                            <input
                              disabled={!isEditable}
                              value={item.code}
                              onChange={(event) => updateItem(index, { code: event.target.value })}
                              placeholder="Item code"
                              className="min-w-0 flex-1 rounded-lg border border-slate-200 bg-white px-2 py-2 text-xs"
                            />
                            {isEditable && form.items.length > 1 ? (
                              <button
                                type="button"
                                onClick={() =>
                                  setForm((current) => ({
                                    ...current,
                                    items: current.items.filter((_, itemIndex) => itemIndex !== index),
                                  }))
                                }
                                className="rounded-lg p-2 text-rose-600 cursor-pointer"
                                aria-label="Remove item"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            ) : null}
                          </div>

                          <DocumentItemCatalogSelect
                            itemType={item.type}
                            serviceTypeId={item.serviceTypeId}
                            code={item.code}
                            disabled={!isEditable}
                            services={documentSettings?.serviceTypes || []}
                            parts={catalogParts}
                            onSelect={(selection) =>
                              updateItem(index, {
                                serviceTypeId: selection.serviceTypeId,
                                code: selection.code,
                                description: selection.description,
                                quantity: 1,
                                unitPrice: selection.unitPrice,
                              })
                            }
                          />

                          {item.type === "part" && item.code ? (
                            <div
                              className={`mt-2 mb-1 grid grid-cols-3 gap-2 rounded-lg border px-3 py-2 text-[10px] ${
                                selectedPart
                                  ? shortage > 0
                                    ? "border-amber-200 bg-amber-50"
                                    : "border-emerald-200 bg-emerald-50"
                                  : "border-slate-200 bg-slate-100"
                              }`}
                            >
                              <div>
                                <p className="font-extrabold uppercase tracking-wide text-slate-500">Stock now</p>
                                <p className="mt-0.5 font-black text-slate-900">{selectedPart ? stockOnHand.toLocaleString() : "Not linked"}</p>
                              </div>
                              <div>
                                <p className="font-extrabold uppercase tracking-wide text-slate-500">Required</p>
                                <p className="mt-0.5 font-black text-slate-900">{requiredQuantity.toLocaleString()}</p>
                              </div>
                              <div>
                                <p className="font-extrabold uppercase tracking-wide text-slate-500">Shortage</p>
                                <p className={`mt-0.5 font-black ${shortage > 0 ? "text-amber-700" : "text-emerald-700"}`}>
                                  {selectedPart ? shortage.toLocaleString() : "—"}
                                </p>
                              </div>
                            </div>
                          ) : null}

                          <textarea
                            disabled={!isEditable}
                            rows={2}
                            value={item.description}
                            onChange={(event) => updateItem(index, { description: event.target.value })}
                            placeholder="Description"
                            className="mt-2 w-full resize-none rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs"
                          />

                          <div className="mt-2 grid grid-cols-3 gap-2">
                            <label className="text-[10px] font-bold text-slate-500">
                              QTY
                              <input
                                type="number"
                                min="1"
                                step="1"
                                disabled={!isEditable}
                                value={item.quantity}
                                onChange={(event) => updateItem(index, { quantity: Math.max(1, Number(event.target.value)) })}
                                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-2 py-2 text-xs font-bold"
                              />
                            </label>
                            <label className="text-[10px] font-bold text-slate-500">
                              UNIT PRICE
                              <input
                                type="number"
                                min="0"
                                step="0.01"
                                disabled={!isEditable}
                                value={item.unitPrice}
                                onChange={(event) => updateItem(index, { unitPrice: Number(event.target.value) })}
                                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-2 py-2 text-xs"
                              />
                            </label>
                            <div className="text-[10px] font-bold text-slate-500">
                              AMOUNT
                              <div className="mt-1 rounded-lg bg-slate-200/70 px-2 py-2 text-right text-xs font-bold text-slate-800">
                                {money(item.quantity * item.unitPrice)}
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Notes & Terms */}
                <label className="block text-xs font-bold text-slate-700">
                  Customer notes
                  <textarea
                    disabled={!isEditable}
                    rows={3}
                    value={form.notes}
                    onChange={(event) => setForm((current) => ({ ...current, notes: event.target.value }))}
                    className="mt-1 w-full resize-none rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs"
                  />
                </label>
                <label className="block text-xs font-bold text-slate-700">
                  Terms & conditions
                  <textarea
                    disabled={!isEditable}
                    rows={4}
                    value={form.terms}
                    onChange={(event) => setForm((current) => ({ ...current, terms: event.target.value }))}
                    className="mt-1 w-full resize-none rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs leading-5"
                  />
                </label>

                {quotation?.customerResponseNote ? (
                  <div className="rounded-xl border border-amber-200 bg-amber-50 p-3">
                    <p className="text-[10px] font-extrabold uppercase tracking-wide text-amber-700">Customer response</p>
                    <p className="mt-1 text-xs text-amber-900">{quotation.customerResponseNote}</p>
                  </div>
                ) : null}

                {/* Sticky Action Footer */}
                {canManage ? (
                  <div className="sticky bottom-0 z-10 -mx-1 grid grid-cols-3 gap-2 rounded-2xl border border-slate-200 bg-white/95 p-3 shadow-[0_-12px_30px_rgba(15,23,42,0.10)] backdrop-blur">
                    <button
                      type="button"
                      disabled={saving}
                      onClick={() => void save(false)}
                      className="inline-flex items-center justify-center rounded-xl border border-slate-200 bg-white py-3 text-xs font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-50 cursor-pointer"
                    >
                      <FileDown className="mr-1 h-3.5 w-3.5" />
                      {quotation ? "Update Quote" : "Save Draft"}
                    </button>
                    {(!isApproved || isDraft || isIssued || isRejected) ? (
                      <button
                        type="button"
                        disabled={saving || !canIssue}
                        onClick={() => void save(true)}
                        className="inline-flex items-center justify-center rounded-xl bg-[#1e3a8a] py-3 text-xs font-bold text-white hover:bg-blue-800 disabled:opacity-50 cursor-pointer"
                      >
                        <Send className="mr-1 h-3.5 w-3.5" />
                        {isIssued ? "Re-issue" : "Issue Quote"}
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={onClose}
                        className="inline-flex items-center justify-center rounded-xl border border-slate-200 bg-white py-3 text-xs font-bold text-slate-700 hover:bg-slate-50 cursor-pointer"
                      >
                        Back to WO
                      </button>
                    )}
                    {!isApproved ? (
                      <button
                        type="button"
                        disabled={saving}
                        onClick={() => void approveInternally()}
                        className="inline-flex items-center justify-center rounded-xl bg-emerald-600 py-3 text-xs font-bold text-white hover:bg-emerald-700 disabled:opacity-50 cursor-pointer shadow-sm"
                      >
                        <CheckCircle2 className="mr-1 h-3.5 w-3.5" />
                        Approve & Start
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={onClose}
                        className="inline-flex items-center justify-center rounded-xl bg-emerald-600 py-3 text-xs font-bold text-white hover:bg-emerald-700 cursor-pointer shadow-sm"
                      >
                        <CheckCircle2 className="mr-1 h-3.5 w-3.5" />
                        Approved
                      </button>
                    )}
                  </div>
                ) : null}
              </div>
            </aside>

            {/* Document Stage */}
            <main className="quotation-stage overflow-y-auto bg-slate-200/70 p-6">
              <article id="quotation-document" className="mx-auto min-h-[1040px] max-w-[820px] bg-white p-10 text-[11px] text-slate-900 shadow-xl">
                <header className="grid grid-cols-[250px_minmax(0,1fr)] items-center border-b-2 border-slate-800 pb-4">
                  <div className="flex h-28 w-60 items-center justify-center overflow-hidden">
                    <img src={logo} alt="Mewah AutoWorks" className="h-28 w-60 scale-[1.55] object-contain" />
                  </div>
                  <div className="text-center leading-tight">
                    <h1 className="text-xl font-black">{documentSettings.company?.legalName || "MEWAH AUTOWORKS SDN BHD"}</h1>
                    <p>({documentSettings.company?.registrationNo})</p>
                    <p>({documentSettings.company?.groupName})</p>
                    <p>{documentSettings.company?.address}</p>
                    <p>Tel: {documentSettings.company?.phone} · {documentSettings.company?.email}</p>
                  </div>
                </header>

                <div className="mt-5 grid grid-cols-2 gap-6">
                  <section className="min-h-40 border border-slate-700 p-3">
                    <p className="text-[9px] font-bold text-slate-500">{form.debtorCode || "CUSTOMER"}</p>
                    <p className="font-black">{workOrder.companyName || "Cash Customer"}</p>
                    <p>{workOrder.contactName || "—"}</p>
                    <p>{workOrder.customerPhone || "—"}</p>
                  </section>
                  <section>
                    <h2 className="mb-2 text-center text-2xl font-black tracking-wide">QUOTATION</h2>
                    <dl className="grid grid-cols-[100px_10px_1fr] gap-y-1">
                      <dt className="font-bold">No.</dt><dd>:</dd><dd>{shownNo}</dd>
                      <dt className="font-bold">Revision</dt><dd>:</dd><dd>{quotation?.revision || 1}</dd>
                      <dt className="font-bold">Date</dt><dd>:</dd><dd>{displayDate(quotation?.createdAt || form.date)}</dd>
                      <dt className="font-bold">Valid Until</dt><dd>:</dd><dd>{displayDate(form.validUntil)}</dd>
                      <dt className="font-bold">Job No.</dt><dd>:</dd><dd>{workOrder.workOrderNo}</dd>
                      <dt className="font-bold">Vehicle Type</dt><dd>:</dd><dd>{form.vehicleType}</dd>
                      <dt className="font-bold">Vehicle No.</dt><dd>:</dd><dd>{form.vehicleNo}</dd>
                    </dl>
                  </section>
                </div>

                <table className="mt-5 w-full border-collapse">
                  <thead>
                    <tr className="border-y-2 border-slate-800">
                      <th className="w-10 py-2 text-left">Item</th>
                      <th className="py-2 text-left">Code / Description</th>
                      <th className="w-16 text-right">Qty</th>
                      <th className="w-24 text-right">Unit Price<br />RM</th>
                      <th className="w-24 text-right">Amount<br />RM</th>
                    </tr>
                  </thead>
                  <tbody>
                    {form.items.map((item, index) => (
                      <tr key={item.id || index} className="align-top">
                        <td className="py-2">{index + 1}.</td>
                        <td className="py-2">
                          <p className="font-bold">{item.code ? `${item.code} · ` : ""}{item.description || "Item description"}</p>
                          <p className="text-[8px] uppercase text-slate-500">{item.type}</p>
                        </td>
                        <td className="py-2 text-right">{Number(item.quantity).toFixed(2)}</td>
                        <td className="py-2 text-right">{money(item.unitPrice)}</td>
                        <td className="py-2 text-right">{money(item.quantity * item.unitPrice)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                <div className="mt-36 grid grid-cols-[1fr_290px] gap-4 border-t border-slate-800 pt-2">
                  <div>
                    {form.notes ? (
                      <>
                        <p className="font-black">Note:</p>
                        <p className="whitespace-pre-wrap">{form.notes}</p>
                      </>
                    ) : null}
                  </div>
                  <dl className="grid grid-cols-[1fr_90px] gap-y-1 text-right">
                    <dt className="font-bold">Sub Total</dt><dd>{money(totals.subtotal)}</dd>
                    <dt>Discount</dt><dd>{money(totals.discount)}</dd>
                    {Number(form.taxRate || 0) > 0 ? (
                      <>
                        <dt>Service Tax ({Number(form.taxRate).toFixed(2)}%)</dt>
                        <dd>{money(totals.taxAmount)}</dd>
                      </>
                    ) : null}
                    <dt className="border-t border-slate-800 pt-2 text-sm font-black">Total (RM)</dt>
                    <dd className="border-t border-slate-800 pt-2 text-sm font-black">{money(totals.total)}</dd>
                  </dl>
                </div>

                <div className="mt-5 border-t border-slate-400 pt-3">
                  <p className="font-black">Terms &amp; Conditions:</p>
                  <p className="mt-1 whitespace-pre-wrap">{form.terms}</p>
                </div>
                <p className="mt-10 text-center text-xs font-bold">This is a computer generated quotation, no signature required.</p>
              </article>
            </main>
          </div>
        )}
      </div>
    </div>
  );
}
