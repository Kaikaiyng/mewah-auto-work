import { useState, useMemo } from "react";
import { Search, Plus, Edit, Trash2, AlertCircle, XCircle, X, ImageIcon, Upload, RefreshCw, Download, Package, Boxes, BadgeDollarSign, Eye, Database, Save } from "lucide-react";
import { useApiData } from "../lib/use-api-data";
import { useLanguage } from "../contexts/language-context";
import { toast } from "sonner";
import { useConfirmationDialog } from "../contexts/confirmation-dialog-context";
import { AdminSelect } from "./ui/admin-select";
import { postApi } from "../lib/api";
import { hasAdminPermission } from "../lib/admin-permissions";
import { AutoCountSyncBadge } from "./autocount-sync-badge";
import { exportTableToExcel, ExcelColumnDef } from "../lib/excel-export";

interface Part {
  id: number;
  name: string;
  category: string;
  sku: string;
  price: number;
  cost: number | null;
  uom: string;
  itemGroup: string;
  itemType: ItemType;
  taxCode: string;
  isStockItem: boolean;
  isActive: boolean;
  stock: number;
  lowStockThreshold: number;
  supplier: string;
  supplierCode?: string;
  supplierName?: string;
  image: string;
}

interface ImportPartRow {
  sku: string;
  name: string;
  uom?: string;
  category?: string;
  cost?: number;
  price?: number;
  stock?: number;
  lowStockThreshold?: number;
  supplier?: string;
  itemGroup?: string;
  itemType?: ItemType;
  taxCode?: string;
  isStockItem?: boolean;
  isActive?: boolean;
}

type ItemType = "part" | "labour" | "service" | "fee" | "vehicle" | "other";

interface StockGroup {
  code: string;
  description: string;
  itemType: ItemType;
  isWorkshopItem: boolean;
  isActive: boolean;
}

interface ImportResult {
  created: number;
  updated: number;
  skipped: number;
  total: number;
}

interface AutoCountItemDetail {
  itemCode: string;
  fields: Record<string, string | number | null>;
  image: {
    hasImage: boolean;
    size: number;
  };
}

const IMPORT_PREVIEW_LIMIT = 5;
const PARTS_PAGE_SIZE = 60;

function parseCsv(text: string) {
  const rows: string[][] = [];
  let row: string[] = [];
  let value = "";
  let quoted = false;

  for (let index = 0; index < text.length; index += 1) {
    const character = text[index];
    if (character === '"') {
      if (quoted && text[index + 1] === '"') {
        value += '"';
        index += 1;
      } else {
        quoted = !quoted;
      }
    } else if (character === "," && !quoted) {
      row.push(value);
      value = "";
    } else if ((character === "\n" || character === "\r") && !quoted) {
      if (character === "\r" && text[index + 1] === "\n") index += 1;
      row.push(value);
      if (row.some((cell) => cell.trim() !== "")) rows.push(row);
      row = [];
      value = "";
    } else {
      value += character;
    }
  }
  row.push(value);
  if (row.some((cell) => cell.trim() !== "")) rows.push(row);
  return rows;
}

function findColumn(headers: string[], aliases: string[]) {
  return aliases.map((alias) => headers.indexOf(alias)).find((index) => index >= 0) ?? -1;
}

function parseCsvNumber(value?: string) {
  const trimmed = value?.trim();
  if (!trimmed) return undefined;
  const negative = /^\(.*\)$/.test(trimmed);
  const normalized = trimmed.replace(/[(),\s]/g, "").replace(/^(?:RM|MYR)/i, "");
  const parsed = Number(normalized);
  if (!Number.isFinite(parsed)) return undefined;
  return negative ? -parsed : parsed;
}

function parseAutoCountCsv(text: string): ImportPartRow[] {
  const rows = parseCsv(text.replace(/^\uFEFF/, ""));
  if (rows.length < 2) throw new Error("The selected CSV does not contain any part records.");
  const headers = rows[0].map((header) => header.trim().toLowerCase().replace(/[^a-z0-9]/g, ""));
  const skuIndex = findColumn(headers, ["sku", "itemcode", "stockcode", "partno", "partcode", "code"]);
  const nameIndex = findColumn(headers, ["name", "description", "itemdescription", "itemname", "partname", "stockname"]);
  const uomIndex = findColumn(headers, ["uom", "unit", "baseuom", "unitofmeasure"]);
  const categoryIndex = findColumn(headers, ["category", "itemgroup", "stockgroup", "partcategory", "groupname", "classification"]);
  const itemTypeIndex = findColumn(headers, ["itemtype", "type", "stocktype"]);
  const taxCodeIndex = findColumn(headers, ["taxcode", "salestaxcode", "outputtaxcode"]);
  const costIndex = findColumn(headers, ["cost", "costprice", "standardcost", "stdcost", "averagecost", "unitcost", "lastcost"]);
  const priceIndex = findColumn(headers, ["price", "sellingprice", "sellingprice1", "unitprice", "salesprice", "salesprice1"]);
  const stockIndex = findColumn(headers, ["stock", "quantity", "qty", "stockquantity", "currentstock", "qtyonhand", "onhandqty", "onhand", "balance", "balanceqty", "balancequantity", "qtybalance", "stockbalance", "stockbalanceqty"]);
  const thresholdIndex = findColumn(headers, ["lowstockthreshold", "minimumstock", "minstock", "minstocklevel", "reorderlevel", "reorderpoint", "reorderqty", "reorderquantity", "minlevel", "minimumlevel"]);
  const supplierIndex = findColumn(headers, ["supplier", "vendor", "suppliername", "vendorname"]);
  if (skuIndex < 0 || nameIndex < 0) {
    throw new Error("The CSV must contain SKU/Item Code and Name/Description columns.");
  }

  const importedRows: ImportPartRow[] = [];
  for (const values of rows.slice(1)) {
    const skuValue = values[skuIndex] || "";
    const nameValue = values[nameIndex]?.trim() || "";
    if (!skuValue.trim() || !nameValue) continue;
    const imported: ImportPartRow = {
      sku: skuValue,
      name: nameValue,
    };
    const uomValue = uomIndex >= 0 ? values[uomIndex]?.trim() : "";
    const categoryValue = categoryIndex >= 0 ? values[categoryIndex]?.trim() : "";
    const supplierValue = supplierIndex >= 0 ? values[supplierIndex]?.trim() : "";
    const itemTypeValue = itemTypeIndex >= 0 ? values[itemTypeIndex]?.trim().toLowerCase() : "";
    const taxCodeValue = taxCodeIndex >= 0 ? values[taxCodeIndex]?.trim() : "";
    const costValue = costIndex >= 0 ? parseCsvNumber(values[costIndex]) : undefined;
    const priceValue = priceIndex >= 0 ? parseCsvNumber(values[priceIndex]) : undefined;
    const stockValue = stockIndex >= 0 ? parseCsvNumber(values[stockIndex]) : undefined;
    const thresholdValue = thresholdIndex >= 0 ? parseCsvNumber(values[thresholdIndex]) : undefined;
    if (uomValue) imported.uom = uomValue;
    if (categoryValue) {
      imported.category = categoryValue;
      imported.itemGroup = categoryValue;
    }
    if (supplierValue) imported.supplier = supplierValue;
    if (["part", "labour", "service", "fee", "vehicle", "other"].includes(itemTypeValue)) imported.itemType = itemTypeValue as ItemType;
    if (taxCodeValue) imported.taxCode = taxCodeValue;
    if (costValue !== undefined) imported.cost = Math.max(0, costValue);
    if (priceValue !== undefined) imported.price = Math.max(0, priceValue);
    if (stockValue !== undefined) imported.stock = Math.max(0, stockValue);
    if (thresholdValue !== undefined) imported.lowStockThreshold = Math.max(0, thresholdValue);
    importedRows.push(imported);
  }
  if (importedRows.length === 0) throw new Error("No valid part rows were found in the selected CSV.");
  if (importedRows.length > 5000) throw new Error("A single import cannot exceed 5,000 rows.");
  return importedRows;
}

const presetAutoCountGroups = [
  "ACCHDLG", "ACCRUAL", "AUDIT FE", "BOOKFEE", "CONTRA", "CONTRI", "COURIER", "DEPOSIT",
  "EQUIP", "FWDG", "HAULAGE", "HDLG", "INSURAN", "LAB HAND", "LABOUR", "MTL_DGC",
  "O/CHARGE", "PORTS", "PR LABOU", "PREPAY", "PS LABOU", "RENTAL", "SM", "SOC", "SP",
  "STOCK", "STOCK PM", "T&E (EXP", "T/L USE", "T/W USE", "TLS&EQP", "TR LABOU", "TRANS",
  "TS LABOU", "UK/EQP", "UTILITY",
];
const itemTypeLabels: Record<ItemType, string> = {
  part: "Part / Stock",
  labour: "Labour",
  service: "Service",
  fee: "Fee / Charge",
  vehicle: "Vehicle Sales",
  other: "Other",
};
const MAX_PART_IMAGE_BYTES = 3 * 1024 * 1024;
const acceptedPartImageTypes = ["image/jpeg", "image/png", "image/webp"];

function isPartLowStock(part: Part) {
  return part.itemType === "part" && part.isStockItem && part.stock <= Math.max(0, part.lowStockThreshold);
}

type StockStatus = "in-stock" | "low-stock" | "out-of-stock" | "not-stock";

function getPartStockStatus(part: Part): StockStatus {
  if (part.itemType !== "part" || !part.isStockItem) return "not-stock";
  if (part.stock <= 0) return "out-of-stock";
  if (isPartLowStock(part)) return "low-stock";
  return "in-stock";
}

const stockStatusConfig: Record<StockStatus, { label: string; className: string }> = {
  "in-stock": { label: "In stock", className: "border-emerald-200 bg-emerald-50 text-emerald-700" },
  "low-stock": { label: "Low stock", className: "border-amber-200 bg-amber-50 text-amber-700" },
  "out-of-stock": { label: "Out of stock", className: "border-red-200 bg-red-50 text-red-700" },
  "not-stock": { label: "Not stock-tracked", className: "border-slate-200 bg-slate-50 text-slate-600" },
};

const itemDetailSections = [
  {
    title: "Item master",
    fields: ["ItemCode", "Description", "Desc2", "FurtherDescription", "ItemGroup", "ItemType", "ItemClass", "ItemCategory", "Classification", "ItemBrand", "GlobalCode"],
  },
  {
    title: "Stock & units",
    fields: ["StockControl", "BaseUOM", "SalesUOM", "PurchaseUOM", "ReportUOM", "CostingMethod", "AssemblyCost", "LeadTime", "LeadTimeDay", "HasSerialNo", "HasBatchNo", "SNFormatName", "BackOrderControl", "AutoUOMConversion"],
  },
  {
    title: "Sales, purchase & tax",
    fields: ["TaxCode", "PurchaseTaxCode", "DutyRate", "TariffCode", "MarkupRatio", "MainSupplier", "IsSalesItem", "IsPurchaseItem", "IsPOSItem", "IsRawMaterialItem", "IsFinishGoodsItem", "MustGenerateEInvoice"],
  },
  {
    title: "Settings",
    fields: ["IsActive", "Discontinued", "IsCalcBonusPoint", "HasPromoter", "ExternalLink", "ImageFileName", "Note", "Guid"],
  },
  {
    title: "System information",
    fields: ["DocKey", "AutoKey", "CreatedTimeStamp", "CreatedUserID", "LastModified", "LastModifiedUserID", "LastUpdate"],
  },
] as const;

const knownItemDetailFields = new Set<string>(itemDetailSections.flatMap((section) => [...section.fields]));

const booleanItemFields = new Set([
  "StockControl", "HasSerialNo", "HasBatchNo", "IsActive", "Discontinued", "IsCalcBonusPoint",
  "HasPromoter", "BackOrderControl", "AutoUOMConversion", "IsSalesItem", "IsPurchaseItem", "IsPOSItem",
  "IsRawMaterialItem", "IsFinishGoodsItem", "MustGenerateEInvoice",
]);

function itemFieldLabel(field: string) {
  return field
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .replace(/UOM/g, "UOM")
    .replace(/ID/g, "ID");
}

function itemFieldValue(field: string, value: string | number | null) {
  if (value === null || value === "") return "—";
  if (booleanItemFields.has(field)) {
    return ["T", "1", "Y", "TRUE"].includes(String(value).toUpperCase()) ? "Yes" : "No";
  }
  return String(value);
}

function csvCell(value: string | number) {
  return `"${String(value).replace(/"/g, '""')}"`;
}

export function PartsInventory() {
  const canCreate = false;
  const canUpdate = hasAdminPermission("part.update");
  const canDelete = false;
  const canViewCost = hasAdminPermission("part.viewCost");
  const { t } = useLanguage();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedItemType, setSelectedItemType] = useState<"All" | ItemType>("All");
  const [selectedStockStatus, setSelectedStockStatus] = useState<"All" | StockStatus>("All");
  const [selectedPartIds, setSelectedPartIds] = useState<Set<number>>(new Set());
  const [visibleCount, setVisibleCount] = useState(PARTS_PAGE_SIZE);
  
  // API Integration
  const { data: parts, isLoading, error, reload } = useApiData<Part[]>("admin-parts", []);
  const { data: stockGroups } = useApiData<StockGroup[]>("admin-stock-groups", []);
  
  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<"create" | "edit">("create");
  const [editingPart, setEditingPart] = useState<Part | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState("");
  const confirmAction = useConfirmationDialog();

  // Form states
  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [sku, setSku] = useState("");
  const [price, setPrice] = useState("");
  const [cost, setCost] = useState("");
  const [uom, setUom] = useState("");
  const [itemGroup, setItemGroup] = useState("");
  const [itemType, setItemType] = useState<ItemType>("part");
  const [taxCode, setTaxCode] = useState("");
  const [isStockItem, setIsStockItem] = useState(true);
  const [isActive, setIsActive] = useState(true);
  const [stock, setStock] = useState("");
  const [lowStockThreshold, setLowStockThreshold] = useState("10");
  const [supplier, setSupplier] = useState("");
  const [image, setImage] = useState("");
  const [imageData, setImageData] = useState("");
  const [imageFileName, setImageFileName] = useState("");
  const [imageInputKey, setImageInputKey] = useState(0);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importRows, setImportRows] = useState<ImportPartRow[]>([]);
  const [importFileName, setImportFileName] = useState("");
  const [importError, setImportError] = useState("");
  const [importing, setImporting] = useState(false);
  const [detailPart, setDetailPart] = useState<Part | null>(null);
  const [itemDetail, setItemDetail] = useState<AutoCountItemDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailError, setDetailError] = useState("");

  const categories = useMemo(() => {
    return ["All", ...new Set(parts.map((p) => p.itemGroup || p.category).filter(Boolean))];
  }, [parts]);
  const itemGroupOptions = useMemo(() => {
    return [...new Set([
      ...presetAutoCountGroups,
      ...stockGroups.map((group) => group.code),
      ...parts.map((part) => part.itemGroup).filter(Boolean),
    ])];
  }, [parts, stockGroups]);
  const stockGroupMap = useMemo(
    () => new Map(stockGroups.map((group) => [group.code, group])),
    [stockGroups],
  );

  const filteredParts = useMemo(() => {
    return parts.filter((part) => {
      const matchesSearch =
        part.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        part.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (part.supplierCode || part.supplier).toLowerCase().includes(searchTerm.toLowerCase()) ||
        (part.supplierName || "").toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === "All" || (part.itemGroup || part.category) === selectedCategory;
      const matchesItemType = selectedItemType === "All" || part.itemType === selectedItemType;
      const matchesStockStatus = selectedStockStatus === "All" || getPartStockStatus(part) === selectedStockStatus;
      return matchesSearch && matchesCategory && matchesItemType && matchesStockStatus;
    });
  }, [parts, searchTerm, selectedCategory, selectedItemType, selectedStockStatus]);

  const lowStockParts = useMemo(() => {
    return parts.filter(isPartLowStock);
  }, [parts]);

  const stockCounts = useMemo(() => {
    return {
      all: parts.length,
      inStock: parts.filter((p) => getPartStockStatus(p) === "in-stock").length,
      lowStock: parts.filter((p) => getPartStockStatus(p) === "low-stock").length,
      outOfStock: parts.filter((p) => getPartStockStatus(p) === "out-of-stock").length,
      notStock: parts.filter((p) => getPartStockStatus(p) === "not-stock").length,
    };
  }, [parts]);

  const inventoryStats = useMemo(() => {
    const workshopParts = parts.filter((part) => part.itemType === "part" && part.isStockItem);
    const normalizedSkus = new Set(
      parts.map((part) => part.sku.trim().toUpperCase()).filter(Boolean),
    );
    const normalizedCategories = new Set(
      parts.map((part) => (part.itemGroup || part.category).trim().toLowerCase()).filter(Boolean),
    );
    return {
      totalSkus: normalizedSkus.size,
      totalStock: workshopParts.reduce((sum, part) => sum + Math.max(0, part.stock), 0),
      categoryCount: normalizedCategories.size,
      costValue: workshopParts.reduce((sum, part) => sum + (part.cost ?? 0) * Math.max(0, part.stock), 0),
      retailValue: workshopParts.reduce((sum, part) => sum + part.price * Math.max(0, part.stock), 0),
    };
  }, [parts]);
  const visibleParts = useMemo(
    () => filteredParts.slice(0, visibleCount),
    [filteredParts, visibleCount],
  );
  const missingImportCosts = useMemo(
    () => importRows.filter((part) => part.cost === undefined).length,
    [importRows],
  );
  const importedStockTotal = useMemo(
    () => importRows.reduce((sum, part) => sum + (part.stock ?? 0), 0),
    [importRows],
  );
  const selectedParts = useMemo(
    () => parts.filter((part) => selectedPartIds.has(part.id)),
    [parts, selectedPartIds],
  );
  const allVisibleSelected = visibleParts.length > 0 && visibleParts.every((part) => selectedPartIds.has(part.id));

  const togglePartSelection = (partId: number) => {
    setSelectedPartIds((current) => {
      const next = new Set(current);
      if (next.has(partId)) next.delete(partId);
      else next.add(partId);
      return next;
    });
  };

  const toggleVisibleSelection = () => {
    setSelectedPartIds((current) => {
      const next = new Set(current);
      if (allVisibleSelected) visibleParts.forEach((part) => next.delete(part.id));
      else visibleParts.forEach((part) => next.add(part.id));
      return next;
    });
  };

  const exportParts = async (items: Part[]) => {
    if (items.length === 0) {
      toast.error("No parts are available to export.");
      return;
    }

    const columnDefs: ExcelColumnDef[] = [
      { header: "Item Code", key: "sku", align: "left", minWidth: 18, numFmt: "@" },
      { header: "Description", key: "name", align: "left", minWidth: 35 },
      { header: "Category", key: "category", align: "left", minWidth: 16 },
      { header: "Stock Group", key: "itemGroup", align: "left", minWidth: 14 },
      { header: "Item Type", key: "itemType", align: "center", minWidth: 16 },
      { header: "UOM", key: "uom", align: "center", minWidth: 10 },
    ];

    if (canViewCost) {
      columnDefs.push({ header: "Standard Cost (RM)", key: "cost", align: "right", minWidth: 18, numFmt: "#,##0.00" });
    }

    columnDefs.push(
      { header: "Selling Price (RM)", key: "price", align: "right", minWidth: 18, numFmt: "#,##0.00" },
      { header: "Tax Code", key: "taxCode", align: "center", minWidth: 12 },
      { header: "Stock Qty", key: "stock", align: "right", minWidth: 13, numFmt: "#,##0" },
      { header: "Low Stock Threshold", key: "lowStockThreshold", align: "right", minWidth: 18, numFmt: "#,##0" },
      { header: "Supplier", key: "supplier", align: "left", minWidth: 26 },
      { header: "Status", key: "status", align: "center", minWidth: 15 }
    );

    const rows = items.map((part) => {
      const rowData: Record<string, string | number> = {
        sku: String(part.sku || ""),
        name: String(part.name || ""),
        category: String(part.category || ""),
        itemGroup: String(part.itemGroup || ""),
        itemType: String(itemTypeLabels[part.itemType] || part.itemType || ""),
        uom: String(part.uom || ""),
        price: Number(part.price ?? 0),
        taxCode: String(part.taxCode || ""),
        stock: Number(part.stock ?? 0),
        lowStockThreshold: Number(part.lowStockThreshold ?? 0),
        supplier: part.supplierName ? `${part.supplierName} (${part.supplierCode || part.supplier})` : String(part.supplier || ""),
        status: stockStatusConfig[getPartStockStatus(part)]?.label || "Unknown",
      };

      if (canViewCost) {
        rowData.cost = part.cost !== null && part.cost !== undefined ? Number(part.cost) : 0;
      }
      return rowData;
    });

    const fileName = `maw-parts-${new Date().toISOString().slice(0, 10)}.xlsx`;
    await exportTableToExcel({
      fileName,
      sheetName: "Parts Inventory",
      columns: columnDefs,
      data: rows,
      successMessage: `Exported ${items.length} parts to ${fileName}`,
    });
  };

  // Open Create Modal
  const openCreateModal = () => {
    setModalMode("create");
    setEditingPart(null);
    setFormError("");
    
    // Clear form fields
    setName("");
    setCategory("SPARE PARTS");
    setSku("");
    setPrice("");
    setCost("");
    setUom("PCS");
    setItemGroup("SP");
    setItemType("part");
    setTaxCode("");
    setIsStockItem(true);
    setIsActive(true);
    setStock("");
    setLowStockThreshold("10");
    setSupplier("");
    setImage("");
    setImageData("");
    setImageFileName("");
    setImageInputKey((key) => key + 1);
    
    setIsModalOpen(true);
  };

  // Open Edit Modal
  const openEditModal = (part: Part) => {
    setModalMode("edit");
    setEditingPart(part);
    setFormError("");
    
    // Load values
    setName(part.name);
    setCategory(part.category);
    setSku(part.sku);
    setPrice(part.price.toString());
    setCost((part.cost ?? 0).toString());
    setUom(part.uom);
    setItemGroup(part.itemGroup || "");
    setItemType(part.itemType || "part");
    setTaxCode(part.taxCode || "");
    setIsStockItem(part.isStockItem ?? true);
    setIsActive(part.isActive ?? true);
    setStock(part.stock.toString());
    setLowStockThreshold(part.lowStockThreshold.toString());
    setSupplier(part.supplierCode || part.supplier);
    setImage(part.image);
    setImageData("");
    setImageFileName("");
    setImageInputKey((key) => key + 1);
    
    setIsModalOpen(true);
  };

  // Handle Form Submit
  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError("");
    setSubmitting(true);

    const normalizedName = name.trim();
    const normalizedSku = sku;
    const parsedPrice = Number(price);
    const parsedCost = Number(cost);
    const parsedStock = Number(stock);
    const parsedThreshold = Number(lowStockThreshold);

    if (!normalizedName) {
      setFormError("Part Name is required.");
      setSubmitting(false);
      return;
    }
    if (!normalizedSku.trim()) {
      setFormError("SKU / Code is required.");
      setSubmitting(false);
      return;
    }
    if (normalizedSku.length > 80) {
      setFormError("Item Code must not exceed 80 characters.");
      setSubmitting(false);
      return;
    }
    if (!Number.isFinite(parsedPrice) || parsedPrice < 0 || !Number.isFinite(parsedCost) || parsedCost < 0) {
      setFormError("Unit price and unit cost must be valid non-negative amounts.");
      setSubmitting(false);
      return;
    }
    if (!Number.isFinite(parsedStock) || parsedStock < 0 || !Number.isFinite(parsedThreshold) || parsedThreshold < 0) {
      setFormError("Stock quantity and low threshold must be valid non-negative quantities.");
      setSubmitting(false);
      return;
    }

    const payload = {
      id: editingPart?.id,
      name: normalizedName,
      category: category.trim() || "Others",
      sku: normalizedSku,
      price: parsedPrice,
      cost: parsedCost,
      uom: uom.trim(),
      itemGroup: itemGroup.trim().toUpperCase(),
      itemType,
      taxCode: taxCode.trim().toUpperCase(),
      isStockItem,
      isActive,
      stock: parsedStock,
      lowStockThreshold: parsedThreshold,
      supplier: supplier.trim() || "Mewah AutoWorks",
      image: image.trim(),
      imageData,
    };

    const action = modalMode === "create" ? "admin-create-part" : "admin-update-part";

    try {
      await postApi(action, payload);
      setIsModalOpen(false);
      await reload();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Failed to save part");
    } finally {
      setSubmitting(false);
    }
  };

  const openImportModal = () => {
    setImportRows([]);
    setImportFileName("");
    setImportError("");
    setIsImportModalOpen(true);
  };

  const handleImportFile = async (file?: File) => {
    setImportRows([]);
    setImportError("");
    setImportFileName(file?.name || "");
    if (!file) return;
    if (!file.name.toLowerCase().endsWith(".csv")) {
      setImportError("Select the prepared AutoCount CSV file.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setImportError("The import file must not exceed 5 MB.");
      return;
    }
    try {
      setImportRows(parseAutoCountCsv(await file.text()));
    } catch (caught) {
      setImportError(caught instanceof Error ? caught.message : "Unable to read the selected CSV.");
    }
  };

  const handleImportParts = async () => {
    if (importRows.length === 0 || importing) return;
    setImportError("");
    setImporting(true);
    try {
      const result = await postApi<ImportResult>("admin-import-parts", { items: importRows });
      setIsImportModalOpen(false);
      setVisibleCount(PARTS_PAGE_SIZE);
      await reload();
      toast.success(`AutoCount import complete: ${result.created} created, ${result.updated} updated, ${result.skipped} skipped.`);
    } catch (caught) {
      setImportError(caught instanceof Error ? caught.message : "Unable to import AutoCount parts.");
    } finally {
      setImporting(false);
    }
  };

  const handleImageSelection = (file?: File) => {
    setFormError("");
    if (!file) return;
    if (!acceptedPartImageTypes.includes(file.type)) {
      setFormError("Image must be a JPG, PNG, or WebP file.");
      setImageInputKey((key) => key + 1);
      return;
    }
    if (file.size > MAX_PART_IMAGE_BYTES) {
      setFormError("Image must not exceed 3 MB.");
      setImageInputKey((key) => key + 1);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result !== "string") {
        setFormError("Unable to read the selected image.");
        return;
      }
      setImageData(reader.result);
      setImageFileName(file.name);
    };
    reader.onerror = () => setFormError("Unable to read the selected image.");
    reader.readAsDataURL(file);
  };

  const removeImage = () => {
    setImage("");
    setImageData("");
    setImageFileName("");
    setImageInputKey((key) => key + 1);
  };

  // Handle Delete Part
  const handleDeletePart = async (part: Part) => {
    const confirmed = await confirmAction({
      title: `Delete part "${part.name}"?`,
      description: `Part ${part.sku || `#${part.id}`} will be permanently removed from inventory. This action cannot be undone.`,
      confirmLabel: "Delete part",
      tone: "danger",
    });
    if (!confirmed) {
      return;
    }

    try {
      await postApi("admin-delete-part", { id: part.id });
      await reload();
      toast.success(`Part "${part.name}" deleted.`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to delete part");
    }
  };

  const openItemDetail = async (part: Part) => {
    setDetailPart(part);
    setItemDetail(null);
    setDetailError("");
    setDetailLoading(true);
    try {
      setItemDetail(await postApi<AutoCountItemDetail>("admin-item-detail", { itemCode: part.sku }));
    } catch (caught) {
      setDetailError(caught instanceof Error ? caught.message : "Unable to load AutoCount Item details.");
    } finally {
      setDetailLoading(false);
    }
  };

  const closeItemDetail = () => {
    setDetailPart(null);
    setItemDetail(null);
    setDetailError("");
    setDetailLoading(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-2xl font-bold text-gray-900">
              {t("parts_management")}
            </h1>
            <AutoCountSyncBadge
              label="Stock Master Synced"
              onRefresh={() => void reload()}
              isRefreshing={isLoading}
            />
          </div>
          <p className="mt-0.5 text-xs text-slate-500">
            Spare parts catalog and stock levels are master-managed in AutoCount and synced to MAW
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => exportParts(filteredParts)}
            disabled={isLoading || Boolean(error) || filteredParts.length === 0}
            className="inline-flex h-10 items-center justify-center rounded-xl border border-gray-300 bg-white px-4 text-sm font-semibold text-gray-700 shadow-sm transition-colors hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Download className="mr-2 h-4 w-4" />
            Export
          </button>
        {canCreate ? <>
          <button
            type="button"
            onClick={openImportModal}
            className="inline-flex h-10 items-center justify-center rounded-xl border border-[#1e3a8a] bg-white px-4 text-sm font-semibold text-[#1e3a8a] shadow-sm transition-colors hover:bg-blue-50"
          >
            <Upload className="mr-2 h-4 w-4" />
            Import
          </button>
          <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex h-10 items-center justify-center rounded-xl bg-[#1e3a8a] px-4 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-blue-800"
          >
            <Plus className="mr-2 h-4 w-4" />
            {t("add_part")}
          </button>
        </> : null}
        </div>
      </div>

      {error && (
        <div role="alert" className="flex items-start justify-between gap-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
          <div className="flex items-start gap-2">
            <XCircle className="mt-0.5 h-5 w-5 shrink-0" />
            <div>
              <p className="font-semibold">Parts inventory is unavailable</p>
              <p className="mt-0.5">{error}. No substitute inventory data is being shown.</p>
            </div>
          </div>
          <button type="button" onClick={reload} disabled={isLoading} className="inline-flex shrink-0 items-center rounded-lg border border-red-300 bg-white px-3 py-1.5 font-semibold text-red-700 hover:bg-red-100 disabled:opacity-50">
            <RefreshCw className={`mr-1.5 h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
            Retry
          </button>
        </div>
      )}

      {/* Stats */}
      {!error ? <div className={`grid grid-cols-1 gap-3 sm:grid-cols-2 ${canViewCost ? "xl:grid-cols-4" : "xl:grid-cols-3"}`}>
        {canViewCost ? <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
          <div className="flex items-center justify-between"><p className="text-xs font-semibold uppercase tracking-wide text-gray-500">Total items</p><Package className="h-4 w-4 text-gray-400" /></div>
          <p className="mt-3 text-2xl font-bold text-gray-900">{inventoryStats.totalSkus.toLocaleString()}</p>
          <p className="mt-1 text-xs text-gray-500">Across {inventoryStats.categoryCount} categories</p>
        </div> : null}
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
          <div className="flex items-center justify-between"><p className="text-xs font-semibold uppercase tracking-wide text-gray-500">Stock on hand</p><Boxes className="h-4 w-4 text-gray-400" /></div>
          <p className="mt-3 text-2xl font-bold text-gray-900">{inventoryStats.totalStock.toLocaleString()}</p>
          <p className="mt-1 text-xs text-gray-500">Available workshop-part units</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
          <div className="flex items-center justify-between"><p className="text-xs font-semibold uppercase tracking-wide text-gray-500">Inventory value</p><BadgeDollarSign className="h-4 w-4 text-gray-400" /></div>
          <p className="mt-3 text-2xl font-bold text-gray-900">RM {inventoryStats.costValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          <p className="mt-1 text-xs text-gray-500">Based on standard cost</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
          <div className="flex items-center justify-between"><p className="text-xs font-semibold uppercase tracking-wide text-gray-500">Low stock alerts</p><AlertCircle className="h-4 w-4 text-amber-500" /></div>
          <p className="mt-3 text-2xl font-bold text-amber-600">{lowStockParts.length}</p>
          <p className="mt-1 text-xs text-gray-500">Items at or below threshold</p>
        </div>
      </div> : null}

      {/* Stock Status Category Tabs */}
      {!error && (
        <div className="flex flex-wrap items-center gap-1.5 border-b border-slate-200 pb-2">
          {(
            [
              { id: "All", label: "All Items", count: stockCounts.all },
              { id: "in-stock", label: "In Stock", count: stockCounts.inStock },
              { id: "low-stock", label: "Low Stock", count: stockCounts.lowStock, badgeColor: stockCounts.lowStock > 0 ? "bg-amber-100 text-amber-800" : undefined },
              { id: "out-of-stock", label: "Out of Stock", count: stockCounts.outOfStock, badgeColor: stockCounts.outOfStock > 0 ? "bg-rose-100 text-rose-700 animate-pulse" : undefined },
              { id: "not-stock", label: "Non-stock / Services", count: stockCounts.notStock },
            ] as { id: "All" | StockStatus; label: string; count: number; badgeColor?: string }[]
          ).map((tab) => {
            const isActive = selectedStockStatus === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  setSelectedStockStatus(tab.id);
                  setVisibleCount(PARTS_PAGE_SIZE);
                }}
                className={`inline-flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-bold transition-all cursor-pointer ${
                  isActive
                    ? "bg-[#1e3a8a] text-white shadow-sm"
                    : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
                }`}
              >
                <span>{tab.label}</span>
                <span
                  className={`rounded-full px-2 py-0.5 text-[10px] font-extrabold ${
                    isActive
                      ? "bg-white/20 text-white"
                      : tab.badgeColor || "bg-slate-100 text-slate-600"
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            );
          })}
        </div>
      )}

      {/* Unified Search & Dropdown Filters Bar */}
      {!error && (
        <div className="maw-filter-bar">
          <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
            <div className="maw-search-field">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setVisibleCount(PARTS_PAGE_SIZE);
                }}
                placeholder={t("search_parts")}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-sm"
              />
            </div>
            <div>
              <AdminSelect
                value={selectedCategory}
                onChange={(e) => {
                  setSelectedCategory(e.target.value);
                  setVisibleCount(PARTS_PAGE_SIZE);
                }}
                aria-label="Filter by category"
                className="w-full"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat === "All" ? "All Categories" : cat}
                  </option>
                ))}
              </AdminSelect>
            </div>
            <div>
              <AdminSelect
                value={selectedItemType}
                onChange={(e) => {
                  setSelectedItemType(e.target.value as "All" | ItemType);
                  setVisibleCount(PARTS_PAGE_SIZE);
                }}
                aria-label="Filter by item type"
                className="w-full"
              >
                <option value="All">All Item Types</option>
                <option value="part">Part / Stock</option>
                <option value="labour">Labour</option>
                <option value="service">Service</option>
                <option value="fee">Fee / Charge</option>
                <option value="vehicle">Vehicle Sales</option>
                <option value="other">Other</option>
              </AdminSelect>
            </div>
          </div>
        </div>
      )}

      {isLoading && parts.length === 0 ? (
        <div className="flex min-h-48 items-center justify-center rounded-lg border border-gray-200 bg-white text-sm text-gray-500">
          <RefreshCw className="mr-2 h-5 w-5 animate-spin" />
          Loading parts inventory...
        </div>
      ) : null}

      {!isLoading && !error && parts.length === 0 ? (
        <div className="rounded-lg border border-dashed border-gray-300 bg-white px-6 py-12 text-center">
          <ImageIcon className="mx-auto h-9 w-9 text-gray-300" />
          <h2 className="mt-3 text-sm font-semibold text-gray-900">No parts in inventory</h2>
          <p className="mt-1 text-sm text-gray-500">All parts and stock quantities are synced from AutoCount.</p>
        </div>
      ) : null}

      {!isLoading && !error && parts.length > 0 && filteredParts.length === 0 ? (
        <div className="rounded-lg border border-dashed border-gray-300 bg-white px-6 py-10 text-center text-sm text-gray-500">
          No parts match the current search, category and stock-status filters.
        </div>
      ) : null}

      {/* Parts Table */}
      {!error && visibleParts.length > 0 ? <div className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1020px] text-left">
            <thead className="border-b border-gray-200 bg-gray-50/80 text-xs font-semibold uppercase tracking-wide text-gray-500">
              <tr>
                <th className="w-12 px-4 py-3">
                  <input type="checkbox" checked={allVisibleSelected} onChange={toggleVisibleSelection} aria-label="Select visible parts" className="h-4 w-4 rounded border-gray-300 text-[#1e3a8a] focus:ring-blue-500" />
                </th>
                <th className="px-3 py-3">Part</th>
                <th className="px-3 py-3">SKU & UOM</th>
                <th className="px-3 py-3">Supplier</th>
                <th className="px-3 py-3 text-right">Price</th>
                <th className="px-3 py-3 text-right">Stock</th>
                <th className="px-3 py-3">Status</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {visibleParts.map((part) => {
                const status = stockStatusConfig[getPartStockStatus(part)];
                const isSelected = selectedPartIds.has(part.id);
                return (
                  <tr key={part.id} className={`transition-colors hover:bg-blue-50/40 ${isSelected ? "bg-blue-50/70" : ""}`}>
                    <td className="px-4 py-3">
                      <input type="checkbox" checked={isSelected} onChange={() => togglePartSelection(part.id)} aria-label={`Select ${part.name}`} className="h-4 w-4 rounded border-gray-300 text-[#1e3a8a] focus:ring-blue-500" />
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex min-w-0 items-center gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-gray-200 bg-gray-50">
                          {part.image ? <img src={part.image} alt="" className="h-full w-full object-cover" /> : <Package className="h-5 w-5 text-gray-300" />}
                        </div>
                        <div className="min-w-0">
                          <p className="max-w-[240px] truncate text-sm font-semibold text-gray-900" title={part.name}>{part.name}</p>
                          <p className="mt-0.5 max-w-[240px] truncate text-xs text-gray-500" title={part.itemGroup || part.category}>
                            {part.itemGroup || part.category || "No group"} · {itemTypeLabels[part.itemType]}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <p className="font-mono text-xs font-semibold text-gray-800">{part.sku}</p>
                      <p className="mt-1 text-xs text-gray-500">{part.uom || "Unit not set"}</p>
                    </td>
                    <td className="px-3 py-3">
                      <p className="max-w-[200px] truncate text-xs font-semibold text-gray-800" title={part.supplierName || undefined}>{part.supplierName || "—"}</p>
                      <p className="mt-1 font-mono text-[11px] text-gray-500">{part.supplierCode || part.supplier || "No code"}</p>
                    </td>
                    <td className="px-3 py-3 text-right">
                      <p className="text-sm font-semibold text-gray-900">RM {part.price.toFixed(2)}</p>
                      {canViewCost && part.cost !== null ? <p className="mt-1 text-xs text-gray-500">Standard cost RM {part.cost.toFixed(2)}</p> : null}
                    </td>
                    <td className="px-3 py-3 text-right">
                      {part.itemType === "part" && part.isStockItem ? (
                        <>
                          <p className={`text-sm font-semibold ${part.stock < 0 ? "text-red-600" : "text-gray-900"}`}>{part.stock.toLocaleString()}</p>
                          <button
                            type="button"
                            onClick={() => openEditModal(part)}
                            className="mt-1 inline-flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800 hover:underline cursor-pointer"
                            title="Click to change Low Stock Alert Threshold"
                          >
                            <span>Min: {part.lowStockThreshold}</span>
                            <Edit className="h-3 w-3 inline opacity-60" />
                          </button>
                        </>
                      ) : (
                        <p className="text-xs font-medium text-gray-400">Not tracked</p>
                      )}
                    </td>
                    <td className="px-3 py-3"><span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold ${status.className}`}><span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />{status.label}</span></td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => void openItemDetail(part)}
                          aria-label={`View ${part.name} AutoCount details`}
                          title="View AutoCount Details"
                          className="rounded-lg p-2 text-gray-500 hover:bg-blue-50 hover:text-blue-700 cursor-pointer"
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                        {canUpdate ? (
                          <button
                            type="button"
                            onClick={() => openEditModal(part)}
                            aria-label={`Edit ${part.name}`}
                            title="Edit Low Stock Threshold & Info"
                            className="rounded-lg p-2 text-blue-700 hover:bg-blue-50 cursor-pointer"
                          >
                            <Edit className="h-4 w-4" />
                          </button>
                        ) : null}
                        {canDelete ? <button type="button" onClick={() => handleDeletePart(part)} aria-label={`Delete ${part.name}`} className="rounded-lg p-2 text-gray-500 hover:bg-red-50 hover:text-red-700 cursor-pointer"><Trash2 className="h-4 w-4" /></button> : null}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between border-t border-gray-200 bg-gray-50/70 px-4 py-3 text-xs text-gray-500">
          <span>Showing {visibleParts.length.toLocaleString()} of {filteredParts.length.toLocaleString()} matching parts</span>
          <span>{selectedParts.length.toLocaleString()} selected</span>
        </div>
      </div> : null}

      {visibleParts.length < filteredParts.length ? (
        <div className="flex justify-center">
          <button
            type="button"
            onClick={() => setVisibleCount((count) => count + PARTS_PAGE_SIZE)}
            className="rounded-lg border border-gray-300 bg-white px-5 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50"
          >
            Load more ({filteredParts.length - visibleParts.length} remaining)
          </button>
        </div>
      ) : null}

      {selectedParts.length > 0 ? (
        <div className="fixed bottom-6 left-1/2 z-40 flex -translate-x-1/2 items-center gap-2 rounded-xl border border-gray-200 bg-white px-3 py-2 shadow-2xl">
          <span className="border-r border-gray-200 px-2 text-sm font-semibold text-gray-800">{selectedParts.length} selected</span>
          <button type="button" onClick={() => exportParts(selectedParts)} className="inline-flex items-center rounded-lg px-3 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-100"><Download className="mr-2 h-4 w-4" />Export</button>
          {canUpdate ? <button type="button" disabled={selectedParts.length !== 1} onClick={() => openEditModal(selectedParts[0])} className="inline-flex items-center rounded-lg px-3 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-100 disabled:cursor-not-allowed disabled:opacity-40"><Edit className="mr-2 h-4 w-4" />Edit info</button> : null}
          {canDelete ? <button type="button" disabled={selectedParts.length !== 1} onClick={() => handleDeletePart(selectedParts[0])} className="inline-flex items-center rounded-lg px-3 py-2 text-sm font-semibold text-gray-700 hover:bg-red-50 hover:text-red-700 disabled:cursor-not-allowed disabled:opacity-40"><Trash2 className="mr-2 h-4 w-4" />Delete</button> : null}
          <button type="button" onClick={() => setSelectedPartIds(new Set())} aria-label="Clear selection" className="rounded-lg p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-700"><X className="h-4 w-4" /></button>
        </div>
      ) : null}

      {detailPart ? (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-slate-950/55 p-4 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="flex max-h-[92vh] w-full max-w-5xl flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl animate-in zoom-in-95 duration-200">
            <header className="flex items-center justify-between border-b border-slate-200 bg-slate-50/90 px-5 py-4">
              <div className="min-w-0">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-700"><Database className="h-4 w-4" />AutoCount Item</div>
                <h2 className="mt-1 truncate text-lg font-extrabold text-slate-900">{detailPart.sku} · {detailPart.name}</h2>
              </div>
              <button type="button" onClick={closeItemDetail} aria-label="Close Item details" className="ml-4 rounded-xl border border-slate-200 bg-white p-2 text-slate-500 shadow-sm hover:bg-slate-100 hover:text-slate-800"><X className="h-5 w-5" /></button>
            </header>

            <div className="overflow-y-auto p-5">
              {detailLoading ? (
                <div className="flex min-h-64 items-center justify-center text-sm font-medium text-slate-500"><RefreshCw className="mr-2 h-5 w-5 animate-spin text-blue-600" />Loading Item details...</div>
              ) : null}

              {!detailLoading && detailError ? (
                <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-4 text-sm text-amber-800">{detailError}</div>
              ) : null}

              {!detailLoading && itemDetail ? (
                <div className="space-y-5">
                  <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    <div className="rounded-xl border border-blue-100 bg-blue-50 p-3"><p className="text-[10px] font-bold uppercase tracking-wider text-blue-600">Item Code</p><p className="mt-1 break-all font-mono text-sm font-bold text-slate-900">{itemDetail.itemCode}</p></div>
                    <div className="rounded-xl border border-slate-200 bg-slate-50 p-3"><p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Item Group</p><p className="mt-1 text-sm font-bold text-slate-900">{itemFieldValue("ItemGroup", itemDetail.fields.ItemGroup)}</p></div>
                    <div className="rounded-xl border border-slate-200 bg-slate-50 p-3"><p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Active</p><p className="mt-1 text-sm font-bold text-slate-900">{itemFieldValue("IsActive", itemDetail.fields.IsActive)}</p></div>
                    <div className="rounded-xl border border-slate-200 bg-slate-50 p-3"><p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">AutoCount Image</p><p className="mt-1 text-sm font-bold text-slate-900">{itemDetail.image.hasImage ? `${itemDetail.image.size.toLocaleString()} bytes` : "No image"}</p></div>
                  </div>

                  {itemDetailSections.map((section) => {
                    const fields = section.fields.filter((field) => Object.prototype.hasOwnProperty.call(itemDetail.fields, field));
                    if (fields.length === 0) return null;
                    return (
                      <section key={section.title} className="overflow-hidden rounded-xl border border-slate-200">
                        <h3 className="border-b border-slate-200 bg-slate-50 px-4 py-2.5 text-xs font-extrabold uppercase tracking-wider text-slate-600">{section.title}</h3>
                        <div className="grid sm:grid-cols-2 lg:grid-cols-3">
                          {fields.map((field) => {
                            const value = itemFieldValue(field, itemDetail.fields[field]);
                            const isLong = value.length > 80;
                            return (
                              <div key={field} className={`${isLong ? "sm:col-span-2 lg:col-span-3" : ""} min-w-0 border-b border-r border-slate-100 px-4 py-3`}>
                                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">{itemFieldLabel(field)}</p>
                                <p className="mt-1 whitespace-pre-wrap break-words text-sm font-medium text-slate-800">{value}</p>
                              </div>
                            );
                          })}
                        </div>
                      </section>
                    );
                  })}

                  {Object.entries(itemDetail.fields).some(([field]) => !knownItemDetailFields.has(field)) ? (
                    <section className="overflow-hidden rounded-xl border border-slate-200">
                      <h3 className="border-b border-slate-200 bg-slate-50 px-4 py-2.5 text-xs font-extrabold uppercase tracking-wider text-slate-600">Additional fields</h3>
                      <div className="grid sm:grid-cols-2 lg:grid-cols-3">
                        {Object.entries(itemDetail.fields).filter(([field]) => !knownItemDetailFields.has(field)).map(([field, rawValue]) => (
                          <div key={field} className="min-w-0 border-b border-r border-slate-100 px-4 py-3"><p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">{itemFieldLabel(field)}</p><p className="mt-1 whitespace-pre-wrap break-words text-sm font-medium text-slate-800">{itemFieldValue(field, rawValue)}</p></div>
                        ))}
                      </div>
                    </section>
                  ) : null}
                </div>
              ) : null}
            </div>
          </div>
        </div>
      ) : null}

      {isImportModalOpen ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-3 backdrop-blur-sm sm:p-5">
          <div className="flex max-h-[94vh] w-full max-w-2xl flex-col overflow-hidden rounded-2xl border border-white/70 bg-white shadow-2xl">
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 bg-white px-5 py-4 sm:px-7 sm:py-5">
              <div className="flex items-start gap-3.5"><div className="mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-[#1e3a8a] ring-1 ring-blue-100"><Upload className="h-5 w-5" /></div><div>
                <h2 className="text-lg font-bold tracking-tight text-slate-900 sm:text-xl">Import AutoCount Parts</h2>
                <p className="mt-1 text-xs leading-5 text-slate-500 sm:text-sm">Review the selected CSV before creating or updating inventory records.</p>
              </div></div>
              <button type="button" onClick={() => setIsImportModalOpen(false)} aria-label="Close AutoCount import" className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="flex-1 space-y-4 overflow-y-auto bg-slate-50/80 p-4 sm:p-6">
              {importError ? (
                <div role="alert" className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                  {importError}
                </div>
              ) : null}
              <label className="flex cursor-pointer items-center justify-center rounded-xl border-2 border-dashed border-blue-200 bg-white p-6 shadow-sm transition hover:border-blue-300 hover:bg-blue-50/50">
                <div className="text-center">
                  <Upload className="mx-auto h-7 w-7 text-[#1e3a8a]" />
                  <p className="mt-2 text-sm font-semibold text-gray-800">{importFileName || "Select prepared AutoCount CSV"}</p>
                  <p className="mt-1 text-xs text-gray-500">Maximum 5,000 records · 5 MB</p>
                </div>
                <input
                  type="file"
                  accept=".csv,text/csv"
                  className="sr-only"
                  onChange={(event) => handleImportFile(event.target.files?.[0])}
                />
              </label>
              {importRows.length > 0 ? (
                <div className="space-y-3">
                  <div className="grid grid-cols-3 gap-3">
                    <div className="rounded-lg bg-blue-50 p-3"><p className="text-xs text-gray-500">Ready</p><p className="text-xl font-bold text-blue-700">{importRows.length}</p></div>
                    <div className="rounded-lg bg-amber-50 p-3"><p className="text-xs text-gray-500">Missing unit cost</p><p className="text-xl font-bold text-amber-700">{missingImportCosts}</p></div>
                    <div className="rounded-lg bg-gray-100 p-3"><p className="text-xs text-gray-500">Imported stock</p><p className="text-xl font-bold text-gray-700">{importedStockTotal.toLocaleString()}</p></div>
                  </div>
                  <div className="overflow-hidden rounded-lg border border-gray-200">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-gray-50 text-gray-500"><tr><th className="px-3 py-2">SKU</th><th className="px-3 py-2">Name</th><th className="px-3 py-2">UOM</th><th className="px-3 py-2 text-right">Stock</th><th className="px-3 py-2 text-right">Cost</th></tr></thead>
                      <tbody>
                        {importRows.slice(0, IMPORT_PREVIEW_LIMIT).map((part) => (
                          <tr key={part.sku} className="border-t border-gray-100"><td className="px-3 py-2 font-mono">{part.sku}</td><td className="max-w-xs truncate px-3 py-2">{part.name}</td><td className="px-3 py-2">{part.uom || "-"}</td><td className="px-3 py-2 text-right">{part.stock ?? "-"}</td><td className="px-3 py-2 text-right">{part.cost === undefined ? "-" : `RM ${part.cost.toFixed(2)}`}</td></tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <p className="text-xs text-gray-500">Only columns present in the CSV are updated. Missing fields are preserved for existing SKUs.</p>
                </div>
              ) : null}
            </div>
            <div className="flex items-center justify-end gap-2.5 border-t border-slate-200 bg-white px-4 py-3.5 sm:px-7">
              <button type="button" onClick={() => setIsImportModalOpen(false)} className="h-10 rounded-lg border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-700 hover:bg-slate-50">Cancel</button>
              <button type="button" disabled={importRows.length === 0 || importing} onClick={handleImportParts} className="inline-flex h-10 items-center gap-2 rounded-lg bg-[#1e3a8a] px-5 text-sm font-semibold text-white shadow-sm disabled:opacity-50">
                <Upload className="h-4 w-4" />{importing ? "Importing..." : `Import ${importRows.length || ""} Parts`}
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {/* Add / Edit Part Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-3 backdrop-blur-sm transition-opacity sm:p-5">
          <div className="flex max-h-[94vh] w-full max-w-4xl flex-col overflow-hidden rounded-2xl border border-white/70 bg-white shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 bg-white px-5 py-4 sm:px-7 sm:py-5">
              <div className="flex items-start gap-3.5"><div className="mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-[#1e3a8a] ring-1 ring-blue-100"><Package className="h-5 w-5" /></div><div><h2 className="text-lg font-bold tracking-tight text-slate-900 sm:text-xl">
                {modalMode === "create" ? t("add_part") : `${t("edit")} - ${name}`}
              </h2><p className="mt-1 text-xs leading-5 text-slate-500 sm:text-sm">Maintain AutoCount identity, pricing, stock controls and item media.</p></div></div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                aria-label="Close part dialog"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="flex flex-col flex-1 overflow-hidden">
              <div className="flex-1 space-y-4 overflow-y-auto bg-slate-50/80 p-4 sm:p-6">
                {formError && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600 font-medium">
                    {formError}
                  </div>
                )}

                <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
                  <div className="flex items-start gap-3 rounded-t-xl border-b border-slate-100 bg-white px-4 py-3.5 sm:px-5"><div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-blue-50 text-blue-700"><Package className="h-4 w-4" /></div><div><h3 className="text-sm font-bold text-slate-900">1. Item profile</h3><p className="mt-0.5 text-xs text-slate-500">Enter item identity, AutoCount mapping, stock and supplier details.</p></div></div>
                  <div className="space-y-4 p-4 sm:p-5">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                    {t("part_name")} *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                    placeholder="e.g. Engine Oil 15W-40"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                      AutoCount Stock Group
                    </label>
                    <AdminSelect
                      value={itemGroup}
                      onChange={(event) => {
                        const nextGroup = event.target.value;
                        const group = stockGroupMap.get(nextGroup);
                        setItemGroup(nextGroup);
                        setCategory(group?.description || nextGroup || "Others");
                        if (group) {
                          setItemType(group.itemType);
                          setIsStockItem(group.itemType === "part" || group.itemType === "vehicle");
                        }
                      }}
                      className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">No AutoCount group</option>
                      {itemGroupOptions.map((groupCode) => (
                        <option key={groupCode} value={groupCode}>
                          {groupCode}{stockGroupMap.get(groupCode)?.description ? ` — ${stockGroupMap.get(groupCode)?.description}` : ""}
                        </option>
                      ))}
                    </AdminSelect>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                      AutoCount Item Code *
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={80}
                      value={sku}
                      onChange={(e) => setSku(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm font-mono"
                      placeholder="Symbols and spaces are preserved"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">Item Type</label>
                    <AdminSelect
                      value={itemType}
                      onChange={(event) => {
                        const nextType = event.target.value as ItemType;
                        setItemType(nextType);
                        setIsStockItem(nextType === "part" || nextType === "vehicle");
                      }}
                      className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      {Object.entries(itemTypeLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
                    </AdminSelect>
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-gray-700">Tax Code</label>
                    <input type="text" maxLength={30} value={taxCode} onChange={(event) => setTaxCode(event.target.value)} placeholder="Optional" className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm uppercase focus:outline-none focus:ring-2 focus:ring-blue-500" />
                  </div>
                </div>

                {itemType === "vehicle" ? <div className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">Vehicle Sales items stay outside the workshop Work Order and Purchase Order item selectors.</div> : null}

                <div className="grid grid-cols-3 gap-4">
                  {canViewCost ? <div>
                    <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                      {t("unit_price")} (RM)
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                      placeholder="0.00"
                    />
                  </div> : null}
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                      Unit Cost (RM)
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={cost}
                      onChange={(e) => setCost(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                      placeholder="0.00"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                      UOM
                    </label>
                    <input
                      type="text"
                      value={uom}
                      onChange={(e) => setUom(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                      placeholder="PCS"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                      {t("stock_quantity")}
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="0.001"
                      value={stock}
                      onChange={(e) => setStock(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                      placeholder="0"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                      Low Threshold
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="0.001"
                      value={lowStockThreshold}
                      onChange={(e) => setLowStockThreshold(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                      placeholder="10"
                    />
                  </div>
                </div>

                <div className="flex flex-wrap gap-4 rounded-lg border border-gray-200 bg-gray-50 px-4 py-3 text-sm text-gray-700">
                  <label className="inline-flex items-center gap-2"><input type="checkbox" checked={isStockItem} onChange={(event) => setIsStockItem(event.target.checked)} className="h-4 w-4 rounded border-gray-300" />Track stock quantity</label>
                  <label className="inline-flex items-center gap-2"><input type="checkbox" checked={isActive} onChange={(event) => setIsActive(event.target.checked)} className="h-4 w-4 rounded border-gray-300" />Active item</label>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                    {t("supplier")}
                  </label>
                  <input
                    type="text"
                    value={supplier}
                    onChange={(e) => setSupplier(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                    placeholder="e.g. Bosch Malaysia"
                  />
                  {editingPart?.supplierName ? <p className="mt-1 text-xs font-medium text-blue-700">{editingPart.supplierName}</p> : null}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                    Part Image
                  </label>
                  <div className="rounded-xl border border-dashed border-gray-300 bg-gray-50 p-3">
                    <div className="flex items-center gap-3">
                      <div className="flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-gray-200 bg-white">
                        {imageData || image ? (
                          <img
                            src={imageData || image}
                            alt="Part preview"
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <ImageIcon className="h-7 w-7 text-gray-300" />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <label className="inline-flex cursor-pointer items-center rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-100">
                          <Upload className="mr-2 h-4 w-4" />
                          Choose Image
                          <input
                            key={imageInputKey}
                            type="file"
                            accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                            onChange={(event) => handleImageSelection(event.target.files?.[0])}
                            className="sr-only"
                          />
                        </label>
                        <p className="mt-2 truncate text-xs text-gray-500">
                          {imageFileName || (image ? "Current image" : "JPG, PNG or WebP · max 3 MB")}
                        </p>
                        {(imageData || image) && (
                          <button
                            type="button"
                            onClick={removeImage}
                            className="mt-1 text-xs font-semibold text-red-600 hover:text-red-700"
                          >
                            Remove image
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                  </div>
                </section>
              </div>

              <div className="flex flex-col-reverse gap-3 border-t border-slate-200 bg-white px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between sm:px-7">
                <p className="text-xs text-slate-500"><span className="font-bold text-red-500">*</span> Required fields must be completed</p>
                <div className="flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="h-10 rounded-lg border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-700 hover:bg-slate-50"
                >
                  {t("cancel")}
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex h-10 items-center gap-2 rounded-lg bg-[#1e3a8a] px-5 text-sm font-semibold text-white shadow-sm hover:bg-blue-800 disabled:opacity-50"
                >
                  <Save className="h-4 w-4" />{submitting ? "Saving..." : modalMode === "create" ? "Create Part" : "Save Changes"}
                </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
