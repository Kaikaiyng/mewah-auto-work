import { useMemo, useState } from "react";
import {
  Activity,
  CalendarDays,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Fingerprint,
  Search,
  ShieldCheck,
  UserRound,
  Download,
} from "lucide-react";
import { useApiData } from "../lib/use-api-data";
import { AdminSelect } from "./ui/admin-select";
import { exportTableToExcel, ExcelColumnDef } from "../lib/excel-export";
import { toast } from "sonner";

interface AuditItem {
  id: number;
  action: string;
  category: string;
  entityType: string;
  entityId: string;
  entityLabel: string;
  description: string;
  metadata: Record<string, unknown>;
  actorId: number;
  actorName: string;
  actorRole: string;
  ipAddress: string;
  userAgent: string;
  createdAt: string;
}

interface AuditResponse {
  items: AuditItem[];
  stats: {
    total: number;
    today: number;
    activeActors: number;
    securityEvents: number;
  };
}

const EMPTY_AUDIT_RESPONSE: AuditResponse = {
  items: [],
  stats: { total: 0, today: 0, activeActors: 0, securityEvents: 0 },
};

const PAGE_SIZE = 25;

function readableAction(action: string) {
  return action
    .replace(/^(admin-|workshop-|customer-)/, "")
    .split("-")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

function actorSourceLabel(action: string, actorRole: string) {
  if (action.startsWith("customer-")) return "Customer";
  if (action.startsWith("workshop-")) return actorRole || "Workshop";
  return actorRole || "Admin";
}

function formatDateTime(value: string) {
  if (!value) return "-";
  const parsed = new Date(value.replace(" ", "T"));
  if (Number.isNaN(parsed.getTime())) return value;
  return new Intl.DateTimeFormat("en-MY", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(parsed);
}

function categoryTone(category: string) {
  const tones: Record<string, string> = {
    Workshop: "border-blue-200 bg-blue-50 text-blue-700",
    Inventory: "border-amber-200 bg-amber-50 text-amber-700",
    Finance: "border-emerald-200 bg-emerald-50 text-emerald-700",
    "Security & Admin": "border-violet-200 bg-violet-50 text-violet-700",
    "Customer Data": "border-cyan-200 bg-cyan-50 text-cyan-700",
    "Customer Portal": "border-teal-200 bg-teal-50 text-teal-700",
    Communication: "border-pink-200 bg-pink-50 text-pink-700",
  };
  return tones[category] || "border-slate-200 bg-slate-50 text-slate-700";
}

export function AuditTrail() {
  const { data, isLoading, error, reload } = useApiData<AuditResponse>(
    "admin-audit-trail",
    EMPTY_AUDIT_RESPONSE,
  );
  const [searchTerm, setSearchTerm] = useState("");
  const [category, setCategory] = useState("all");
  const [actor, setActor] = useState("all");
  const [dateRange, setDateRange] = useState("30");
  const [page, setPage] = useState(1);
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const categories = useMemo(
    () => Array.from(new Set(data.items.map((item) => item.category))).sort(),
    [data.items],
  );
  const actors = useMemo(
    () => Array.from(new Set(data.items.map((item) => item.actorName))).sort(),
    [data.items],
  );

  const filteredItems = useMemo(() => {
    const query = searchTerm.trim().toLowerCase();
    const rangeDays = Number(dateRange);
    const minimumDate = rangeDays > 0 ? Date.now() - rangeDays * 86_400_000 : 0;
    return data.items.filter((item) => {
      const searchable = [
        item.action,
        item.description,
        item.actorName,
        item.actorRole,
        item.entityType,
        item.entityId,
        item.entityLabel,
        item.ipAddress,
      ].join(" ").toLowerCase();
      const timestamp = new Date(item.createdAt.replace(" ", "T")).getTime();
      return (!query || searchable.includes(query))
        && (category === "all" || item.category === category)
        && (actor === "all" || item.actorName === actor)
        && (!minimumDate || (!Number.isNaN(timestamp) && timestamp >= minimumDate));
    });
  }, [actor, category, data.items, dateRange, searchTerm]);

  const totalPages = Math.max(1, Math.ceil(filteredItems.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const visibleItems = filteredItems.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);

  const updateFilter = (update: () => void) => {
    update();
    setPage(1);
    setExpandedId(null);
  };

  const handleExportAudit = async () => {
    if (filteredItems.length === 0) {
      toast.error("No audit records available to export.");
      return;
    }

    const columnDefs: ExcelColumnDef[] = [
      { header: "Timestamp", key: "createdAt", align: "center", minWidth: 20 },
      { header: "Actor Name", key: "actorName", align: "left", minWidth: 20 },
      { header: "Role / Source", key: "actorRole", align: "left", minWidth: 16 },
      { header: "Action", key: "action", align: "left", minWidth: 24 },
      { header: "Category", key: "category", align: "left", minWidth: 16 },
      { header: "Entity Type", key: "entityType", align: "left", minWidth: 16 },
      { header: "Record Identifier", key: "entityLabel", align: "left", minWidth: 22 },
      { header: "Description", key: "description", align: "left", minWidth: 36 },
      { header: "IP Address", key: "ipAddress", align: "center", minWidth: 16, numFmt: "@" },
    ];

    const rows = filteredItems.map((item) => ({
      createdAt: item.createdAt ? String(item.createdAt).slice(0, 19).replace("T", " ") : "-",
      actorName: String(item.actorName || "-"),
      actorRole: String(item.actorRole || "-"),
      action: readableAction(item.action),
      category: String(item.category || "-").toUpperCase(),
      entityType: String(item.entityType || "-"),
      entityLabel: String(item.entityLabel || item.entityId || "-"),
      description: String(item.description || "-"),
      ipAddress: String(item.ipAddress || "-"),
    }));

    const fileName = `maw-audit-trail-${new Date().toISOString().slice(0, 10)}.xlsx`;
    await exportTableToExcel({
      fileName,
      sheetName: "Audit Trail",
      columns: columnDefs,
      data: rows,
      successMessage: `Exported ${filteredItems.length} audit logs to ${fileName}`,
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-blue-200 bg-blue-50 text-[#1e3a8a]">
              <ShieldCheck className="h-5 w-5" />
            </span>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">Audit Trail</h1>
              <p className="mt-0.5 text-sm text-slate-500">Successful actions by admins, workshop staff, and customers.</p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportAudit}
            disabled={isLoading || filteredItems.length === 0}
            className="inline-flex h-10 items-center justify-center rounded-xl border border-gray-300 bg-white px-4 text-sm font-semibold text-gray-700 shadow-sm transition-colors hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Download className="mr-2 h-4 w-4" />
            Export Excel
          </button>
          <span className="inline-flex items-center rounded-full border border-violet-200 bg-violet-50 px-3 py-1.5 text-xs font-bold text-violet-700">
            <Fingerprint className="mr-1.5 h-3.5 w-3.5" />
            Super Admin only
          </span>
        </div>
      </div>

      {error ? (
        <div className="flex items-center justify-between gap-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700" role="alert">
          <span>Audit Trail is unavailable: {error}</span>
          <button type="button" onClick={() => void reload()} className="font-semibold underline underline-offset-2">Retry</button>
        </div>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "Total events", value: data.stats.total, icon: Activity, tone: "text-blue-700 bg-blue-50" },
          { label: "Today", value: data.stats.today, icon: CalendarDays, tone: "text-cyan-700 bg-cyan-50" },
          { label: "Active actors · 30 days", value: data.stats.activeActors, icon: UserRound, tone: "text-emerald-700 bg-emerald-50" },
          { label: "Security & admin", value: data.stats.securityEvents, icon: ShieldCheck, tone: "text-violet-700 bg-violet-50" },
        ].map((stat) => (
          <div key={stat.label} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">{stat.label}</p>
                <p className="mt-2 text-2xl font-black text-slate-900">{stat.value.toLocaleString()}</p>
              </div>
              <span className={`flex h-9 w-9 items-center justify-center rounded-lg ${stat.tone}`}><stat.icon className="h-4 w-4" /></span>
            </div>
          </div>
        ))}
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-3 shadow-sm">
        <div className="grid gap-3 lg:grid-cols-[minmax(260px,1fr)_220px_220px_170px]">
          <label className="relative block">
            <span className="sr-only">Search audit trail</span>
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="search"
              value={searchTerm}
              onChange={(event) => updateFilter(() => setSearchTerm(event.target.value))}
              placeholder="Search action, person, record or IP..."
              className="h-10 w-full rounded-lg border border-slate-300 bg-white pl-10 pr-3 text-sm outline-none transition focus:border-blue-400 focus:ring-2 focus:ring-blue-100"
            />
          </label>
          <AdminSelect value={category} onChange={(event) => updateFilter(() => setCategory(event.target.value))} className="w-full">
            <option value="all">All categories</option>
            {categories.map((item) => <option key={item} value={item}>{item}</option>)}
          </AdminSelect>
          <AdminSelect value={actor} onChange={(event) => updateFilter(() => setActor(event.target.value))} className="w-full">
            <option value="all">All actors</option>
            {actors.map((item) => <option key={item} value={item}>{item}</option>)}
          </AdminSelect>
          <AdminSelect value={dateRange} onChange={(event) => updateFilter(() => setDateRange(event.target.value))} className="w-full">
            <option value="7">Last 7 days</option>
            <option value="30">Last 30 days</option>
            <option value="90">Last 90 days</option>
            <option value="0">All retained</option>
          </AdminSelect>
        </div>
      </div>

      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1020px] text-left">
            <thead className="border-b border-slate-200 bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-500">
              <tr>
                <th className="px-4 py-3">Date & time</th>
                <th className="px-4 py-3">Actor</th>
                <th className="px-4 py-3">Action</th>
                <th className="px-4 py-3">Record</th>
                <th className="px-4 py-3">Category</th>
                <th className="w-12 px-4 py-3"><span className="sr-only">Details</span></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {isLoading ? (
                <tr><td colSpan={6} className="px-4 py-16 text-center text-sm text-slate-500">Loading audit events...</td></tr>
              ) : visibleItems.length === 0 ? (
                <tr><td colSpan={6} className="px-4 py-16 text-center text-sm text-slate-500">No audit events match these filters.</td></tr>
              ) : visibleItems.map((item) => {
                const expanded = expandedId === item.id;
                return [
                  <tr key={`row-${item.id}`} className="transition-colors hover:bg-slate-50/70">
                    <td className="whitespace-nowrap px-4 py-3 text-sm text-slate-600">{formatDateTime(item.createdAt)}</td>
                    <td className="px-4 py-3">
                      <p className="text-sm font-semibold text-slate-900">{item.actorName}</p>
                      <p className="mt-0.5 text-xs text-slate-500">{actorSourceLabel(item.action, item.actorRole)}{item.ipAddress ? ` · ${item.ipAddress}` : ""}</p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm font-semibold text-slate-900">{readableAction(item.action)}</p>
                      <p className="mt-0.5 max-w-[340px] truncate text-xs text-slate-500" title={item.description}>{item.description}</p>
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-700">
                      <span className="font-medium capitalize">{item.entityType.replaceAll("-", " ")}</span>
                      {item.entityLabel || item.entityId ? <p className="mt-0.5 text-xs text-slate-500">{item.entityLabel || `#${item.entityId}`}</p> : null}
                    </td>
                    <td className="px-4 py-3"><span className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-semibold ${categoryTone(item.category)}`}>{item.category}</span></td>
                    <td className="px-4 py-3">
                      <button
                        type="button"
                        onClick={() => setExpandedId(expanded ? null : item.id)}
                        className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        aria-label={expanded ? "Hide audit details" : "Show audit details"}
                        aria-expanded={expanded}
                      >
                        <ChevronDown className={`h-4 w-4 transition-transform ${expanded ? "rotate-180" : ""}`} />
                      </button>
                    </td>
                  </tr>,
                  expanded ? (
                    <tr key={`details-${item.id}`} className="bg-slate-50/80">
                      <td colSpan={6} className="px-4 py-4">
                        <div className="grid gap-4 rounded-xl border border-slate-200 bg-white p-4 lg:grid-cols-[1fr_1.4fr]">
                          <div className="space-y-2 text-sm">
                            <p><span className="font-semibold text-slate-700">Event ID:</span> <span className="text-slate-600">#{item.id}</span></p>
                            <p><span className="font-semibold text-slate-700">API action:</span> <code className="rounded bg-slate-100 px-1.5 py-0.5 text-xs text-slate-700">{item.action}</code></p>
                            <p><span className="font-semibold text-slate-700">Record:</span> <span className="text-slate-600">{item.entityType}{item.entityId ? ` #${item.entityId}` : ""}{item.entityLabel ? ` · ${item.entityLabel}` : ""}</span></p>
                            <p><span className="font-semibold text-slate-700">Browser:</span> <span className="break-words text-xs text-slate-500">{item.userAgent || "Not recorded"}</span></p>
                          </div>
                          <div>
                            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">Sanitised request details</p>
                            <pre className="max-h-52 overflow-auto whitespace-pre-wrap break-words rounded-lg bg-slate-950 p-3 text-xs leading-relaxed text-slate-200">{JSON.stringify(item.metadata, null, 2)}</pre>
                          </div>
                        </div>
                      </td>
                    </tr>
                  ) : null,
                ];
              })}
            </tbody>
          </table>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 bg-slate-50/70 px-4 py-3">
          <p className="text-xs text-slate-500">Showing {visibleItems.length} of {filteredItems.length.toLocaleString()} matching events</p>
          <div className="flex items-center gap-2">
            <button type="button" onClick={() => setPage((current) => Math.max(1, current - 1))} disabled={safePage === 1} className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-300 bg-white text-slate-600 disabled:cursor-not-allowed disabled:opacity-40" aria-label="Previous page"><ChevronLeft className="h-4 w-4" /></button>
            <span className="min-w-20 text-center text-xs font-semibold text-slate-600">{safePage} / {totalPages}</span>
            <button type="button" onClick={() => setPage((current) => Math.min(totalPages, current + 1))} disabled={safePage === totalPages} className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-300 bg-white text-slate-600 disabled:cursor-not-allowed disabled:opacity-40" aria-label="Next page"><ChevronRight className="h-4 w-4" /></button>
          </div>
        </div>
      </div>
    </div>
  );
}
