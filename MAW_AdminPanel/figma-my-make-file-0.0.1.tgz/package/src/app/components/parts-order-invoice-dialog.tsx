import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, CheckCircle2, FileDown, Plus, Printer, RefreshCw, Send, Trash2, X, XCircle, ReceiptText } from "lucide-react";
import { toast } from "sonner";
import logo from "../../MAW_logo.png";
import { apiRequest, postApi } from "../lib/api";
import {
  DocumentItemCatalogSelect,
  type DocumentCatalogPart,
} from "./ui/document-item-catalog-select";
import { AdminSelect } from "./ui/admin-select";
import { DesktopDatePicker } from "./ui/desktop-date-picker";

export type PartsOrderItem = {
  name: string;
  quantity: number;
  price: number;
  code?: string;
  taxCode?: string;
  taxRate?: number;
};

export type PartsOrderData = {
  id: string;
  customer: string;
  items: PartsOrderItem[];
  total: number;
  status: "Pending" | "Processing" | "Shipped" | "Delivered";
  orderDate: string;
  deliveryAddress: string;
  autocountDoNo?: string;
  autocountSyncStatus?: string;
  autocountSyncAt?: string | null;
  debtorCode?: string;
};

export interface InvoiceLine {
  id?: number;
  type: "part" | "labour" | "other";
  serviceTypeId?: number | null;
  code: string;
  description: string;
  quantity: number;
  unitPrice: number;
  taxCode: string;
  taxRate: number;
}

export interface InvoiceForm {
  docType: "INVOICE" | "DO";
  isBackOrder?: boolean;
  invoiceDate: string;
  dueDate: string;
  creditTermDays: number;
  autocountJobNo: string;
  debtorCode: string;
  vehicleType: string;
  vehicleNo: string;
  discount: number;
  notes: string;
  paymentInstructions: string;
  items: InvoiceLine[];
}

const DEFAULT_INSTRUCTIONS =
  "On payment our official receipt will be forwarded to you by return mail.\nAll cheques to be crossed & made payable to Mewah Autoworks Sdn Bhd.\nPlease add bank commission on all outstation cheques.\nHong Leong Islamic Bank: 37801017381";

function isoDate(offsetDays = 0) {
  const value = new Date();
  value.setDate(value.getDate() + offsetDays);
  return value.toISOString().slice(0, 10);
}

function money(value: number) {
  return Number(value || 0).toLocaleString("en-MY", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function displayDate(value?: string | null) {
  if (!value) return "—";
  const date = new Date(value.includes("T") ? value : `${value}T00:00:00`);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString("en-GB");
}

function computeDueDate(invoiceDateStr: string, termDays: number): string {
  try {
    const d = new Date(invoiceDateStr);
    if (!isNaN(d.getTime())) {
      d.setDate(d.getDate() + (Number(termDays) || 0));
      return d.toISOString().slice(0, 10);
    }
  } catch {}
  return invoiceDateStr;
}

export function PartsOrderInvoiceDialog({
  order,
  onClose,
  onChanged,
  backLabel = "Back to Orders",
}: {
  order: PartsOrderData;
  onClose: () => void;
  onChanged: () => void | Promise<void>;
  backLabel?: string;
}) {
  const [catalogParts, setCatalogParts] = useState<DocumentCatalogPart[]>([]);
  const [debtors, setDebtors] = useState<{ code: string; name: string; term?: string }[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const [form, setForm] = useState<InvoiceForm>(() => {
    const invDate = order.orderDate || isoDate();
    const term = 30;
    return {
      docType: "DO",
      isBackOrder: false,
      invoiceDate: invDate,
      dueDate: computeDueDate(invDate, term),
      creditTermDays: term,
      autocountJobNo: order.id,
      debtorCode: order.debtorCode || "",
      vehicleType: "Parts Order",
      vehicleNo: "-",
      discount: 0,
      notes: "",
      paymentInstructions: DEFAULT_INSTRUCTIONS,
      items: (order.items && order.items.length > 0)
        ? order.items.map((i, idx) => ({
            id: idx + 1,
            type: "part",
            serviceTypeId: null,
            code: i.code || "",
            description: i.name,
            quantity: Number(i.quantity) || 1,
            unitPrice: Number(i.price) || 0,
            taxCode: i.taxCode || "",
            taxRate: i.taxRate || 0,
          }))
        : [{ type: "part", serviceTypeId: null, code: "", description: "Spare part item", quantity: 1, unitPrice: 0, taxCode: "", taxRate: 0 }],
    };
  });

  useEffect(() => {
    let active = true;
    Promise.all([
      apiRequest<DocumentCatalogPart[]>("admin-parts").catch(() => []),
      apiRequest<{ debtors?: { code: string; name: string; term?: string }[] } | { code: string; name: string; term?: string }[]>("admin-debtors")
        .then((res) => (Array.isArray(res) ? res : res?.debtors || []))
        .catch(() => []),
    ]).then(([loadedParts, loadedDebtors]) => {
      if (!active) return;
      setCatalogParts(loadedParts || []);
      const debtorList = Array.isArray(loadedDebtors) ? loadedDebtors : [];
      setDebtors(debtorList);
      if (!form.debtorCode && debtorList.length > 0) {
        const matched = debtorList.find(
          (d) =>
            d.name.toLowerCase().includes(order.customer.toLowerCase()) ||
            order.customer.toLowerCase().includes(d.name.toLowerCase())
        );
        if (matched) {
          let nextTerm = form.creditTermDays;
          if (matched.term) {
            const m = matched.term.match(/\d+/);
            if (m) nextTerm = Number(m[0]);
          }
          setForm((cur) => ({
            ...cur,
            debtorCode: matched.code,
            creditTermDays: nextTerm,
            dueDate: computeDueDate(cur.invoiceDate, nextTerm),
          }));
        }
      }
    });
    return () => {
      active = false;
    };
  }, []);

  const totals = useMemo(() => {
    const subtotal = form.items.reduce((sum, item) => sum + (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0), 0);
    const afterDiscount = Math.max(0, subtotal - (Number(form.discount) || 0));
    const taxAmount = 0;
    const total = afterDiscount + taxAmount;
    return { subtotal, discount: Number(form.discount) || 0, taxAmount, total };
  }, [form.items, form.discount]);

  const updateItem = (index: number, patch: Partial<InvoiceLine>) => {
    setForm((current) => {
      const nextItems = current.items.map((item, itemIndex) => {
        if (itemIndex !== index) return item;
        return { ...item, ...patch };
      });
      return { ...current, items: nextItems };
    });
  };

  const handleSave = async (isIssue = true) => {
    setSaving(true);
    setError("");
    try {
      if (isIssue) {
        await postApi("admin-update-order-status", {
          id: order.id,
          orderId: order.id,
          status: "processing",
        });
        toast.success(`Parts Order ${order.id} issued & queued for AutoCount ${form.docType} sync!`);
      } else {
        toast.success(`Parts Order invoice draft saved.`);
      }
      await onChanged();
      onClose();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Unable to save invoice.");
      toast.error(caught instanceof Error ? caught.message : "Unable to save invoice.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="invoice-print-shell space-y-4">
      <style>{`@media print { @page { size: A4 portrait; margin: 10mm; } html, body { height:auto!important; overflow:visible!important; background:#fff!important; } #root { display:none!important; } body * { visibility:hidden!important; } .invoice-print-shell, #invoice-document, #invoice-document * { visibility:visible!important; } .invoice-print-shell { display:block!important; position:static!important; inset:auto!important; margin:0!important; padding:0!important; background:#fff!important; } .invoice-frame, .invoice-layout, .invoice-stage { display:block!important; position:static!important; width:auto!important; max-width:none!important; height:auto!important; max-height:none!important; overflow:visible!important; background:#fff!important; box-shadow:none!important; } .no-print { display:none!important; } #invoice-document { width:100%!important; min-height:0!important; max-width:none!important; margin:0!important; padding:0!important; box-shadow:none!important; } #invoice-document thead { display:table-header-group; } #invoice-document tr { break-inside:avoid-page; } }`}</style>
      <div className="invoice-frame flex w-full flex-col overflow-hidden rounded-2xl border border-slate-200 bg-slate-100 shadow-sm">
          <header className="no-print flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 bg-white px-5 py-4 sm:px-7 sm:py-5">
            <div className="flex flex-wrap items-center gap-3.5">
              <button
                type="button"
                onClick={onClose}
                className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50 cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" />
                {backLabel}
              </button>
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-[#1e3a8a] ring-1 ring-blue-100">
                <ReceiptText className="h-5 w-5" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-lg font-extrabold text-slate-900">
                    {form.docType === "DO" ? "Delivery Order" : "Invoice"} · {order.id}
                  </h2>
                  <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-bold uppercase text-slate-800">
                    {order.status}
                  </span>
                  <span className={`rounded-full px-2.5 py-1 text-[10px] font-bold uppercase ${
                    order.autocountSyncStatus === "synced"
                      ? "bg-emerald-100 text-emerald-800"
                      : "bg-amber-100 text-amber-800"
                  }`}>
                    AutoCount: {order.autocountSyncStatus === "synced" ? "synced" : "queued"}
                  </span>
                </div>
                <p className="mt-0.5 text-xs text-slate-500">
                  Create the invoice in MAW, then queue and sync to AutoCount ERP billing.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => window.print()}
                className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 shadow-sm hover:bg-slate-50 cursor-pointer"
                aria-label="Print invoice"
              >
                <Printer className="h-4 w-4" />
                Print Invoice
              </button>
              <button
                type="button"
                onClick={onClose}
                className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700 cursor-pointer"
                aria-label="Close dialog"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </header>

          <div className="invoice-layout grid min-h-0 flex-1 lg:grid-cols-[470px_minmax(0,1fr)]">
            {/* Left Sidebar Form with exact 1:1 card layout */}
            <aside className="no-print overflow-y-auto border-r border-slate-200 bg-slate-100/80 p-4 sm:p-5">
              {error ? <div className="mb-4 rounded-xl border border-rose-200 bg-rose-50 p-3 text-xs text-rose-700">{error}</div> : null}
              <div className="space-y-5 [&>div:nth-child(n+2):nth-child(-n+5)]:rounded-xl [&>div:nth-child(n+2):nth-child(-n+5)]:border [&>div:nth-child(n+2):nth-child(-n+5)]:border-slate-200 [&>div:nth-child(n+2):nth-child(-n+5)]:bg-white [&>div:nth-child(n+2):nth-child(-n+5)]:p-3 [&>div:nth-child(n+2):nth-child(-n+5)]:shadow-sm [&>div:nth-child(6)]:rounded-2xl [&>div:nth-child(6)]:border [&>div:nth-child(6)]:border-slate-200 [&>div:nth-child(6)]:border-l-4 [&>div:nth-child(6)]:border-l-blue-500 [&>div:nth-child(6)]:bg-white [&>div:nth-child(6)]:p-4 [&>div:nth-child(6)]:shadow-sm [&>div:nth-child(6)>div:first-child]:border-b [&>div:nth-child(6)>div:first-child]:border-slate-100 [&>div:nth-child(6)>div:first-child]:pb-3 [&>label]:rounded-xl [&>label]:border [&>label]:border-slate-200 [&>label]:border-l-4 [&>label]:border-l-slate-300 [&>label]:bg-white [&>label]:p-4 [&>label]:shadow-sm">
                
                {/* Header Card */}
                <div className="flex items-start gap-3 rounded-2xl border border-blue-100 bg-blue-50/80 p-4">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#1e3a8a] text-white">
                    <ReceiptText className="h-4 w-4" />
                  </span>
                  <div>
                    <h3 className="text-sm font-extrabold text-slate-900">
                      {form.docType === "DO" ? "Delivery Order setup" : "Invoice setup"}
                    </h3>
                    <p className="mt-0.5 text-xs leading-5 text-slate-600">
                      Confirm document type, dates, and AutoCount references.
                    </p>
                  </div>
                </div>

                {/* Sync Document Type Toggle */}
                <div>
                  <label className="mb-1.5 block text-xs font-bold text-slate-700">Sync Document Type</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setForm((current) => ({ ...current, docType: "INVOICE" }))}
                      className={`flex items-center justify-center gap-1.5 rounded-lg border py-2.5 text-xs font-bold transition-all cursor-pointer ${
                        form.docType === "INVOICE"
                          ? "border-blue-600 bg-blue-50 text-blue-800 shadow-xs ring-1 ring-blue-500/20"
                          : "border-slate-200 bg-white text-slate-600 hover:bg-slate-50"
                      }`}
                    >
                      <span>Sales Invoice</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setForm((current) => ({ ...current, docType: "DO" }))}
                      className={`flex items-center justify-center gap-1.5 rounded-lg border py-2.5 text-xs font-bold transition-all cursor-pointer ${
                        form.docType === "DO"
                          ? "border-indigo-600 bg-indigo-50 text-indigo-800 shadow-xs ring-1 ring-indigo-500/20"
                          : "border-slate-200 bg-white text-slate-600 hover:bg-slate-50"
                      }`}
                    >
                      <span>Delivery Order (DO)</span>
                    </button>
                  </div>
                </div>

                {/* Back Order Switch */}
                <div className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-3 shadow-sm">
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-slate-800">Back Order</span>
                      {form.isBackOrder ? (
                        <span className="rounded-full bg-purple-100 px-2 py-0.5 text-[10px] font-bold text-purple-700">
                          Bypass Stock
                        </span>
                      ) : null}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {form.isBackOrder
                        ? "Enabled: Issue without deducting VIP physical inventory."
                        : "Disabled: Standard stock verification applies."}
                    </p>
                  </div>
                  <label className="relative inline-flex cursor-pointer items-center">
                    <input
                      type="checkbox"
                      checked={Boolean(form.isBackOrder)}
                      onChange={(e) => setForm((cur) => ({ ...cur, isBackOrder: e.target.checked }))}
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-purple-600"></div>
                  </label>
                </div>

                {/* Dates */}
                <div className="grid grid-cols-2 gap-3">
                  <label className="text-xs font-bold text-slate-700">
                    Document date
                    <DesktopDatePicker
                      value={form.invoiceDate}
                      onChange={(value) =>
                        setForm((current) => ({
                          ...current,
                          invoiceDate: value,
                          dueDate: computeDueDate(value, current.creditTermDays),
                        }))
                      }
                      ariaLabel="Choose document date"
                      className="mt-1 h-10 bg-slate-50"
                    />
                  </label>
                  <label className="text-xs font-bold text-slate-700">
                    Due date
                    <DesktopDatePicker
                      value={form.dueDate}
                      onChange={(value) => setForm((current) => ({ ...current, dueDate: value }))}
                      ariaLabel="Choose document due date"
                      className="mt-1 h-10 bg-slate-50"
                    />
                  </label>
                </div>

                {/* AutoCount Job No. & Debtor Code */}
                <div className="grid grid-cols-2 gap-3">
                  <label className="text-xs font-bold text-slate-700">
                    AutoCount Job No.
                    <input
                      value={form.autocountJobNo}
                      onChange={(event) =>
                        setForm((current) => ({ ...current, autocountJobNo: event.target.value.toUpperCase() }))
                      }
                      className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 uppercase font-medium text-xs"
                    />
                  </label>
                  <label className="text-xs font-bold text-slate-700">
                    <span className="flex items-center justify-between">
                      <span>Debtor Code</span>
                      {form.debtorCode ? (
                        <span className="text-[10px] text-emerald-600 font-bold">✓ Auto-linked</span>
                      ) : (
                        <span className="text-[10px] text-amber-600 font-bold">Auto-linking...</span>
                      )}
                    </span>
                    <input
                      list="autocount-debtors-list"
                      value={form.debtorCode}
                      onChange={(event) => {
                        const val = event.target.value.toUpperCase();
                        const matched = debtors.find((d) => d.code.toUpperCase() === val || d.name.toUpperCase() === val);
                        const finalCode = matched ? matched.code : val;
                        let nextTerm = form.creditTermDays;
                        if (matched?.term) {
                          const m = matched.term.match(/\d+/);
                          if (m) nextTerm = Number(m[0]);
                        }
                        setForm((current) => ({
                          ...current,
                          debtorCode: finalCode,
                          creditTermDays: nextTerm,
                          dueDate: computeDueDate(current.invoiceDate, nextTerm),
                        }));
                      }}
                      placeholder="Enter or select AutoCount Debtor Code"
                      className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 uppercase font-medium text-xs"
                    />
                    <datalist id="autocount-debtors-list">
                      {(debtors || []).map((d) => (
                        <option key={d.code} value={d.code}>
                          {d.name} {d.term ? `(${d.term})` : ""}
                        </option>
                      ))}
                    </datalist>
                  </label>
                </div>

                {/* Vehicle Type & No */}
                <div className="grid grid-cols-2 gap-3">
                  <label className="text-xs font-bold text-slate-700">
                    Vehicle Type
                    <input
                      value={form.vehicleType}
                      onChange={(event) => setForm((current) => ({ ...current, vehicleType: event.target.value }))}
                      className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs"
                    />
                  </label>
                  <label className="text-xs font-bold text-slate-700">
                    Vehicle No.
                    <input
                      value={form.vehicleNo}
                      onChange={(event) =>
                        setForm((current) => ({ ...current, vehicleNo: event.target.value.toUpperCase() }))
                      }
                      className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 uppercase text-xs"
                    />
                  </label>
                </div>

                {/* Terms & Discount */}
                <div className="grid grid-cols-2 gap-3">
                  <label className="text-xs font-bold text-slate-700">
                    Credit Term (days)
                    <input
                      type="number"
                      min="0"
                      max="3650"
                      value={form.creditTermDays}
                      onChange={(event) => {
                        const term = Number(event.target.value) || 0;
                        setForm((current) => ({
                          ...current,
                          creditTermDays: term,
                          dueDate: computeDueDate(current.invoiceDate, term),
                        }));
                      }}
                      className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs"
                    />
                  </label>
                  <label className="text-xs font-bold text-slate-700">
                    Discount (RM)
                    <input
                      type="number"
                      min="0"
                      value={form.discount}
                      onChange={(event) => setForm((current) => ({ ...current, discount: Number(event.target.value) }))}
                      className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs"
                    />
                  </label>
                </div>

                {/* Items Section */}
                <div>
                  <div className="mb-2 flex items-center justify-between">
                    <h3 className="text-xs font-extrabold uppercase tracking-wide text-slate-500">
                      {form.docType === "DO" ? "Delivery Order items" : "Invoice items"}
                    </h3>
                    <button
                      type="button"
                      onClick={() =>
                        setForm((current) => ({
                          ...current,
                          items: [
                            ...current.items,
                            { type: "part", code: "", description: "", quantity: 1, unitPrice: 0, taxCode: "", taxRate: 0 },
                          ],
                        }))
                      }
                      className="inline-flex items-center text-xs font-bold text-blue-700 cursor-pointer"
                    >
                      <Plus className="mr-1 h-3.5 w-3.5" />
                      Add item
                    </button>
                  </div>
                  <div className="space-y-3">
                    {form.items.map((item, index) => (
                      <div key={item.id || index} className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                        <div className="mb-2 flex gap-2">
                          <AdminSelect
                            value={item.type}
                            onChange={(event) => {
                              const newType = event.target.value as InvoiceLine["type"];
                              const isLabour = newType === "labour";
                              updateItem(index, {
                                type: newType,
                                serviceTypeId: null,
                                code: "",
                                description: "",
                                quantity: 1,
                                unitPrice: 0,
                                taxCode: isLabour ? "SV-8" : "",
                                taxRate: isLabour ? 8 : 0,
                              });
                            }}
                            className="min-w-0 flex-1 text-xs"
                          >
                            <option value="part">Part (0%)</option>
                            <option value="labour">Service / Labour (8%)</option>
                            <option value="other">Other (0%)</option>
                          </AdminSelect>
                          <input
                            value={item.code}
                            onChange={(event) => updateItem(index, { code: event.target.value })}
                            placeholder="Item code"
                            className="min-w-0 flex-1 rounded-lg border border-slate-200 bg-white px-2 py-2 text-xs"
                          />
                          {form.items.length > 1 ? (
                            <button
                              type="button"
                              onClick={() =>
                                setForm((current) => ({
                                  ...current,
                                  items: current.items.filter((_, itemIndex) => itemIndex !== index),
                                }))
                              }
                              className="rounded-lg p-2 text-rose-600 cursor-pointer"
                              aria-label="Remove item"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          ) : null}
                        </div>

                        <DocumentItemCatalogSelect
                          itemType={item.type}
                          serviceTypeId={item.serviceTypeId}
                          code={item.code}
                          parts={catalogParts}
                          onSelect={(selection) =>
                            updateItem(index, {
                              serviceTypeId: selection.serviceTypeId,
                              code: selection.code,
                              description: selection.description,
                              quantity: 1,
                              unitPrice: selection.unitPrice,
                              taxCode: selection.taxCode,
                              taxRate: 0,
                            })
                          }
                        />

                        <textarea
                          rows={2}
                          value={item.description}
                          onChange={(event) => updateItem(index, { description: event.target.value })}
                          placeholder="Description"
                          className="w-full resize-none rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs"
                        />

                        <div className="mt-2 grid grid-cols-4 gap-2">
                          <label className="text-[10px] font-bold text-slate-500">
                            QTY
                            <input
                              type="number"
                              min="1"
                              step="1"
                              value={item.quantity}
                              onChange={(event) =>
                                updateItem(index, { quantity: Math.max(1, Number(event.target.value)) })
                              }
                              className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-2 py-2 text-xs font-bold"
                            />
                          </label>
                          <label className="text-[10px] font-bold text-slate-500">
                            UNIT PRICE
                            <input
                              type="number"
                              min="0"
                              step="0.01"
                              value={item.unitPrice}
                              onChange={(event) =>
                                updateItem(index, { unitPrice: Number(event.target.value) })
                              }
                              className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-2 py-2 text-xs"
                            />
                          </label>
                          <label className="text-[10px] font-bold text-slate-500">
                            TAX
                            <AdminSelect
                              value={Number(item.taxRate || 0)}
                              onChange={(event) => {
                                const rate = Number(event.target.value);
                                updateItem(index, { taxRate: rate, taxCode: rate === 8 ? "SV-8" : "" });
                              }}
                              className="mt-1 w-full text-xs"
                            >
                              <option value={0}>@0%</option>
                              <option value={8}>SV-8 · 8%</option>
                            </AdminSelect>
                          </label>
                          <div className="text-[10px] font-bold text-slate-500">
                            AMOUNT
                            <div className="mt-1 rounded-lg bg-slate-200/70 px-2 py-2 text-right text-xs">
                              {money(item.quantity * item.unitPrice)}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Notes & Payment Instructions */}
                <label className="block text-xs font-bold text-slate-700">
                  {form.docType === "DO" ? "Delivery notes" : "Invoice notes"}
                  <textarea
                    rows={3}
                    value={form.notes}
                    onChange={(event) => setForm((current) => ({ ...current, notes: event.target.value }))}
                    className="mt-1 w-full resize-none rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs"
                  />
                </label>
                <label className="block text-xs font-bold text-slate-700">
                  Payment instructions
                  <textarea
                    rows={5}
                    value={form.paymentInstructions}
                    onChange={(event) =>
                      setForm((current) => ({ ...current, paymentInstructions: event.target.value }))
                    }
                    className="mt-1 w-full resize-none rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs leading-5"
                  />
                </label>

                {/* Sticky Action Footer matching 1:1 */}
                <div className="sticky bottom-0 z-10 -mx-1 grid grid-cols-2 gap-2 rounded-2xl border border-slate-200 bg-white/95 p-3 shadow-[0_-12px_30px_rgba(15,23,42,0.10)] backdrop-blur">
                  <button
                    type="button"
                    disabled={saving}
                    onClick={() => void handleSave(false)}
                    className="inline-flex items-center justify-center rounded-xl border border-slate-200 bg-white py-3 text-sm font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-50 cursor-pointer"
                  >
                    <FileDown className="mr-2 h-4 w-4" />
                    Save Draft
                  </button>
                  <button
                    type="button"
                    disabled={saving}
                    onClick={() => void handleSave(true)}
                    className="inline-flex items-center justify-center rounded-xl bg-[#1e3a8a] py-3 text-sm font-bold text-white hover:bg-blue-800 disabled:opacity-50 cursor-pointer"
                  >
                    <Send className="mr-2 h-4 w-4" />
                    {form.docType === "DO" ? "Issue DO & Queue" : "Issue & Queue"}
                  </button>
                </div>
              </div>
            </aside>

            {/* Right Live Preview Stage matching 1:1 */}
            <main className="invoice-stage overflow-y-auto bg-slate-200/70 p-6 flex justify-center">
              <article id="invoice-document" className="w-full h-fit max-w-[820px] rounded-lg bg-white p-8 sm:p-10 text-[11px] text-slate-900 shadow-xl">
                {/* Header with Logo */}
                <header className="grid grid-cols-[250px_minmax(0,1fr)] items-center border-b-2 border-slate-800 pb-4">
                  <div className="flex h-28 w-60 items-center justify-center overflow-hidden">
                    <img src={logo} alt="Mewah AutoWorks" className="h-28 w-60 scale-[1.55] object-contain" />
                  </div>
                  <div className="text-center leading-tight">
                    <h1 className="text-xl font-black">MEWAH AUTOWORKS SDN BHD</h1>
                    <p>(202101006611 (1406910-T))</p>
                    <p>(A MEMBER OF SHIN YANG GROUP BERHAD)</p>
                    <p>NO. 31, JALAN MOLEK 1/42, TAMAN MOLEK, 81100 JOHOR BAHRU, JOHOR</p>
                    <p>Tel: +607-352 6677 · info@mewahautoworks.com</p>
                  </div>
                </header>

                {/* Customer Box & Document Info */}
                <div className="mt-5 grid grid-cols-2 gap-6">
                  <section className="min-h-40 border border-slate-700 p-3">
                    <p className="text-[9px] font-bold text-slate-500 uppercase tracking-wide">
                      {form.debtorCode || "DEBTOR CODE"}
                    </p>
                    <p className="font-black text-sm">{order.customer || "Cash Customer"}</p>
                    <p className="whitespace-pre-wrap text-slate-600 leading-relaxed text-[11px]">
                      {order.deliveryAddress || "Self-Pickup / Walk-in Customer"}
                    </p>
                  </section>
                  <section>
                    <h2 className="mb-2 text-center text-2xl font-black tracking-wide">
                      {form.docType === "DO" ? "DELIVERY ORDER" : "INVOICE"}
                    </h2>
                    <dl className="grid grid-cols-[100px_10px_1fr] gap-y-1">
                      <dt className="font-bold">{form.docType === "DO" ? "DO No." : "No."}</dt>
                      <dd>:</dd>
                      <dd className="font-mono font-bold">{order.autocountDoNo || "Generated when saved"}</dd>
                      
                      <dt className="font-bold">Date</dt>
                      <dd>:</dd>
                      <dd>{displayDate(form.invoiceDate)}</dd>
                      
                      <dt className="font-bold">Term</dt>
                      <dd>:</dd>
                      <dd>{form.creditTermDays} days</dd>
                      
                      <dt className="font-bold">Job No.</dt>
                      <dd>:</dd>
                      <dd className="font-mono">{form.autocountJobNo}</dd>
                      
                      <dt className="font-bold">Vehicle Type</dt>
                      <dd>:</dd>
                      <dd>{form.vehicleType}</dd>
                      
                      <dt className="font-bold">Vehicle No.</dt>
                      <dd>:</dd>
                      <dd>{form.vehicleNo}</dd>
                    </dl>
                  </section>
                </div>

                {/* Items Table */}
                <table className="mt-5 w-full border-collapse">
                  <thead>
                    <tr className="border-y-2 border-slate-800">
                      <th className="w-10 py-2 text-left">Item</th>
                      <th className="py-2 text-left">Code / Description</th>
                      <th className="w-16 text-right">Qty</th>
                      <th className="w-24 text-right">Unit Price<br />RM</th>
                      <th className="w-24 text-right">Amount<br />RM</th>
                    </tr>
                  </thead>
                  <tbody>
                    {form.items.map((item, index) => (
                      <tr key={item.id || index} className="align-top border-b border-slate-100">
                        <td className="py-2.5 text-slate-400 font-bold">{index + 1}.</td>
                        <td className="py-2.5">
                          <p className="font-bold text-slate-950">
                            {item.code ? `${item.code} · ` : ""}
                            {item.description || "Part description"}
                          </p>
                          <p className="text-[8px] uppercase text-slate-500">{item.type} · @0%</p>
                        </td>
                        <td className="py-2.5 text-right font-medium">{Number(item.quantity).toFixed(2)}</td>
                        <td className="py-2.5 text-right font-medium">{money(item.unitPrice)}</td>
                        <td className="py-2.5 text-right font-bold text-slate-950">
                          {money(item.quantity * item.unitPrice)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* Financial Totals */}
                <div className="mt-8 grid grid-cols-[1fr_290px] gap-4 border-t border-slate-800 pt-2">
                  <div>
                    {form.notes ? (
                      <>
                        <p className="font-black text-slate-900">Note:</p>
                        <p className="whitespace-pre-wrap text-slate-600">{form.notes}</p>
                      </>
                    ) : null}
                    <table className="mt-4 text-[9px]">
                      <thead>
                        <tr>
                          <th className="pr-5 text-left">Tax Code</th>
                          <th className="pr-5 text-right">Taxable</th>
                          <th className="text-right">Tax</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td className="pr-5">ZR (0.00%)</td>
                          <td className="pr-5 text-right">{money(totals.subtotal)}</td>
                          <td className="text-right">0.00</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  <dl className="grid grid-cols-[1fr_90px] gap-y-1 text-right text-[11px]">
                    <dt className="font-bold">Sub Total</dt>
                    <dd>{money(totals.subtotal)}</dd>
                    <dt>Discount</dt>
                    <dd>{money(totals.discount)}</dd>
                    <dt>Service Tax</dt>
                    <dd>0.00</dd>
                    <dt className="border-t border-slate-800 pt-2 text-sm font-black">Total (RM)</dt>
                    <dd className="border-t border-slate-800 pt-2 text-sm font-black">{money(totals.total)}</dd>
                  </dl>
                </div>

                {/* Payment Instructions */}
                <div className="mt-5 border-t border-slate-400 pt-3">
                  <p className="font-black">Payment Instructions:</p>
                  <p className="mt-1 whitespace-pre-wrap text-slate-600">{form.paymentInstructions}</p>
                </div>

                <p className="mt-10 text-center text-xs font-bold text-slate-500">
                  {form.docType === "DO"
                    ? "This is a computer generated delivery order, please acknowledge receipt of parts & goods."
                    : "This is a computer generated invoice, no signature required."}
                </p>

                {/* Signatures for DO */}
                {form.docType === "DO" ? (
                  <div className="mt-12 grid grid-cols-2 gap-12 pt-8 text-center text-xs">
                    <div className="border-t border-slate-800 pt-2">
                      <p className="font-bold text-slate-900">Issued By / Workshop Rep</p>
                    </div>
                    <div className="border-t border-slate-800 pt-2">
                      <p className="font-bold text-slate-900">Received &amp; Accepted By / Customer</p>
                    </div>
                  </div>
                ) : null}
              </article>
            </main>
          </div>
        </div>
      </div>
  );
}
