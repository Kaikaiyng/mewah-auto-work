const DEFAULT_API_BASE_URL = "api/api.php";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || DEFAULT_API_BASE_URL;

export function apiAssetUrl(mode: string, params: Record<string, string | number>) {
  const query = new URLSearchParams({ mode });
  Object.entries(params).forEach(([key, value]) => query.set(key, String(value)));
  return `${API_BASE_URL}${API_BASE_URL.includes("?") ? "&" : "?"}${query.toString()}`;
}

function authValue(key: string) {
  return sessionStorage.getItem(key) || localStorage.getItem(key);
}

function clearStoredAdminAuth() {
  for (const storage of [sessionStorage, localStorage]) {
    storage.removeItem("maw_admin_authenticated");
    storage.removeItem("maw_admin_user");
    storage.removeItem("maw_admin_auth_expires_at");
    storage.removeItem("csrf_token");
  }
}

type ApiResponse<T> = {
  success: boolean;
  message: string;
  data: T;
};

export async function apiRequest<T>(mode: string, options: RequestInit = {}): Promise<T> {
  const separator = API_BASE_URL.includes("?") ? "&" : "?";
  const csrfToken = authValue("csrf_token");
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(options.headers as Record<string, string> || {}),
  };
  if (csrfToken) {
    headers["X-CSRF-Token"] = csrfToken;
  }

  const response = await fetch(`${API_BASE_URL}${separator}mode=${mode}`, {
    headers,
    credentials: "include",
    cache: "no-store",
    ...options,
  });

  const responseText = await response.text();
  let payload: ApiResponse<T>;

  try {
    payload = JSON.parse(responseText) as ApiResponse<T>;
  } catch {
    const message = responseText.trim()
      ? `API returned non-JSON response (${response.status}): ${responseText.slice(0, 160)}`
      : `API returned empty response (${response.status}). Check api.php path, PHP error log, and database credentials.`;
    throw new Error(message);
  }

  if (!response.ok || !payload.success) {
    if (response.status === 401 && mode !== "admin-login") {
      clearStoredAdminAuth();
      const loginPath = window.location.pathname.startsWith("/staging/")
        ? "/staging/login"
        : "/login";
      window.location.replace(loginPath);
    }
    throw new Error(payload.message || "API request failed");
  }

  return payload.data;
}

export function postApi<T>(mode: string, body: unknown): Promise<T> {
  return apiRequest<T>(mode, {
    method: "POST",
    body: JSON.stringify(body),
  });
}
