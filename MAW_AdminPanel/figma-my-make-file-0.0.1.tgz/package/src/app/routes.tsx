import { createBrowserRouter, Navigate } from "react-router";
import type { ReactNode } from "react";
import { DashboardLayout } from "./components/dashboard-layout";
import { Dashboard } from "./components/dashboard";
import { Customers } from "./components/customers";
import { Drivers } from "./components/drivers";
import { Companies } from "./components/companies";
import { Suppliers } from "./components/suppliers";
import { Equipment } from "./components/equipment";
import { Bookings } from "./components/bookings";
import { PartsInventory } from "./components/parts-inventory";
import { Orders } from "./components/orders";
import { PurchaseOrders } from "./components/purchase-orders";
import { Invoices } from "./components/invoices";
import { PendingSyncInvoices } from "./components/pending-sync-invoices";
import { Notifications } from "./components/notifications";
import { Reports } from "./components/reports";
import { Settings } from "./components/settings";
import { WorkOrders } from "./components/work-orders";
import { Staff } from "./components/staff";
import { AuditTrail } from "./components/audit-trail";
import { AppLogs } from "./components/app-logs";
import { AutocountSyncHealth } from "./components/autocount-sync-health";
import { AutoCountProjects } from "./components/autocount-projects";
import { isAdminAuthenticated, LoginPage } from "./components/login-page";
import { canAccessAdminPath } from "./lib/admin-permissions";

function ProtectedDashboardLayout() {
  if (!isAdminAuthenticated()) {
    return <Navigate to="/login" replace />;
  }

  return <DashboardLayout />;
}

function RoleProtectedPage({ path, children }: { path: string; children: ReactNode }) {
  if (!canAccessAdminPath(path)) {
    return <Navigate to="/" replace />;
  }
  return children;
}

function DashboardIndex() {
  return canAccessAdminPath("/")
    ? <Dashboard />
    : <Navigate to="/work-orders" replace />;
}

// Router configuration
export const router = createBrowserRouter([
  {
    path: "/login",
    Component: LoginPage,
  },
  {
    path: "/",
    Component: ProtectedDashboardLayout,
    children: [
      { index: true, Component: DashboardIndex },
      { path: "work-orders", element: <RoleProtectedPage path="/work-orders"><WorkOrders /></RoleProtectedPage> },
      { path: "staff", element: <RoleProtectedPage path="/staff"><Staff /></RoleProtectedPage> },
      { path: "customers", element: <RoleProtectedPage path="/customers"><Customers /></RoleProtectedPage> },
      { path: "drivers", element: <RoleProtectedPage path="/drivers"><Drivers /></RoleProtectedPage> },
      { path: "companies", element: <RoleProtectedPage path="/companies"><Companies /></RoleProtectedPage> },
      { path: "debtors", element: <Navigate to="/companies" replace /> },
      { path: "autocount-sync", element: <RoleProtectedPage path="/autocount-sync"><AutocountSyncHealth /></RoleProtectedPage> },
      { path: "suppliers", element: <RoleProtectedPage path="/suppliers"><Suppliers /></RoleProtectedPage> },
      { path: "equipment", element: <RoleProtectedPage path="/equipment"><Equipment /></RoleProtectedPage> },
      { path: "projects", element: <RoleProtectedPage path="/projects"><AutoCountProjects /></RoleProtectedPage> },
      { path: "bookings", element: <RoleProtectedPage path="/bookings"><Bookings /></RoleProtectedPage> },
      { path: "parts", element: <RoleProtectedPage path="/parts"><PartsInventory /></RoleProtectedPage> },
      { path: "orders", element: <RoleProtectedPage path="/orders"><Orders /></RoleProtectedPage> },
      { path: "purchase-orders", element: <RoleProtectedPage path="/purchase-orders"><PurchaseOrders /></RoleProtectedPage> },
      { path: "invoices", element: <RoleProtectedPage path="/invoices"><Invoices /></RoleProtectedPage> },
      { path: "pending-sync-invoices", element: <RoleProtectedPage path="/pending-sync-invoices"><PendingSyncInvoices /></RoleProtectedPage> },
      { path: "billing/pending-sync", element: <Navigate to="/pending-sync-invoices" replace /> },
      { path: "notifications", element: <RoleProtectedPage path="/notifications"><Notifications /></RoleProtectedPage> },
      { path: "audit-trail", element: <RoleProtectedPage path="/audit-trail"><AuditTrail /></RoleProtectedPage> },
      { path: "app-logs", element: <RoleProtectedPage path="/app-logs"><AppLogs /></RoleProtectedPage> },
      { path: "reports", element: <RoleProtectedPage path="/reports"><Reports /></RoleProtectedPage> },
      { path: "settings", element: <RoleProtectedPage path="/settings"><Settings /></RoleProtectedPage> },
    ],
  },
]);
